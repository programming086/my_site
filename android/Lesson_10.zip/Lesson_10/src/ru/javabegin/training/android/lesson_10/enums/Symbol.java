package ru.javabegin.training.android.lesson_10.enums;

public enum Symbol {
	
	FIRST_DIGIT,
	OPERATION,
	SECOND_DIGIT

}
