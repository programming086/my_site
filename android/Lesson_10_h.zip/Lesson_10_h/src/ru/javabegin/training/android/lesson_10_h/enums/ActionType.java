package ru.javabegin.training.android.lesson_10_h.enums;

public enum ActionType {
	OPERAION,
	CALCULATION,
	CLEAR,
	DIGIT,
	COMMA,
	DELETE

}
