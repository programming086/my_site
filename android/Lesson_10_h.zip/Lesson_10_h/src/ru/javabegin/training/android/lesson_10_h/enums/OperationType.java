package ru.javabegin.training.android.lesson_10_h.enums;

public enum OperationType {
	
	ADD,
	SUBTRACT,
	MULTIPLY,
	DIVIDE

}
