package ru.javabegin.training.android.lesson_10_h.enums;

public enum Symbol {
	
	FIRST_DIGIT,
	OPERATION,
	SECOND_DIGIT

}
