package ru.javabegin.training.android.lesson_11.enums;

public enum ActionType {
	OPERAION,
	CALCULATION,
	CLEAR,
	DIGIT,
	COMMA,
	DELETE

}
