package ru.javabegin.training.android.lesson_12.enums;

public enum ActionType {
	OPERAION,
	CALCULATION,
	CLEAR,
	DIGIT,
	COMMA,
	DELETE

}
