package ru.javabegin.training.android.lesson_12.enums;

public enum OperationType {
	
	ADD,
	SUBTRACT,
	MULTIPLY,
	DIVIDE

}
