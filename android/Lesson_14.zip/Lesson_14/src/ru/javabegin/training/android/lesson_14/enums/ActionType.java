package ru.javabegin.training.android.lesson_14.enums;

public enum ActionType {
	OPERAION,
	CALCULATION,
	CLEAR,
	DIGIT,
	COMMA,
	DELETE

}
