package ru.javabegin.training.android.lesson_14.enums;

public enum OperationType {
	
	ADD,
	SUBTRACT,
	MULTIPLY,
	DIVIDE

}
