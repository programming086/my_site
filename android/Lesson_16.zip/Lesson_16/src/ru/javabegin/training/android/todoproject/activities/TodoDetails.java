package ru.javabegin.training.android.todoproject.activities;

import ru.javabegin.training.adnroid.todoproject.R;
import ru.javabegin.training.android.todoproject.objects.TodoDocument;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class TodoDetails extends Activity {
	
	public static final int RESULT_SAVE = 100;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_todo_details);
		TodoDocument todoDocument = (TodoDocument)getIntent().getSerializableExtra(TodoList.TODO_DOCUMENT);
		setTitle(todoDocument.getName());
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.todo_details, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.back:{
		
			setResult(RESULT_CANCELED);
			finish();
			return true;
		}
		
		case R.id.save:{
			setResult(RESULT_SAVE);
			finish();
			return true;
		}

		default:
			break;
		}
		
		
		return super.onOptionsItemSelected(item);
	}

}
