package ru.javabegin.training.android.todoproject.objects;

import java.util.ArrayList;

import android.app.Application;

public class AppContext extends Application{
	
	public static final String ACTION_TYPE = "ru.javabegin.training.android.todoproject.AppContext.ActionType";
	public static final String DOC_INDEX = "ru.javabegin.training.android.todoproject.AppContext.ActionIndex";
	
	public static final int ACTION_NEW_TASK = 0;
	public static final int ACTION_UPDATE = 1;
	
	private ArrayList<TodoDocument> listDocuments = new ArrayList<TodoDocument>();
	
	public ArrayList<TodoDocument> getListDocuments() {
		return listDocuments;
	}
	
	public void setListDocuments(ArrayList<TodoDocument> listDocuments) {
		this.listDocuments = listDocuments;
	}

}
