package ru.javabegin.training.android.todoproject.objects;

import java.util.Comparator;

public class TodoListComparator {
	
	private static DateComparator dateComparator;
	private static NameComparator nameComparator;
	
	public static Comparator<TodoDocument> getDateComparator(){
		if (dateComparator == null){
			dateComparator = new DateComparator();
		}
		
		return dateComparator;
	}

	
	public static Comparator<TodoDocument> getNameComparator(){
		if (nameComparator == null){
			nameComparator = new NameComparator();
		}
		
		return nameComparator;
	}
	
	
	private static class NameComparator implements Comparator<TodoDocument> {

		@Override
		public int compare(TodoDocument lhs, TodoDocument rhs) {
			return lhs.getName().compareTo(rhs.getName());
		}

	}

	private static class DateComparator implements Comparator<TodoDocument> {

		@Override
		public int compare(TodoDocument lhs, TodoDocument rhs) {
			return rhs.getCreateDate().compareTo(lhs.getCreateDate());
		}

	}

}
