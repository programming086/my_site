/** Automatically generated file. DO NOT MODIFY */
package ru.javabegin.training.adnroid.todoproject;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}