package ru.javabegin.training.android.todoproject.objects;

import java.io.File;
import java.util.ArrayList;

import ru.javabegin.training.android.todoproject.receivers.DeleteDocumentReceiver;
import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;

public class AppContext extends Application {

	public static final String ACTION_TYPE = "ru.javabegin.training.android.todoproject.ActionType";
	public static final String DOC_INDEX = "ru.javabegin.training.android.todoproject.DocIndex";
	public static final String DOC_INDEXES = "ru.javabegin.training.android.todoproject.DocIndexes";

	public static final int ACTION_NEW_TASK = 0;
	public static final int ACTION_UPDATE = 1;

	public static final String FIELD_CONTENT = "content";
	public static final String FIELD_NAME = "name";
	public static final String FIELD_CREATE_DATE = "createDate";
	public static final String FIELD_PRIORITY_TYPE = "priorityType";
	public static final String FIELD_IMAGE_PATH = "imagePath";
	
	public static final String RECEIVER_DELETE_DOCUMENT = "ru.javabegin.training.android.todoproject.DeleteDocument";

	public static final String RECEIVER_REFRESH_LISTVIEW = "ru.javabegin.training.android.todoproject.RefreshListView";

	public static final int IMAGE_WIDTH_FULL = 400;
	public static final int IMAGE_HEIGHT_FULL = 400;

	public static final int IMAGE_WIDTH_THMB = 100;
	public static final int IMAGE_HEIGHT_THMB = 100;
	
	private ArrayList<TodoDocument> listDocuments;

	
	private BroadcastReceiver deleteDocumentReceiver = new DeleteDocumentReceiver();
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		LocalBroadcastManager.getInstance(this).registerReceiver(deleteDocumentReceiver, new IntentFilter(RECEIVER_DELETE_DOCUMENT));
	}
	
	@Override
	public void onTerminate() {
		// TODO Auto-generated method stub
		super.onTerminate();
		LocalBroadcastManager.getInstance(this).unregisterReceiver(deleteDocumentReceiver);
	}

	public ArrayList<TodoDocument> getListDocuments() {
		return listDocuments;
	}

	public void setListDocuments(ArrayList<TodoDocument> listDocuments) {
		this.listDocuments = listDocuments;
	}

	public File getPrefsDir() {
		return new File(getApplicationInfo().dataDir + "/" + "shared_prefs");
	}
	
	public String getPrefsDirPath() {
		return getApplicationInfo().dataDir + "/" + "shared_prefs";
	}
	

}
