package ru.javabegin.training.android.todoproject.activities;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Set;
import java.util.TreeSet;

import ru.javabegin.training.adnroid.todoproject.R;
import ru.javabegin.training.android.todoproject.adapters.TodoAdapter;
import ru.javabegin.training.android.todoproject.enums.PriorityType;
import ru.javabegin.training.android.todoproject.objects.AppContext;
import ru.javabegin.training.android.todoproject.objects.TodoDocument;
import ru.javabegin.training.android.todoproject.objects.TodoListComparator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.LayoutAnimationController;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class TodoList extends Activity {

	private ListView listviewTasks;
	private MenuItem menuSort;
	private MenuItem menuDelete;
	private MenuItem menuCreate;

	private RelativeLayout layoutListView;

	private EditText txtSearch;
	private ArrayList<TodoDocument> listDocuments;
	private Intent intent;
	private TodoAdapter todoAdapter;

	private CheckboxListener checkboxListener = new CheckboxListener();

	private static Comparator<TodoDocument> comparator = TodoListComparator
			.getDateComparator();// по-умолчанию сортировать по дате создания
									// заметки

	private BroadcastReceiver refreshListViewReceiver = new RefreshListViewReceiver();

	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_todo_list);

		listviewTasks = (ListView) findViewById(R.id.listTasks);
		listviewTasks.setOnItemClickListener(new ListViewClickListener());
		listviewTasks.setEmptyView(findViewById(R.id.emptyView));
		
		listviewTasks.setLayoutAnimation(createAnimation());

		layoutListView = (RelativeLayout) findViewById(R.id.layoutListView);

		txtSearch = (EditText) findViewById(R.id.txtSearch);
		txtSearch.addTextChangedListener(new TextChangeListener());

		getActionBar().setDisplayHomeAsUpEnabled(false);

		intent = new Intent(this, TodoDetails.class);

		LocalBroadcastManager.getInstance(this).registerReceiver(
				refreshListViewReceiver,
				new IntentFilter(AppContext.RECEIVER_REFRESH_LISTVIEW));

		if (((AppContext) getApplicationContext()).getListDocuments() == null) {// если
																				// в
																				// первый
																				// раз
																				// загружаем
																				// документы
			new LoadDocumentsTask().execute();
		}

	}

	private LayoutAnimationController createAnimation() {
		
		AnimationSet set = new AnimationSet(true);

		Animation animation = new AlphaAnimation(0.0f, 1.0f);

		animation.setDuration(300);

		set.addAnimation(animation);

		animation = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF, 0.0f, Animation.RELATIVE_TO_SELF, 1.0f, Animation.RELATIVE_TO_SELF, 0.0f);

		animation.setDuration(300);

		set.addAnimation(animation);
		
		return new LayoutAnimationController(set, 0.3f);
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		if (listDocuments != null) {
			sort();
		}
	}

	private void checkControlsActive() {
		if (listDocuments == null || menuSort == null || menuDelete == null)
			return;
		if (listDocuments.isEmpty()) {
			menuDelete.setEnabled(false);
			menuSort.setEnabled(false);
			menuCreate.setEnabled(true);
			txtSearch.setEnabled(false);
		} else {
			menuDelete.setEnabled(!indexesForDelete.isEmpty());
			menuSort.setEnabled(listDocuments.size() > 1);// если запись только
															// одна - сортировка
															// недоступна
			menuCreate.setEnabled(indexesForDelete.isEmpty());
			txtSearch.setEnabled(indexesForDelete.isEmpty());
		}
	}

	private void sort() {

		indexesForDelete.clear();

		Collections.sort(listDocuments, comparator);
		updateIndexes();

		// возможны более оптимальные решения: наследование от BaseAdapter,
		// запуск в параллельном потоке
		todoAdapter = new TodoAdapter(this, listDocuments, checkboxListener);
		listviewTasks.setAdapter(todoAdapter);

		todoAdapter.getFilter().filter(txtSearch.getText());

		checkControlsActive();

		setTitle(getResources().getString(R.string.app_name) + " ("
				+ listDocuments.size() + ")");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.todo_list, menu);

		menuSort = menu.findItem(R.id.menu_sort);
		menuDelete = menu.findItem(R.id.menu_delete_check);
		menuCreate = menu.findItem(R.id.menu_new_task);

		checkControlsActive();

		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		if (item.isChecked()) {
			return true;
		}

		switch (item.getItemId()) {
		case R.id.menu_new_task: {

			Bundle bundle = new Bundle();
			bundle.putInt(AppContext.ACTION_TYPE, AppContext.ACTION_NEW_TASK);

			intent.putExtras(bundle);
			startActivity(intent);
			overridePendingTransition(R.anim.pull_in_right,
					R.anim.push_out_left);

			return true;
		}

		case R.id.menu_sort_name: {
			comparator = TodoListComparator.getNameComparator();
			sort();
			item.setChecked(true);
			return true;
		}

		case R.id.menu_sort_date: {
			comparator = TodoListComparator.getDateComparator();
			sort();
			item.setChecked(true);
			return true;
		}

		case R.id.menu_sort_priority: {
			comparator = TodoListComparator.getPriorityComparator();
			sort();
			item.setChecked(true);
			return true;
		}

		case R.id.menu_delete_check: {

			if (!indexesForDelete.isEmpty()) {

				Intent intent = new Intent(AppContext.RECEIVER_DELETE_DOCUMENT);

				intent.putIntegerArrayListExtra(AppContext.DOC_INDEXES,
						new ArrayList<Integer>(indexesForDelete));
				LocalBroadcastManager.getInstance(this).sendBroadcast(intent);

				indexesForDelete.clear();

			}

			return true;
		}

		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	private void updateIndexes() {
		int i = 0;
		for (TodoDocument doc : listDocuments) {
			doc.setNumber(i++);
		}
	}

	public void clearSearch(View view) {
		txtSearch.setText("");
	}

	private class ListViewClickListener implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			Bundle bundle = new Bundle();
			bundle.putInt(AppContext.ACTION_TYPE, AppContext.ACTION_UPDATE);
			bundle.putInt(AppContext.DOC_INDEX, ((TodoDocument) parent
					.getAdapter().getItem(position)).getNumber());

			intent.putExtras(bundle);
			startActivity(intent);
			overridePendingTransition(R.anim.pull_in_right,
					R.anim.push_out_left);
		}

	}

	private class TextChangeListener implements TextWatcher {

		@Override
		public void afterTextChanged(Editable s) {
		}

		@Override
		public void beforeTextChanged(CharSequence s, int start, int count,
				int after) {
		}

		@Override
		public void onTextChanged(CharSequence s, int start, int before,
				int count) {
			todoAdapter.getFilter().filter(s);
		}

	}

	private class RefreshListViewReceiver extends BroadcastReceiver {

		@Override
		public void onReceive(Context context, Intent intent) {
			sort();

		}

	}

	private Set<Integer> indexesForDelete = new TreeSet<Integer>();

	private class CheckboxListener implements View.OnClickListener {

		@Override
		public void onClick(View v) {
			CheckBox checkBox = (CheckBox) v;
			TodoDocument todoDocument = (TodoDocument) checkBox.getTag();
			todoDocument.setChecked(checkBox.isChecked());

			RelativeLayout ve = (RelativeLayout) v.getParent();

			TextView txtTodoName = (TextView) ve
					.findViewById(R.id.txt_todo_name);
			TextView txtTodoDate = (TextView) ve
					.findViewById(R.id.txt_todo_date);

			if (checkBox.isChecked()) {
				indexesForDelete.add(todoDocument.getNumber());
				txtTodoName.setTextColor(Color.LTGRAY);
				txtTodoDate.setTextColor(Color.LTGRAY);
			} else {
				indexesForDelete.remove(todoDocument.getNumber());
				txtTodoName.setTextColor(Color.BLACK);
				txtTodoDate.setTextColor(Color.BLACK);
			}

			checkControlsActive();

		}

	}

	private class LoadDocumentsTask extends AsyncTask<Void, String, Void> {

		private ProgressDialog dialog;

		private File prefsDir = ((AppContext) getApplicationContext())
				.getPrefsDir();

		@Override
		protected void onPreExecute() {

			int max = 0;

			if (prefsDir.list() != null) {
				max = prefsDir.list().length;
			}

			if (max == 0)
				return;

			dialog = new ProgressDialog(TodoList.this);
			// dialog.setTitle("");
			dialog.setMax(max);
			dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			dialog.setMessage(getResources().getString(R.string.loading));

			if (!dialog.isShowing()) {
				dialog.show();
			}
		}

		@Override
		protected void onPostExecute(Void result) {
			layoutListView.setVisibility(View.VISIBLE);
			if (dialog != null && dialog.isShowing()) {
				sort();
				dialog.dismiss();
			}

		}

		@Override
		protected void onProgressUpdate(String... values) {
			dialog.setProgress(Integer.valueOf(values[0]));
			dialog.setMessage(getResources().getString(R.string.loading) + "\""
					+ values[1] + "...\"");
		}

		@Override
		protected Void doInBackground(Void... params) {

			imitateLoaindg();

			AppContext appContext = ((AppContext) getApplicationContext());

			listDocuments = new ArrayList<TodoDocument>();

			if (prefsDir.exists() && prefsDir.isDirectory()) {
				String[] list = prefsDir.list();
				for (int i = 0; i < list.length; i++) {
					SharedPreferences sharedPref = getSharedPreferences(
							list[i].replace(".xml", ""), Context.MODE_PRIVATE);
					TodoDocument todoDocument = new TodoDocument();
					todoDocument.setContent(sharedPref.getString(
							AppContext.FIELD_CONTENT, null));
					todoDocument.setCreateDate(new Date(sharedPref.getLong(
							AppContext.FIELD_CREATE_DATE, 0)));
					todoDocument.setName(sharedPref.getString(
							AppContext.FIELD_NAME, null));
					todoDocument
							.setPriorityType(PriorityType.values()[sharedPref
									.getInt(AppContext.FIELD_PRIORITY_TYPE, 0)]);
					todoDocument.setImagePath(sharedPref.getString(
							AppContext.FIELD_IMAGE_PATH, null));
					listDocuments.add(todoDocument);

					imitateLoaindg();

					publishProgress("" + i, todoDocument.getName());

				}

			}

			appContext.setListDocuments(listDocuments);

			return null;
		}

		private void imitateLoaindg() {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

}
