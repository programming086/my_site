package ru.javabegin.training.android.lesson_4;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

	private TextView txtLogin;
	private TextView txtPassword;

	private Button btnLogin;
	private Button btnClear;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		txtLogin = (TextView) findViewById(R.id.txtLogin);
		txtPassword = (TextView) findViewById(R.id.txtPassword);
		btnLogin = (Button) findViewById(R.id.btnLogin);
		btnClear = (Button) findViewById(R.id.btnClear);
	}

	public void buttonClick(View view) {
		if (view == btnLogin) {


		} else if (view == btnClear) {

			txtLogin.setText("");
			txtPassword.setText("");
			txtLogin.requestFocus();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
