package ru.javabegin.training.android.lesson_5;

import ru.javabegin.training.android.objects.LoginInfo;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.widget.TextView;

public class ResultActivity extends Activity {
	
	private TextView txtResult; 

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_result);
		
		Intent intent = getIntent();
		LoginInfo loginInfo = (LoginInfo)intent.getSerializableExtra(MainActivity.LOGIN_INFO);
		
		txtResult = (TextView) findViewById(R.id.txtResult);
		
		txtResult.setText(String.format(txtResult.getText().toString(),loginInfo.getLogin(),loginInfo.getPassword(), loginInfo.getDevice()));
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.result, menu);
		return true;
	}

}
