package ru.javabegin.training.android.lesson_6_h;

import ru.javabegin.training.android.objects.LoginInfo;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity{

	public static final String LOGIN_INFO = "ru.javabegin.training.android.login_info";

	private TextView txtLogin;
	private TextView txtPassword;

	private Spinner spinDevices;

	private Builder dlgBuilder;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		defineComponents();

		prepareDialogBuilder();
	}

	private void prepareDialogBuilder() {
		dlgBuilder = new Builder(this);
		dlgBuilder.setTitle(R.string.error);
//		dlgBuilder.setNegativeButton("Cancel", this);
		dlgBuilder.setPositiveButton("OK", null);		
	}
	
	

	private void defineComponents() {
		txtLogin = (TextView) findViewById(R.id.txtLogin);
		txtPassword = (TextView) findViewById(R.id.txtPassword);

		spinDevices = (Spinner) findViewById(R.id.spinDevices);
		
		txtLogin.requestFocus();
	}

	private void showUserDialog(int messageId) {
		dlgBuilder.setMessage(messageId);
		AlertDialog alertDialog = dlgBuilder.create();
		alertDialog.show();
	}
	
	private void showToastMessage(int messageId){
		Toast toastMessage = Toast.makeText(this, messageId, Toast.LENGTH_LONG);
		toastMessage.setGravity(Gravity.TOP, 0, 100);
		toastMessage.show();
	}

	public void buttonClick(View view) {

		if (view.getId() == R.id.btnLogin) {

			LoginInfo loginInfo = new LoginInfo();
			loginInfo.setLogin(txtLogin.getText().toString());
			loginInfo.setPassword(txtPassword.getText().toString());
			loginInfo.setDevice(spinDevices.getSelectedItem().toString());

			if (loginInfo.getLogin() == null
					|| loginInfo.getLogin().trim().equals("")) {
				showToastMessage(R.string.login_required);
				txtLogin.requestFocus();
				return;
			} else if (loginInfo.getPassword() == null
					|| loginInfo.getPassword().trim().equals("")) {

				showToastMessage(R.string.password_required);
				txtPassword.requestFocus();
				return;
			}

			Intent resultIntent = new Intent(this, ResultActivity.class);
			resultIntent.putExtra(LOGIN_INFO, loginInfo);
			startActivity(resultIntent);

		} else if (view.getId() == R.id.btnClear) {

			txtLogin.setText("");
			txtPassword.setText("");
			spinDevices.setSelection(0);
			txtLogin.requestFocus();
		}

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}


}
