/** Automatically generated file. DO NOT MODIFY */
package ru.javabegin.training.android.lesson_7_h;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}