package ru.javabegin.training.android.lesson_8;

public enum Symbol {
	
	FIRST_DIGIT,
	OPERATION,
	SECOND_DIGIT

}
