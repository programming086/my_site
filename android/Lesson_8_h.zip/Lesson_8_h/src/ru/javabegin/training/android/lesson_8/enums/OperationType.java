package ru.javabegin.training.android.lesson_8.enums;

public enum OperationType {
	
	ADD,
	SUBTRACT,
	MULTIPLY,
	DIVIDE

}
