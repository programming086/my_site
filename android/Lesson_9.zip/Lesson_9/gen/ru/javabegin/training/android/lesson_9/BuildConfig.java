/** Automatically generated file. DO NOT MODIFY */
package ru.javabegin.training.android.lesson_9;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}