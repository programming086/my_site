package ru.javabegin.training.android.lesson_9.enums;

public enum OperationType {
	
	ADD,
	SUBTRACT,
	MULTIPLY,
	DIVIDE

}
