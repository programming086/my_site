package ru.javabegin.training.android.money.activities;



import ru.javabegin.training.android.activities.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends Activity {
	
	private ListView menuList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
        
        menuList = (ListView) findViewById(R.id.left_menu);
     
        menuList.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.menu_array)));
        
        menuList.setOnItemClickListener(new DrawerItemClickListener());
        
        
        
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
    private class DrawerItemClickListener implements ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        	Intent contentIntent = new Intent(MainActivity.this, Content.class);
        	contentIntent.putExtra("TEST_CONTENT", id);
        	startActivity(contentIntent);
        }
    }

}
