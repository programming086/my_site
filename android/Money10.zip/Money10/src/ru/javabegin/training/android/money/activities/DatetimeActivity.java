package ru.javabegin.training.android.money.activities;

import java.text.DateFormat;
import java.util.Calendar;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.fragments.DatePickerFragment;
import ru.javabegin.training.android.money.fragments.TimePickerFragment;
import ru.javabegin.training.android.money.gui.datetime.interfaces.DatetimeChangeListener;
import ru.javabegin.training.android.money.objects.AppContext;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

public class DatetimeActivity extends AnimationActivity {
	
	private static final String TAG_DATE = "ru.javabegin.training.android.money.activities.datePicker";
	private static final String TAG_TIME = "ru.javabegin.training.android.money.activities.timePicker";
	
	private TimePickerFragment timeFragment = new TimePickerFragment();
	private DatePickerFragment dateFragment = new DatePickerFragment();
	
	private TextView txtDate;
	private TextView txtTime;
	
	private Calendar calendar;
	
	private Bundle bundle;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_datetime);
		
		txtDate = (TextView)findViewById(R.id.txt_date);
		txtTime = (TextView)findViewById(R.id.txt_time);
		
		calendar = (Calendar)getIntent().getSerializableExtra(AppContext.CALENDAR);
		
		bundle = new Bundle();
		bundle.putSerializable(AppContext.CALENDAR, calendar);// параметры для фрагментов, чтобы при выборе времени сразу показывалось текущее выбранное
		
		changeTime();
		changeDate();
		
		timeFragment.setArguments(bundle);
		dateFragment.setArguments(bundle);
		
		timeFragment.setDatetimeChangeListener(new DatetimeChangeListener() {
			
			@Override
			public void changeValue(Calendar calendar) {
				DatetimeActivity.this.calendar.set(Calendar.HOUR_OF_DAY, calendar.get(Calendar.HOUR_OF_DAY));
				DatetimeActivity.this.calendar.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE));
				
				changeTime();
			}
		});
		
		dateFragment.setDatetimeChangeListener(new DatetimeChangeListener() {
			
			@Override
			public void changeValue(Calendar calendar) {
				DatetimeActivity.this.calendar.set(Calendar.YEAR, calendar.get(Calendar.YEAR));
				DatetimeActivity.this.calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH));
				DatetimeActivity.this.calendar.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH));
				
				changeDate();
			}
		});
			
		
	}
	
	

	private void changeDate() {
		txtDate.setText(DateFormat.getDateInstance().format(calendar.getTime()));		
	}


	private void changeTime() {
		txtTime.setText(DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime()));		
	}



	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.datetime, menu);
		return true;
	}
	
	
	public void showTimePickerDialog(View v) {	
		timeFragment.show(getFragmentManager(), TAG_TIME);	
	}
	
	public void showDatePickerDialog(View v) {
		dateFragment.show(getFragmentManager(), TAG_DATE);	
	}
	
	@Override
	protected void closeActivity() {
		Intent result = new Intent();
		result.putExtra(AppContext.CALENDAR, calendar);
		setResult(RESULT_OK, result);
		super.closeActivity();
	}
	

}
