package ru.javabegin.training.android.money.database.abstracts;

import java.util.ArrayList;

import android.database.Cursor;
import android.database.DatabaseUtils;
import android.util.Log;

public abstract class AbstractDbListItem<T> extends AbstractDbItem{
	

	protected abstract T fillItem(Cursor c); // делегируем дочерним классам заполнение объекта
	
	public T getFirstItemFromSQL(String sql) {
		T item = null;

		try {

			cursor = sqlExecutor.execFirstResult(sql);
			item = fillItem(cursor);
			closeCursor();

		} catch (Exception e) {
			Log.e(tag, e.getMessage());
		}

		return item;
	}
	
	

	public T getLastItem() {
		return getFirstItemFromSQL(getSqlLastItem());
	}

	public T getItem(long id) {
		return getFirstItemFromSQL(getSql(id));
	}

	public ArrayList<T> getListItems(T item) {
		ArrayList<T> sprList = new ArrayList<T>();

		try {

			cursor = sqlExecutor.execSQL(getSqlListItem(item));
			
			System.out.println(DatabaseUtils.dumpCursorToString(cursor));

			while (cursor.moveToNext()) {
				sprList.add(fillItem(cursor));
			}

			closeCursor();

		} catch (Exception e) {
			Log.e(tag, e.getMessage());
		}

		return sprList;
	}
	
	public Cursor getCursorItems(T item) {

		try {
			cursor = sqlExecutor.execSQL(getSqlListItem(item));

		} catch (Exception e) {
			Log.e(tag, e.getMessage());
		}

		return cursor;
	}


	
	
	protected boolean getBooleanFromInt(int number) {
		if (number > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	
	
	public boolean hasRows(String sql){
		cursor = sqlExecutor.execFirstResult(sql);
		int count = cursor.getCount();
		closeCursor();
		return getBooleanFromInt(count);
	}	
	

	
	
	protected String getSqlLastItem() {
		return null;
	}

	protected String getSql(long id) {
		return null;
	}

	protected String getSqlListItem(T item) {
		return null;
	}







}
