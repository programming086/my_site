package ru.javabegin.training.android.money.database.abstracts.impls;

import ru.javabegin.training.android.money.database.abstracts.AbstractDbListItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.CurrencyItem;
import android.database.Cursor;

public class CurrencyDbItem extends AbstractDbListItem<CurrencyItem>{
	
	@Override
	protected String getSqlListItem(CurrencyItem item) {
		StringBuilder builder = new StringBuilder();

		builder.append("select " + " c1._id as " + ALIAS_ID
				+ ", c1.name  as " + ALIAS_NAME
				+ ", coalesce((select _id from " + CURRENCY_TABLE
				+ " c2 where c2.parent_id=c1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + ", c1.short_name as "
				+ ALIAS_SHORT_NAME + " from " + CURRENCY_TABLE
				+ " c1 " + " where coalesce(c1.parent_id,0) = "
				+ item.getId() + " order by order_show");

		return builder.toString();
	}

	@Override
	protected String getSql(long id) {

		StringBuilder builder = new StringBuilder();

		builder.append("select " + " c1._id as " + ALIAS_ID
				+ ", c1.name  as " + ALIAS_NAME
				+ ", coalesce((select _id from " + CURRENCY_TABLE
				+ " c2 where c2.parent_id=c1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + ", c1.short_name as "
				+ ALIAS_SHORT_NAME + " from " + CURRENCY_TABLE + " c1 "
				+ " where c1._id=(select currency_id from "
				+ OPERATIONS_TABLE + " o where o._id=" + id + ")");
		return builder.toString();
	}

	@Override
	protected String getSqlLastItem() {
		StringBuilder builder = new StringBuilder();
		builder.append("select " + " c1._id as " + ALIAS_ID + ", c1.name  as "
				+ ALIAS_NAME + ", coalesce((select _id from " + CURRENCY_TABLE
				+ " c2 where c2.parent_id=c1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + ", c1.short_name as " + ALIAS_SHORT_NAME
				+ " from " + CURRENCY_TABLE + " c1 "
				+ " where c1._id=(select currency_id from "
				+ LAST_OPERATION_TABLE + ")");

		return builder.toString();
	}

	@Override
	protected CurrencyItem fillItem(Cursor c) {
		CurrencyItem item = new CurrencyItem();
		item.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
		item.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));
		item.setShortName(c.getString(c.getColumnIndex(ALIAS_SHORT_NAME)));
		item.setHasChilds(super.getBooleanFromInt(c.getInt(c.getColumnIndex(ALIAS_HAS_CHILD))));
		return item;
	}

	
	
	


}
