package ru.javabegin.training.android.money.database.abstracts.impls;

import ru.javabegin.training.android.money.database.abstracts.AbstractDbListItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.DescriptionItem;
import android.database.Cursor;

public class DescriptionDbItem extends AbstractDbListItem<DescriptionItem> {
	

	@Override
	protected String getSql(long id) {
		StringBuilder builder = new StringBuilder();
		builder.append("select description as "+ALIAS_DESC+" from "+OPERATIONS_TABLE+" where _id="+id);		
		return builder.toString();
	}

	

	protected DescriptionItem fillItem(Cursor c) {		
		DescriptionItem item = new DescriptionItem();
		item.setSelectedText(c.getString(c.getColumnIndex(ALIAS_DESC)));
		return item;
	}


}
