package ru.javabegin.training.android.money.listview.items.interfaces;

import java.util.ArrayList;

public interface ListItem extends Item{
	
	ArrayList<ListItem> getList();

	boolean hasChilds();
	
	String getTableName();

	ListItem getSelectedChildItem();
	
	int getId();
	
	String getName();
	
}
