/** Automatically generated file. DO NOT MODIFY */
package ru.javabegin.training.android.money;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}