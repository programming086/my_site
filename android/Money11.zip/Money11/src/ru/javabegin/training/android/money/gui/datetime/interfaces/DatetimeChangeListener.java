package ru.javabegin.training.android.money.gui.datetime.interfaces;

import java.util.Calendar;

public interface DatetimeChangeListener {
	
	void changeValue(Calendar calendar);

}
