package ru.javabegin.training.android.money.listview.items.interfaces;

import java.io.Serializable;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;

public interface Item extends Serializable{	
	
	Intent getIntent(Context context);	
	
	boolean isEnable();
	
	Bitmap getImage();
	
	String getSelectedText();
	
	String getTitleText();
	
	String getShortText();
	
}
