package ru.javabegin.training.android.money.listview.items.interfaces.impls;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.listview.items.abstracts.AbstractSprItemNotifier;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import ru.javabegin.training.android.money.objects.AppContext;

public class OperTypeItem extends AbstractSprItemNotifier {
	
	private static final long serialVersionUID =  1L;
	
	public static final String TABLE_NAME = "spr_OperationType";
	
	private OperationType type;
	
	public OperTypeItem() {
		setTableName(TABLE_NAME);
		setName(AppContext.getInstance().getResources().getString(R.string.operation_type));
	}
	
	public OperTypeItem(boolean showDefaultItem) {
		this();
		if (showDefaultItem){
			setSelectedChildItem(super.getDefaultItem());
		}
	}
	
	
	@Override
	public ArrayList<ListItem> getList(){
		return new ArrayList<ListItem>(DbItemCreator.getOperTypeDbItem().getListItems(this));
	}
	
		
	
	
	@Override
	public void setSelectedChildItem(ListItem selectedChildItem) {
		super.setSelectedChildItem(selectedChildItem);
		
		notifyListeners(selectedChildItem);
	}
	
	public OperationType getType() {
		return type;
	}
	
	public void setType(OperationType type) {
		this.type = type;
	}
	
	
		
}
