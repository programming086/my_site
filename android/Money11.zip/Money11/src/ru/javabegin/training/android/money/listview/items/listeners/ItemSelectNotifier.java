package ru.javabegin.training.android.money.listview.items.listeners;

import java.util.List;

import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;

// регистратор и уведомитель слушателей
public interface ItemSelectNotifier {
	
	List<ItemSelectListener> getListeners();

    void addListener(ItemSelectListener listener);

    public void removeListener(ItemSelectListener listener);

    public void removeListeners();

    public void notifyListeners(ListItem selectedItem); // можно разделить интерфейсы для регистрации и для уведомления

}
