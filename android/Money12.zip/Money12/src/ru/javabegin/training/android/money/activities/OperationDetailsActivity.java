package ru.javabegin.training.android.money.activities;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.adapters.ItemAdapter;
import ru.javabegin.training.android.money.listview.adapters.SprNameAdapter;
import ru.javabegin.training.android.money.listview.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.listview.items.interfaces.Item;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.CurrencyItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.DateTimeItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.DescriptionItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperSourceItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperTypeItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperationItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.StorageItem;
import ru.javabegin.training.android.money.objects.AppContext;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

// активити для создания/редактирования операции 
public class OperationDetailsActivity extends AnimationActivity {

	public static final String SPR_LIST = "ru.javabegin.training.android.money.activities.sprList";

	private LinkedHashMap<String, AbstractSprItem> sprMap = new LinkedHashMap<String, AbstractSprItem>(); // выбранные

	private ListView lvSpr;
	private ListView lvItems;
	
	private ArrayList<ListItem> listSpr = new ArrayList<ListItem>();
	private ArrayList<Item> listItems = new ArrayList<Item>();
	
	private EditText txtAmount;

	private OperTypeItem operTypeItem = new OperTypeItem(false);
	private OperSourceItem operSourceItem = new OperSourceItem(operTypeItem);
	private CurrencyItem currencyItem = new CurrencyItem(false);
	private StorageItem storageItem = new StorageItem(false);
	
	private DescriptionItem descItem = new DescriptionItem();
	private DateTimeItem dateTimeItem = new DateTimeItem();

	private OperationItem operation;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_operation_details);

		txtAmount = (EditText) findViewById(R.id.txt_amount_input);

		lvSpr = (ListView) findViewById(R.id.list_metadata);
		lvItems = (ListView) findViewById(R.id.list_desc);

		sprMap.put(operTypeItem.getTableName(), operTypeItem);
		sprMap.put(operSourceItem.getTableName(), operSourceItem);
		sprMap.put(currencyItem.getTableName(), currencyItem);
		sprMap.put(storageItem.getTableName(), storageItem);

		listSpr.add(operTypeItem);
		listSpr.add(operSourceItem);
		listSpr.add(currencyItem);
		listSpr.add(storageItem);
		
		listItems.add(descItem);
		listItems.add(dateTimeItem);

		int id = getIntent().getIntExtra(AppContext.OPERATION_ID, 0);

		fillOperationData(id);

		operTypeItem.addListener(operSourceItem);
		lvSpr.setOnItemClickListener(new SprClickListener());
		lvItems.setOnItemClickListener(new ItemClickListener());
		
		
		
		lvSpr.setAdapter(new SprNameAdapter(this, listSpr));
		lvItems.setAdapter(new ItemAdapter(this, listItems));

	}

	private void fillOperationData(int id) {

		if (id <= 0) {// если не редактирование - пробуем получить последние выбранные значения
			if (DbItemCreator.getOperationDbItem().hasLastOperation()){
				selectLastItems();
			}
		}else{// если режим редактирования
			selectEditItems(id);
		}
		
		
	}
	
	private void selectEditItems(int id) {
		operTypeItem.setSelectedChildItem(DbItemCreator.getOperTypeDbItem().getItem(id));
		operSourceItem.setSelectedChildItem(DbItemCreator.getOperSourceDbItem().getItem(id));
		currencyItem.setSelectedChildItem(DbItemCreator.getCurrencyDbItem().getItem(id));
		storageItem.setSelectedChildItem(DbItemCreator.getStorageDbItem().getItem(id));
		descItem.setSelectedText(DbItemCreator.getDescDbItem().getItem(id).getSelectedText());
		dateTimeItem.setCalendar(DbItemCreator.getDatetimeDbItem().getItem(id).getCalendar());

		operation = DbItemCreator.getOperationDbItem().getItem(id);
		operation.setEditMode(true);
		
		txtAmount.setText(String.valueOf(operation.getAmount()));
	}

	private void selectLastItems() {
		operTypeItem.setSelectedChildItem(DbItemCreator.getOperTypeDbItem().getLastItem());
		operSourceItem.setSelectedChildItem(DbItemCreator.getOperSourceDbItem().getLastItem());
		currencyItem.setSelectedChildItem(DbItemCreator.getCurrencyDbItem().getLastItem());
		storageItem.setSelectedChildItem(DbItemCreator.getStorageDbItem().getLastItem());
		
		operation = DbItemCreator.getOperationDbItem().getLastItem();
		operation.setEditMode(false);

		txtAmount.setText(String.valueOf(operation.getAmount()));
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.operation_details, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {

		case R.id.save:
			if (operation == null) {
				operation = new OperationItem();
			}

			operation.setAmount(Double.valueOf(txtAmount.getText().toString()));
			operation.setOperTypeItem(operTypeItem);
			operation.setOperSourceItem(operSourceItem);
			operation.setStorageItem(storageItem);
			operation.setCurrencyItem(currencyItem);
			operation.setDescItem(descItem);
			operation.setDateTimeItem(dateTimeItem);
			
			operation.save();
			super.closeActivity();
			break;

		case R.id.delete:

			AlertDialog.Builder builder = new AlertDialog.Builder(
					OperationDetailsActivity.this);
			builder.setMessage(getResources()
					.getString(R.string.confirm_delete));
			builder.setTitle(getResources().getString(R.string.confirm_title));

			builder.setNegativeButton("NO",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							dialog.cancel();
						}
					});

			builder.setPositiveButton("YES",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {

							if (operation != null) {
								DbItemCreator.getOperationDbItem().deleteOperation(operation.getId());
							}
							OperationDetailsActivity.super.closeActivity();

							Toast.makeText(
									OperationDetailsActivity.this,
									getResources().getString(
											R.string.deleted_title),
									Toast.LENGTH_SHORT).show();
						}
					});

			builder.create().show();

			break;

		}

		return super.onOptionsItemSelected(item);
	}

	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);

		// если выбрано какое-то значение справочника
		if (intent.getExtras() != null && !intent.getExtras().isEmpty()) {

			AbstractSprItem selectedChildItem = (AbstractSprItem) intent
					.getSerializableExtra(AppContext.SELECTED_ITEM);

			AbstractSprItem parentItem = sprMap.get(selectedChildItem
					.getTableName());

			// если выбрали то же самое значение - ничего не делать
			if (parentItem.getSelectedChildItem() != null) {

				long selectedId = selectedChildItem.getId();

				long prevId = parentItem.getSelectedChildItem().getId();

				if (selectedId == prevId) {
					return;
				}

			}

			parentItem.setSelectedChildItem(selectedChildItem);

			((SprNameAdapter) lvSpr.getAdapter()).notifyDataSetChanged();

		}

	}

	
	// слушатель для выбора справочных значений
	private class SprClickListener implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {

			Item item = (Item) parent.getAdapter().getItem(position);
			startActivity(item.getIntent(OperationDetailsActivity.this));
			overridePendingTransition(R.anim.pull_in_right,
					R.anim.push_out_left);

		}

	}
	
	// слушатель для нестандартных 
	private class ItemClickListener implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {

			Item item = (Item) parent.getAdapter().getItem(position);
			
			switch (position) {
			case 0:
				startActivityForResult(item.getIntent(OperationDetailsActivity.this), DescriptionItem.REQUEST_CODE);
				break;

			case 1:
				startActivityForResult(item.getIntent(OperationDetailsActivity.this), DateTimeItem.REQUEST_CODE);
			}
			
			
			overridePendingTransition(R.anim.pull_in_right,
					R.anim.push_out_left);

		}

	}
	
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		
		if (resultCode == RESULT_OK){
			
			switch (requestCode) {
			case DescriptionItem.REQUEST_CODE:
				descItem.setSelectedText(data.getStringExtra(DescriptionItem.TEXT));
				((ItemAdapter) lvItems.getAdapter()).notifyDataSetChanged();
				break;
			case DateTimeItem.REQUEST_CODE:
				Calendar c = (Calendar)data.getSerializableExtra(AppContext.CALENDAR);
				dateTimeItem.setCalendar(c);
				((ItemAdapter) lvItems.getAdapter()).notifyDataSetChanged();
			}
			


		}
		
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		super.onSaveInstanceState(outState);
		// outState.putSerializable(SPR_LIST, sprNamesMap);
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onRestoreInstanceState(savedInstanceState);
		// sprNamesMap = (LinkedHashMap<String, SprNameItem>)
		// savedInstanceState.get(SPR_LIST);
	}
	



}
