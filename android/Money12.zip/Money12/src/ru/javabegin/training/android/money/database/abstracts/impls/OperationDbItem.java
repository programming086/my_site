package ru.javabegin.training.android.money.database.abstracts.impls;

import java.sql.Types;
import java.util.ArrayList;

import ru.javabegin.training.android.money.database.abstracts.AbstractDbListItem;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperationItem;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class OperationDbItem extends AbstractDbListItem<OperationItem> {

	private static final int TYPE_TRANSFER = 3;
	private static final int TYPE_OUTCOME = 2;
	private static final int TYPE_INCOME = 1;
	private OperationType operationType;

	public void setOperationType(OperationType operationType) {
		this.operationType = operationType;
	}

	@Override
	protected String getSqlListItem(OperationItem item) {
		StringBuilder builder = new StringBuilder();

		builder.append("select " + "t.name as " + ALIAS_TYPE + ",s.type_id as "
				+ ALIAS_TYPE_ID + ",o._id as " + ALIAS_ID + ",c.short_name as "
				+ ALIAS_CURRENCY + ",o.[amount] as " + ALIAS_AMOUNT
				+ ",o.[operation_datetime] as " + ALIAS_OPERATION_DATETIME
				+ ",s.[name] as " + ALIAS_SOURCE + ",o.[description] as "
				+ ALIAS_DESC + ",o.[source_id] as " + ALIAS_SOURCE_ID
				+ " from " + OPERATIONS_TABLE + " o " + " inner join "
				+ CURRENCY_TABLE + " c on o.currency_id=c.[_id]  "
				+ " inner join " + OPER_SOURCE_TABLE
				+ " s on o.source_id=s.[_id] " + " inner join "
				+ OPER_TYPE_TABLE + " t on s.type_id=t.[_id] ");

		if (operationType != OperationType.ALL) {
			builder.append(" where o.type_id=" + operationType.getId());
			builder.append(" order by o.operation_datetime desc");
		} else {
			builder.append(" order by o.operation_datetime desc");
		}

		return builder.toString();
	}

	@Override
	protected String getSql(long id) {

		StringBuilder builder = new StringBuilder();

		builder.append("select " + " o._id as " + ALIAS_ID + ", o.amount  as "
				+ ALIAS_AMOUNT + " from " + OPERATIONS_TABLE + " o "
				+ " where o._id=" + id);

		return builder.toString();
	}

	@Override
	protected String getSqlLastItem() {
		StringBuilder builder = new StringBuilder();

		builder.append("select " + " o._id as " + ALIAS_ID + ", o.amount  as "
				+ ALIAS_AMOUNT + " from " + LAST_OPERATION_TABLE + " o ");

		return builder.toString();
	}

	protected OperationItem fillItem(Cursor c) {
		OperationItem item = new OperationItem();
		item.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
		item.setAmount(c.getDouble(c.getColumnIndex(ALIAS_AMOUNT)));
		return item;
	}

	public boolean hasLastOperation() {
		return super.hasRows("select _id from " + LAST_OPERATION_TABLE);
	}

	private SQLiteDatabase db = null;

	public boolean saveOperation(OperationItem operation) {

		SQLiteStatement stmt1 = null;
		SQLiteStatement stmt2 = null;

		try {
			db = getDatabase();

			db.beginTransaction();

			// при сохранение или обновление операции также выполняется триггер

			stmt1 = createOperationStmt(operation);
			stmt1.execute();

			stmt2 = createBalanceStmt(operation);
			stmt2.execute();

			db.setTransactionSuccessful();

		} catch (Exception e) {
			Log.e(tag, e.getMessage());
			return false;
		} finally {
			if (stmt1 != null) {
				stmt1.close();
			}

			if (stmt2 != null) {
				stmt2.close();
			}

			db.endTransaction();
		}

		return true;
	}

	private SQLiteStatement createBalanceStmt(OperationItem operation) {

		SQLiteStatement stmt = null;

		// есть ли уже запись по этому хранилищу и валюте
		boolean recordExists = sqlExecutor.execSQL(
				"select _id from " + BALANCE_TABLE + " where currency_id="
						+ operation.getCurrencyItem().getSelectedChildItem().getId()
						+ " and storage_id="
						+ operation.getStorageItem().getSelectedChildItem().getId()).getCount() > 0;

		
		
		if (recordExists){
			stmt = db.compileStatement("update " + BALANCE_TABLE
					+ " set amount=? where storage_id=? and  currency_id=?");
			
		}else{
			stmt = db.compileStatement("insert into " + BALANCE_TABLE
					+ "(amount, storage_id, currency_id) values(?,?,?)");

		}
		
		
		stmt.bindLong(2, operation.getStorageItem().getSelectedChildItem().getId());
		stmt.bindLong(3, operation.getCurrencyItem().getSelectedChildItem().getId());
	
		double amount = 0;
		
		
		if (recordExists){
			amount = sqlExecutor.execFirstResult("select amount from "+BALANCE_TABLE+"  where currency_id="+ operation.getCurrencyItem().getSelectedChildItem().getId() + " and storage_id="+ operation.getStorageItem().getSelectedChildItem().getId()).getDouble(0);
		}
		
		
		// посчитать итоговую сумму
		switch (operation.getOperTypeItem().getSelectedChildItem().getId()) {
		case TYPE_INCOME:
			stmt.bindDouble(1, amount+operation.getAmount());
			break;

		case TYPE_OUTCOME:
			stmt.bindDouble(1, amount-operation.getAmount());
			break;

	

		default:
			break;
		}

	
		return stmt;

	}

	private SQLiteStatement createOperationStmt(OperationItem operation) {

		SQLiteStatement stmt = null;

		if (operation.isEditMode()) {
			stmt = db
					.compileStatement("update "
							+ OPERATIONS_TABLE
							+ " set operation_datetime=?, amount=?, currency_id=?, source_id=?, storage_id=?, type_id=?, description=? where _id=?");
			stmt.bindLong(8, operation.getId());

		} else {
			stmt = db
					.compileStatement("insert into "
							+ OPERATIONS_TABLE
							+ " (operation_datetime, amount, currency_id, source_id, storage_id, type_id,  description) values (?,?,?,?,?,?,?)");
		}

		long date = operation.getDateTimeItem().getCalendar().getTimeInMillis();

		stmt.bindLong(1, date);
		stmt.bindDouble(2, operation.getAmount());
		stmt.bindLong(3, operation.getCurrencyItem().getSelectedChildItem()
				.getId());
		stmt.bindLong(4, operation.getOperSourceItem().getSelectedChildItem()
				.getId());
		stmt.bindLong(5, operation.getStorageItem().getSelectedChildItem()
				.getId());
		stmt.bindLong(6, operation.getOperTypeItem().getSelectedChildItem()
				.getId());
		if (operation.getDescItem().getSelectedText() == null) {
			stmt.bindNull(7);
		} else {
			stmt.bindString(7, operation.getDescItem().getSelectedText());
		}

		if (operation.getDescItem().getSelectedText() == null) {
			stmt.bindNull(7);
		} else {
			stmt.bindString(7, operation.getDescItem().getSelectedText());
		}

		return stmt;

	}

	public boolean deleteOperation(int id) {
		SQLiteStatement stmt = null;
		try {
			SQLiteDatabase db = getDatabase();

			stmt = db.compileStatement("delete from " + OPERATIONS_TABLE
					+ " where _id=?");

			stmt.bindLong(1, id);
			stmt.execute();

			return true;

		} catch (Exception e) {
			Log.e(tag, e.getMessage());
		} finally {
			stmt.close();
		}

		return false;

	}

}
