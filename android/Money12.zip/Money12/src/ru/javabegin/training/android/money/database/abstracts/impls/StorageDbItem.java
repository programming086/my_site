package ru.javabegin.training.android.money.database.abstracts.impls;

import ru.javabegin.training.android.money.database.abstracts.AbstractDbListItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.StorageItem;
import android.database.Cursor;

public class StorageDbItem extends AbstractDbListItem<StorageItem> {



	@Override
	protected String getSqlListItem(StorageItem item) {
		StringBuilder builder = new StringBuilder();

		builder.append("select " + " c1._id as " + ALIAS_ID + ", c1.name  as "
				+ ALIAS_NAME + ", coalesce((select _id from "
				+ STORAGE_TABLE
				+ " c2 where c2.parent_id=c1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + " from " + STORAGE_TABLE + " c1 "
				+ " where coalesce(c1.parent_id,0) = " + item.getId()
				+ " order by order_show");

		return builder.toString();
	}

	@Override
	protected String getSql(long id) {

		StringBuilder builder = new StringBuilder();

		builder.append("select  s1._id as " + ALIAS_ID + ", s1.name  as "
				+ ALIAS_NAME + ", coalesce((select _id from " + STORAGE_TABLE
				+ " c2 where c2.parent_id=s1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + " from " + STORAGE_TABLE + " s1 "
				+ " where s1._id=(select storage_id from " + OPERATIONS_TABLE
				+ " o where o._id=" + id + ")");

		return builder.toString();
	}

	@Override
	protected String getSqlLastItem() {
		StringBuilder builder = new StringBuilder();
		builder.append("select " + " s1._id as " + ALIAS_ID + ", s1.name  as "
				+ ALIAS_NAME + ", coalesce((select _id from " + STORAGE_TABLE
				+ " c2 where c2.parent_id=s1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + " from " + STORAGE_TABLE + " s1 "
				+ " where s1._id=(select storage_id from "
				+ LAST_OPERATION_TABLE + ")");

		return builder.toString();
	}

	protected StorageItem fillItem(Cursor c) {
		StorageItem item = new StorageItem();
		item.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
		item.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));
		item.setHasChilds(super.getBooleanFromInt(c.getInt(c
				.getColumnIndex(ALIAS_HAS_CHILD))));
		return item;
	}

	
}
