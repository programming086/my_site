package ru.javabegin.training.android.money.listview.adapters;

import java.text.DateFormat;
import java.util.Calendar;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.OperationDbItem;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.objects.AppContext;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class OperationsAdapter extends CursorAdapter {
		
	private AppContext appContext;
	

	
	private Calendar calendar = Calendar.getInstance();
	
	public OperationsAdapter(Context context, Cursor c, boolean autoRequery) {
		super(context, c, autoRequery);
		this.appContext = (AppContext)context.getApplicationContext();
		layoutInflater = LayoutInflater.from(context);
	}

	private LayoutInflater layoutInflater;

	
	@Override
	public void bindView(View view, Context context, Cursor cursor) {
		ViewHolder holder = (ViewHolder) view.getTag();		
		
		holder.amount.setText(cursor.getString(cursor.getColumnIndex(OperationDbItem.ALIAS_AMOUNT)));
		holder.source.setText(cursor.getString(cursor.getColumnIndex(OperationDbItem.ALIAS_SOURCE)));
		holder.type.setText(" - ("+cursor.getString(cursor.getColumnIndex(OperationDbItem.ALIAS_TYPE))+")");
		holder.currency.setText(cursor.getString(cursor.getColumnIndex(OperationDbItem.ALIAS_CURRENCY)));
		
		
		String desc = cursor.getString(cursor.getColumnIndex(OperationDbItem.ALIAS_DESC));
		
		if (desc!=null && desc.length()>0){
			desc = (desc.length()<20)? desc : desc.substring(0,19)+" ...";
			holder.desc.setText(" ("+desc+") ");
			holder.desc.setVisibility(View.VISIBLE);
		}else{
			holder.desc.setVisibility(View.GONE);
		}
		
		
		
		
		String imageName = OperationDbItem.OPER_SOURCE_TABLE.toLowerCase()+ cursor.getInt(cursor.getColumnIndex(OperationDbItem.ALIAS_SOURCE_ID));
	
		try {
			holder.image.setImageBitmap(getImage(imageName));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		long dateTime = cursor.getLong(cursor.getColumnIndex(OperationDbItem.ALIAS_OPERATION_DATETIME));				
		calendar.setTimeInMillis(dateTime);		
		
		holder.date.setText(DateFormat.getDateInstance(DateFormat.MEDIUM).format(calendar.getTime())+", ");
		holder.time.setText(DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar.getTime()));
		
		
		if (cursor.getInt(cursor.getColumnIndex(OperationDbItem.ALIAS_TYPE_ID)) == Integer.valueOf(OperationType.INCOME.getId())){
			holder.type.setTextColor(context.getResources().getColor(R.color.green_dark));
		}else{
			holder.type.setTextColor(context.getResources().getColor(R.color.red_dark));
		}
	}

	

	@Override
	public View newView(Context context, Cursor cursor, ViewGroup parent) {

		View view = layoutInflater.inflate(R.layout.listview_item_operation, parent, false);		
		
		ViewHolder holder = new ViewHolder();
		holder.source = (TextView) view.findViewById(R.id.txt_oper_source);
		holder.date = (TextView) view.findViewById(R.id.txt_oper_date);
		holder.image = (ImageView) view.findViewById(R.id.img_source);
		holder.time = (TextView) view.findViewById(R.id.txt_oper_time);
		holder.amount = (TextView) view.findViewById(R.id.txt_oper_amount);
		holder.type = (TextView) view.findViewById(R.id.txt_oper_type);
		holder.currency = (TextView) view.findViewById(R.id.txt_oper_currency);
		holder.desc = (TextView) view.findViewById(R.id.txt_desc);

		view.setTag(holder);

		return view;

	}
	
	private Bitmap getImage(String name) {
		int imageId = appContext.getResources().getIdentifier(name, "drawable",	appContext.getPackageName());
	
		return BitmapFactory.decodeResource(appContext.getResources(), imageId);

	}
	


	
	static class ViewHolder {
		public TextView date;
		public ImageView image;
		public TextView time;
		public TextView amount;
		public TextView source;
		public TextView type;
		public TextView currency;
		public TextView desc;
	}
}
