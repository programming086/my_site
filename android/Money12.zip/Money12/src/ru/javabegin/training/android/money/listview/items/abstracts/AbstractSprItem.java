package ru.javabegin.training.android.money.listview.items.abstracts;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.activities.SelectValueActivity;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import ru.javabegin.training.android.money.objects.AppContext;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

// абстрактный класс для работы со справочными значениями
public abstract class AbstractSprItem implements ListItem {

	private static final long serialVersionUID = 1L;

	private boolean hasChilds;
	private boolean enable = true;// по-умолчанию элемент доступен

	private String tableName; // к какому типу справочника принадлежит

	// элемент (из spr_Metadata)

	protected AbstractSprItem() {
		// TODO Auto-generated constructor stub
	}

	protected AbstractSprItem getDefaultItem() {
		return DbItemCreator.getOperTypeDbItem().getDefaultItem();
	}

	private ListItem selectedChildItem;

	private int id;// выбранный id
	private String name;// выбранное значение

	@Override
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String getTitleText() {
		return AppContext.getInstance().getResources().getString(R.string.select)+ ": " + getName();
	}
	
	@Override
	public String getShortText() {
		return getSelectedText();
	}

	@Override
	public String getSelectedText() {
		if (getSelectedChildItem() != null) {
			return getName() + ": " + getSelectedChildItem().getName();
		}
		return null;
	}

	@Override
	public Bitmap getImage() {
		// иконку брать по id либо выбранного элемента (для корневого списка
		// справочников)
		// либо id текущего элемента (для списка справочников при выборе)
		int id = getSelectedChildItem() != null ? getSelectedChildItem()
				.getId() : getId();
		int imageId = AppContext
				.getInstance()
				.getResources()
				.getIdentifier(getTableName().toLowerCase() + id, "drawable",
						AppContext.getInstance().getPackageName());

		return BitmapFactory.decodeResource(AppContext.getInstance()
				.getResources(), imageId);
	}

	@Override
	public ListItem getSelectedChildItem() {
		return selectedChildItem;
	}

	public void setSelectedChildItem(ListItem selectedChildItem) {
		this.selectedChildItem = selectedChildItem;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	@Override
	public boolean hasChilds() {
		return hasChilds;
	}

	public void setHasChilds(boolean hasChilds) {
		this.hasChilds = hasChilds;
	}

	@Override
	public boolean isEnable() {
		return enable;
	}

	public void setEnabled(boolean enable) {
		this.enable = enable;
	}

	@Override
	public Intent getIntent(Context context) {
		Intent intent = new Intent(context, SelectValueActivity.class);
		intent.putExtra(AppContext.SELECTED_ITEM, this);
		return intent;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result
				+ ((tableName == null) ? 0 : tableName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AbstractSprItem other = (AbstractSprItem) obj;
		if (id != other.id)
			return false;
		if (tableName == null) {
			if (other.tableName != null)
				return false;
		} else if (!tableName.equals(other.tableName))
			return false;
		return true;
	}

	

	

}
