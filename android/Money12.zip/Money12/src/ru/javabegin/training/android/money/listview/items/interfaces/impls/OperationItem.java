package ru.javabegin.training.android.money.listview.items.interfaces.impls;

import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;

public class OperationItem {
	
	private int id;
	private boolean editMode;
	
	private OperTypeItem operTypeItem;
	private OperSourceItem operSourceItem;
	private StorageItem storageItem;
	private CurrencyItem currencyItem;
	private DescriptionItem descItem;
	private DateTimeItem dateTimeItem;
	
	private Double amount;

	public OperTypeItem getOperTypeItem() {
		return operTypeItem;
	}

	public void setOperTypeItem(OperTypeItem operTypeItem) {
		this.operTypeItem = operTypeItem;
	}

	public OperSourceItem getOperSourceItem() {
		return operSourceItem;
	}

	public void setOperSourceItem(OperSourceItem operSourceItem) {
		this.operSourceItem = operSourceItem;
	}

	public StorageItem getStorageItem() {
		return storageItem;
	}

	public void setStorageItem(StorageItem storageItem) {
		this.storageItem = storageItem;
	}

	public CurrencyItem getCurrencyItem() {
		return currencyItem;
	}

	public void setCurrencyItem(CurrencyItem currencyItem) {
		this.currencyItem = currencyItem;
	}
	
	public DescriptionItem getDescItem() {
		return descItem;
	}
	
	public void setDescItem(DescriptionItem descItem) {
		this.descItem = descItem;
	}


	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public boolean save() {
		return DbItemCreator.getOperationDbItem().saveOperation(this);
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	
	public DateTimeItem getDateTimeItem() {
		return dateTimeItem;
	}
	
	public void setDateTimeItem(DateTimeItem dateTimeItem) {
		this.dateTimeItem = dateTimeItem;
	}


	public boolean isEditMode() {
		return editMode;
	}
	
	public void setEditMode(boolean editMode) {
		this.editMode = editMode;
	}


}
