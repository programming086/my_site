package ru.javabegin.training.android.money.activities;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.adapters.ItemAdapter;
import ru.javabegin.training.android.money.listview.adapters.SprNameAdapter;
import ru.javabegin.training.android.money.listview.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.listview.items.interfaces.Item;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.DateTimeItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.DescriptionItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperationItem;
import ru.javabegin.training.android.money.listview.items.listeners.impls.ListenerRegistrator;
import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.OperationsManager;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

// активити для создания/редактирования операции 
public class OperationDetailsActivity extends AnimationActivity {

	public static final String SPR_LIST = "ru.javabegin.training.android.money.activities.sprList";

	private LinkedHashMap<String, AbstractSprItem> sprSavedMap = new LinkedHashMap<String, AbstractSprItem>(); // хранит
																												// выбранные
																												// значения

	private ListView lvSpr;
	private ListView lvItems;

	private ArrayList<ListItem> sprSelectList = new ArrayList<ListItem>();// для
																			// выбора
																			// справочных
																			// значений
	private ArrayList<Item> addInfoList = new ArrayList<Item>();// для хранения
																// данных,
																// введенныхz
																// вручную

	private EditText txtAmount;

	private OperationItem operationItem;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_operation_details);

		txtAmount = (EditText) findViewById(R.id.txt_amount_input);

		lvSpr = (ListView) findViewById(R.id.list_metadata);

		int id = getIntent().getIntExtra(AppContext.OPERATION_ID, 0);

		if (id > 0) {
			operationItem = OperationsManager.getInstance().getOperation(id);
			operationItem.setEditMode(true);
		} else {
			fillNewValues();
		}
		
		
		addListeners();
		DbItemCreator.getOperSourceDbItem().setOperTypeId(operationItem.getOperTypeItem().getId());		

		
		
		txtAmount.setText(String.valueOf(operationItem.getAmount()));
		
		sprSavedMap.put(operationItem.getOperTypeItem().getTableName(),
				operationItem.getOperTypeItem());
		sprSavedMap.put(operationItem.getOperSourceItem().getTableName(),
				operationItem.getOperSourceItem());

		sprSavedMap.put(operationItem.getCurrencyItem().getTableName(),
				operationItem.getCurrencyItem());
		sprSavedMap.put(operationItem.getStorageItem().getTableName(),
				operationItem.getStorageItem());

		sprSelectList.add(operationItem.getOperTypeItem());
		sprSelectList.add(operationItem.getOperSourceItem());
		sprSelectList.add(operationItem.getCurrencyItem());
		sprSelectList.add(operationItem.getStorageItem());

		addInfoList.add(operationItem.getDescItem());
		addInfoList.add(operationItem.getDateTimeItem());


		lvSpr.setOnItemClickListener(new SprClickListener());

		lvItems = (ListView) findViewById(R.id.list_desc);
		lvItems.setOnItemClickListener(new ItemClickListener());

		lvSpr.setAdapter(new SprNameAdapter(this, sprSelectList));
		lvItems.setAdapter(new ItemAdapter(this, addInfoList));

	}


	private void fillNewValues() {

		operationItem = new OperationItem();

		operationItem.setDescItem(new DescriptionItem());
		operationItem.setDateTimeItem(new DateTimeItem());

		if (DbItemCreator.getOperationDbItem().hasLastOperation()) { // пробуем получить последние выбранные значения
			selectLastItems();
		}		

	}

	
	@Override
	public void finish() {
		// TODO Auto-generated method stub
		super.finish();
		removeListeners();
	}
	
	private void removeListeners() {
		ListenerRegistrator.getInstance().removeListener(operationItem.getOperSourceItem());
		ListenerRegistrator.getInstance().removeListener(DbItemCreator.getOperSourceDbItem());				
	}

	
	private void addListeners(){
		ListenerRegistrator.getInstance().addListener(operationItem.getOperSourceItem());
		ListenerRegistrator.getInstance().addListener(DbItemCreator.getOperSourceDbItem());				
	}

	private void selectLastItems() {
		operationItem.setAmount(DbItemCreator.getOperationDbItem()
				.getLastItem().getAmount());
		operationItem.setCurrencyItem(DbItemCreator.getCurrencyDbItem()
				.getLastItem());
		operationItem.setOperSourceItem(DbItemCreator.getOperSourceDbItem()
				.getLastItem());
		operationItem.setOperTypeItem(DbItemCreator.getOperTypeDbItem()
				.getLastItem());
		operationItem.setStorageItem(DbItemCreator.getStorageDbItem()
				.getLastItem());
	}
	


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.operation_details, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {

		case R.id.save:

			 operationItem.setNewAmount(new BigDecimal(txtAmount.getText().toString()));
			 operationItem.save();
			 removeListeners();
			super.closeActivity();
			break;

		case R.id.delete:

			AlertDialog.Builder builder = new AlertDialog.Builder(
					OperationDetailsActivity.this);
			builder.setMessage(getResources()
					.getString(R.string.confirm_delete));
			builder.setTitle(getResources().getString(R.string.confirm_title));

			builder.setNegativeButton("NO",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							dialog.cancel();
						}
					});

			builder.setPositiveButton("YES",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {

							if (operationItem.isEditMode()) {
								removeListeners();
								DbItemCreator.getOperationDbItem()
										.deleteOperation(operationItem);
							}
							OperationDetailsActivity.super.closeActivity();
							

							Toast.makeText(
									OperationDetailsActivity.this,
									getResources().getString(
											R.string.deleted_title),
									Toast.LENGTH_SHORT).show();
						}
					});

			builder.create().show();

			break;

		}

		return super.onOptionsItemSelected(item);
	}

	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);

		// если выбрано какое-то значение справочника
		if (intent.getExtras() != null && !intent.getExtras().isEmpty()) {

			AbstractSprItem selectedChildItem = (AbstractSprItem) intent
					.getSerializableExtra(AppContext.SELECTED_ITEM);

			AbstractSprItem parentItem = sprSavedMap.get(selectedChildItem
					.getTableName());

			int selectedId = selectedChildItem.getId();
			int prevId = 0;

			// проверяем, выбрали новое значение или нет
			if (parentItem.getSelectedChildItem() != null) {
				prevId = parentItem.getSelectedChildItem().getId();
			}

			if (parentItem.getSelectedChildItem() == null) {
				prevId = parentItem.getId();
			}

			if (selectedId == prevId) {
				return;
			}

			parentItem.setSelectedChildItem(selectedChildItem);

			((SprNameAdapter) lvSpr.getAdapter()).notifyDataSetChanged();

		}

	}

	// слушатель для выбора справочных значений
	private class SprClickListener implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {

			Item item = (Item) parent.getAdapter().getItem(position);
			Intent intent = item.getIntent(OperationDetailsActivity.this);
			intent.putExtra(AppContext.SHOW_ROOT, true); // сначала показывать
															// корневые элементы
			startActivity(intent);
			overridePendingTransition(R.anim.pull_in_right,
					R.anim.push_out_left);

		}

	}

	// слушатель для изменения несправочных значений
	private class ItemClickListener implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {

			Item item = (Item) parent.getAdapter().getItem(position);

			switch (position) {
			case 0:
				startActivityForResult(
						item.getIntent(OperationDetailsActivity.this),
						DescriptionItem.REQUEST_CODE);
				break;

			case 1:
				startActivityForResult(
						item.getIntent(OperationDetailsActivity.this),
						DateTimeItem.REQUEST_CODE);
			}

			overridePendingTransition(R.anim.pull_in_right,
					R.anim.push_out_left);

		}

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == RESULT_OK) {

			switch (requestCode) {
			case DescriptionItem.REQUEST_CODE:
				operationItem.getDescItem().setDisplayText(
						data.getStringExtra(DescriptionItem.TEXT));
				((ItemAdapter) lvItems.getAdapter()).notifyDataSetChanged();
				break;
			case DateTimeItem.REQUEST_CODE:
				Calendar c = (Calendar) data
						.getSerializableExtra(AppContext.CALENDAR);
				operationItem.getDateTimeItem().setCalendar(c);
				((ItemAdapter) lvItems.getAdapter()).notifyDataSetChanged();
			}

		}

	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		super.onSaveInstanceState(outState);
		// outState.putSerializable(SPR_LIST, sprNamesMap);
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onRestoreInstanceState(savedInstanceState);
		// sprNamesMap = (LinkedHashMap<String, SprNameItem>)
		// savedInstanceState.get(SPR_LIST);
	}

}
