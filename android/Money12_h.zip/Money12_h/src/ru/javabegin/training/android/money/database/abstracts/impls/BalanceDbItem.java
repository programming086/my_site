package ru.javabegin.training.android.money.database.abstracts.impls;

import java.math.BigDecimal;

import ru.javabegin.training.android.money.database.abstracts.AbstractDbListItem;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.BalanceItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperationItem;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class BalanceDbItem extends AbstractDbListItem<BalanceItem> {
	
	protected BalanceDbItem() {}

	@Override
	protected String getAllItemsSQL() {
		StringBuilder builder = new StringBuilder();

		builder.append("select _id as "+ALIAS_ID+", currency_id as " + ALIAS_CURRENCY_ID+ ", "
				+ "storage_id as " + ALIAS_STORAGE_ID + ", " + "amount as "
				+ ALIAS_AMOUNT + " from " + BALANCE_TABLE +" where amount<>0"
				+ " order by storage_id desc");

		return builder.toString();
	}

	@Override
	protected BalanceItem fillItem(Cursor c) {
		BalanceItem balanceItem = new BalanceItem();
		balanceItem.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
		balanceItem.setAmount(BigDecimal.valueOf(c.getDouble(c.getColumnIndex(ALIAS_AMOUNT))));
		balanceItem.setCurrencyItem(DbItemCreator.getCurrencyDbItem().getOneItem(c.getInt(c.getColumnIndex(ALIAS_CURRENCY_ID))));
		balanceItem.setStorageItem(DbItemCreator.getStorageDbItem().getOneItem(c.getInt(c.getColumnIndex(ALIAS_STORAGE_ID))));
		return balanceItem;

	}

	
	public BigDecimal getBalanceAmount(int currencyId, int storageId) {
		BigDecimal amount = BigDecimal.valueOf(sqlExecutor.execFirstResult("select amount from " + BALANCE_TABLE + "  where currency_id="+ currencyId + " and storage_id=" + storageId).getDouble(0));
		return amount;
	}
	
	
	public boolean updateBalance(OperationItem item) {
		SQLiteStatement stmt = null;

		SQLiteDatabase db = null;
		
		try {
			
			db=getDatabase();

			// определяем нужные id
			int currencyId = item.getCurrencyItem().getSelectedChildItem() != null ? item
					.getCurrencyItem().getSelectedChildItem().getId()
					: item.getCurrencyItem().getId();
			int storageId = item.getStorageItem().getSelectedChildItem() != null ? item
					.getStorageItem().getSelectedChildItem().getId()
					: item.getStorageItem().getId();
			int operTypeId = item.getOperTypeItem().getSelectedChildItem() != null ? item
					.getOperTypeItem().getSelectedChildItem().getId()
					: item.getOperTypeItem().getId();

			// есть ли уже запись по этому хранилищу и валюте
			boolean recordExists = sqlExecutor.execSQL(
					"select _id from " + BALANCE_TABLE + " where currency_id="
							+ currencyId + " and storage_id=" + storageId)
					.getCount() > 0;

			if (recordExists) {
				stmt = db
						.compileStatement("update "
								+ BALANCE_TABLE
								+ " set amount=? where storage_id=? and  currency_id=?");

			} else {
				stmt = db.compileStatement("insert into " + BALANCE_TABLE
						+ "(amount, storage_id, currency_id) values(?,?,?)");

			}

			stmt.bindLong(2, storageId);
			stmt.bindLong(3, currencyId);

			BigDecimal amount = null;

			if (recordExists) {
				amount = DbItemCreator.getBalanceDbItem().getBalanceAmount(currencyId, storageId);// получить текущее значение баланса
			}else{
				amount = new BigDecimal(0);
			}

			// посчитать итоговую сумму
			switch (OperationType.getType(operTypeId)) {
			case INCOME:
				stmt.bindDouble(1,  amount.add(item.getNewAmount()).doubleValue());
				break;

			case OUTCOME:
				stmt.bindDouble(1, amount.subtract(item.getNewAmount()).doubleValue());
				break;
			}

			stmt.execute();

		} catch (Exception e) {
			Log.e(tag, e.getMessage());
			return false;
		}

		return true;

	}



	
	
	// вернуть значение баланса, которое было до этой операции
	public boolean revertBalance(int operTypeId, int currencyId, int storageId,
			BigDecimal newAmount) {

		SQLiteStatement stmt = null;

		SQLiteDatabase db = null;

		try {
			
			db=getDatabase();

			// получить последнее значение баланса
			BigDecimal oldAmount = DbItemCreator.getBalanceDbItem().getBalanceAmount(currencyId, storageId);

			OperationType operationType = OperationType.getType(operTypeId);

			if (operationType == OperationType.INCOME) {
				oldAmount = oldAmount.subtract(newAmount);// при удалении дохода -
													// отнимаем сумму
			} else if (operationType == OperationType.OUTCOME) {
				oldAmount = oldAmount.add(newAmount);// при удалении расхода -
													// прибавляем сумму
			}

			stmt = db.compileStatement("update " + BALANCE_TABLE
					+ " set amount=? where storage_id=? and  currency_id=?");

			stmt.bindDouble(1, oldAmount.doubleValue());
			stmt.bindLong(2, storageId);
			stmt.bindLong(3, currencyId);

			stmt.execute();

		} catch (Exception e) {
			Log.e(tag, e.getMessage());
			return false;
		} finally {
			if (stmt != null) {
				stmt.close();
			}
		}

		return true;

	}
}
