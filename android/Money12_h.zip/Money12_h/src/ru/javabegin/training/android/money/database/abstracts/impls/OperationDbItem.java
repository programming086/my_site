package ru.javabegin.training.android.money.database.abstracts.impls;

import java.math.BigDecimal;

import ru.javabegin.training.android.money.database.abstracts.AbstractDbListItem;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperationItem;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class OperationDbItem extends AbstractDbListItem<OperationItem> {

	protected OperationDbItem() {
	}

	private OperationType operationType;

	public void setOperationType(OperationType operationType) {
		this.operationType = operationType;
	}

	@Override
	protected String getAllItemsSQL() {
		StringBuilder builder = new StringBuilder();

		builder.append("select " + "o.currency_id as " + ALIAS_CURRENCY_ID
				+ ",t.name as " + ALIAS_TYPE_NAME + ",s.type_id as "
				+ ALIAS_TYPE_ID + ",o._id as " + ALIAS_ID + ",c.short_name as "
				+ ALIAS_CURRENCY + ",o.[amount] as " + ALIAS_AMOUNT
				+ ",o.[operation_datetime] as " + ALIAS_OPERATION_DATETIME
				+ ",o.[storage_id] as " + ALIAS_STORAGE_ID + ",s.[name] as "
				+ ALIAS_SOURCE + ",o.[description] as " + ALIAS_DESC
				+ ",o.[source_id] as " + ALIAS_SOURCE_ID + " from "
				+ OPERATIONS_TABLE + " o " + " inner join " + CURRENCY_TABLE
				+ " c on o.currency_id=c.[_id]  " + " inner join "
				+ OPER_SOURCE_TABLE + " s on o.source_id=s.[_id] "
				+ " inner join " + OPER_TYPE_TABLE + " t on s.type_id=t.[_id] ");

		if (operationType != OperationType.ALL) {
			builder.append(" where o.type_id=" + operationType.getId());
			builder.append(" order by o.operation_datetime desc");
		} else {
			builder.append(" order by o.operation_datetime desc");
		}

		return builder.toString();
	}

	@Override
	protected String getOneItemSQL(int itemId) {

		StringBuilder builder = new StringBuilder();

		builder.append("select " + " o._id as " + ALIAS_ID + ", o.amount  as "
				+ ALIAS_AMOUNT + " from " + OPERATIONS_TABLE + " o "
				+ " where o._id=" + itemId);

		builder.append("select " + "o.currency_id as " + ALIAS_CURRENCY_ID
				+ ",o.type_id as " + ALIAS_TYPE_ID + ",o._id as " + ALIAS_ID
				+ "," + "o.[amount] as " + ALIAS_AMOUNT
				+ ",o.[operation_datetime] as " + ALIAS_OPERATION_DATETIME
				+ ",o.[storage_id] as " + ALIAS_STORAGE_ID
				+ ",o.[description] as " + ALIAS_DESC + ",o.[source_id] as "
				+ ALIAS_SOURCE_ID + " from " + OPERATIONS_TABLE
				+ " o where o._id=" + itemId);

		return builder.toString();
	}

	@Override
	protected String getLastItemSQL() {
		StringBuilder builder = new StringBuilder();

		builder.append("select " + "o.currency_id as " + ALIAS_CURRENCY_ID
				+ ",o.type_id as " + ALIAS_TYPE_ID + ",o._id as " + ALIAS_ID
				+ "," + "o.[amount] as " + ALIAS_AMOUNT
				+ ",o.[operation_datetime] as " + ALIAS_OPERATION_DATETIME
				+ ",o.[storage_id] as " + ALIAS_STORAGE_ID
				+ ",o.[source_id] as " + ALIAS_SOURCE_ID + " from "
				+ LAST_OPERATION_TABLE + " o");

		return builder.toString();
	}

	protected OperationItem fillItem(Cursor c) {
		OperationItem item = new OperationItem();
		item.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
		item.setAmount(BigDecimal.valueOf(c.getDouble(c.getColumnIndex(ALIAS_AMOUNT))));
		item.setCurrencyItem(DbItemCreator.getCurrencyDbItem().getOneItem(
				c.getInt(c.getColumnIndex(ALIAS_CURRENCY_ID))));
		item.setDateTimeItem(DbItemCreator.getDatetimeDbItem().getOneItem(
				item.getId()));
		item.setDescItem(DbItemCreator.getDescDbItem().getOneItem(item.getId()));
		item.setOperSourceItem(DbItemCreator.getOperSourceDbItem().getOneItem(
				c.getInt(c.getColumnIndex(ALIAS_SOURCE_ID))));			
		item.setOperTypeItem(DbItemCreator.getOperTypeDbItem().getOneItem(
				c.getInt(c.getColumnIndex(ALIAS_TYPE_ID))));
		item.setStorageItem(DbItemCreator.getStorageDbItem().getOneItem(
				c.getInt(c.getColumnIndex(ALIAS_STORAGE_ID))));

		return item;
	}

	public boolean hasLastOperation() {
		return super.hasRows("select _id from " + LAST_OPERATION_TABLE);
	}

	private SQLiteDatabase db = null;

	public boolean saveOperation(OperationItem operationItem) {

		boolean success = false;

		try {
			db = getDatabase();

			db.beginTransaction();

			// создаем или обновляем операцию (в базе данных также работает триггер)
			success = createOperation(operationItem);

			// обновляем данные по балансу
			success = checkBalance(operationItem);

			if (success) {// если все операции прошли успешно
				db.setTransactionSuccessful();
			}

		} catch (Exception e) {
			Log.e(tag, e.getMessage());
			return false;
		} finally {
			db.endTransaction();
		}

		return success;
	}

	private boolean checkBalance(OperationItem item) {

		boolean success = false;

		if (item.isEditMode()) { // если режим редактирования

			int oldCurrencyId = item.getCurrencyItem().getId();
			int oldStorageId = item.getStorageItem().getId();

			int operTypeId = item.getOperTypeItem().getId();

			// возвращаем значение баланса, которое было до этой операции
			success = DbItemCreator.getBalanceDbItem().revertBalance(operTypeId, oldCurrencyId, oldStorageId, item.getAmount());
		}
		success = DbItemCreator.getBalanceDbItem().updateBalance(item);

		return success;

	}
	
	


	private boolean createOperation(OperationItem operation) {

		SQLiteStatement stmt = null;

		try {

			if (operation.isEditMode()) {
				stmt = db
						.compileStatement("update "
								+ OPERATIONS_TABLE
								+ " set operation_datetime=?, amount=?, currency_id=?, source_id=?, storage_id=?, type_id=?, description=? where _id=?");
				stmt.bindLong(8, operation.getId());

			} else {
				stmt = db
						.compileStatement("insert into "
								+ OPERATIONS_TABLE
								+ " (operation_datetime, amount, currency_id, source_id, storage_id, type_id,  description) values (?,?,?,?,?,?,?)");
			}

			long date = operation.getDateTimeItem().getCalendar()
					.getTimeInMillis();

			// если есть измененные значения - берем их
			int currencyId = operation.getCurrencyItem().getSelectedChildItem() != null ? operation
					.getCurrencyItem().getSelectedChildItem().getId()
					: operation.getCurrencyItem().getId();
			int operSourceId = operation.getOperSourceItem()
					.getSelectedChildItem() != null ? operation
					.getOperSourceItem().getSelectedChildItem().getId()
					: operation.getOperSourceItem().getId();
			int storageId = operation.getStorageItem().getSelectedChildItem() != null ? operation
					.getStorageItem().getSelectedChildItem().getId()
					: operation.getStorageItem().getId();
			int operTypeId = operation.getOperTypeItem().getSelectedChildItem() != null ? operation
					.getOperTypeItem().getSelectedChildItem().getId()
					: operation.getOperTypeItem().getId();

			stmt.bindLong(1, date);
			stmt.bindDouble(2, operation.getNewAmount().doubleValue());
			stmt.bindLong(3, currencyId);
			stmt.bindLong(4, operSourceId);
			stmt.bindLong(5, storageId);
			stmt.bindLong(6, operTypeId);

			if (operation.getDescItem().getDisplayText() == null) {
				stmt.bindNull(7);
			} else {
				stmt.bindString(7, operation.getDescItem().getDisplayText());
			}

			stmt.execute();

		} catch (Exception e) {
			Log.e(tag, e.getMessage());
			return false;
		}

		return true;

	}

	// удалить операцию и обновить баланс
	public boolean deleteOperation(OperationItem operationItem) {

		boolean success = false; // хранит, все ли операции завершились удачно

		try {

			db = getDatabase();

			db.beginTransaction();

			// сначала удаляем саму операцию, потом обновлям баланс
			success = deleteOperation(operationItem.getId());

			// при обновлении баланса выбираем базовые значения (до
			// редактирования)
			int operTypeId = operationItem.getOperTypeItem().getId();
			int storageId = operationItem.getStorageItem().getId();
			int currencyId = operationItem.getCurrencyItem().getId();
			BigDecimal amount = operationItem.getAmount();

			success = DbItemCreator.getBalanceDbItem().revertBalance(operTypeId, currencyId, storageId, amount);

			if (success) { // если все операции завершили удачно
				db.setTransactionSuccessful();
			}

		} catch (Exception e) {
			Log.e(tag, e.getMessage());
			return false;
		} finally {
			db.endTransaction();
		}

		return success;

	}

	private boolean deleteOperation(int operationId) {
		SQLiteStatement stmt = null;
		try {

			stmt = db.compileStatement("delete from " + OPERATIONS_TABLE
					+ " where _id=?");
			stmt.bindLong(1, operationId);
			stmt.execute();
		} catch (Exception e) {
			Log.e(tag, e.getMessage());
			return false;
		} finally {
			if (stmt != null) {
				stmt.close();
			}
		}

		return true;
	}

	

}
