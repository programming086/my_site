package ru.javabegin.training.android.money.fragments;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.activities.OperationDetailsActivity;
import ru.javabegin.training.android.money.listview.adapters.SprValueAdapter;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import ru.javabegin.training.android.money.objects.AppContext;
import android.app.ListFragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

// список всех общих справочников (для каждого из них пользователь будет выбирать значение)
public class SprListFragment extends ListFragment {
	
	private Intent intentOperDetailsActivity;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		intentOperDetailsActivity = new Intent(getActivity(), OperationDetailsActivity.class);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);

		ListItem item = (ListItem) getArguments().getSerializable(AppContext.SELECTED_ITEM);
		boolean showRoot = getArguments().getBoolean(AppContext.SHOW_ROOT);

		
		if (showRoot){ // первые раз нужно показать корневые элементы
			setListAdapter(new SprValueAdapter(getActivity(), item.getRootItems()));
		} else if (item != null) { //  дальше выбираем значения
			setListAdapter(new SprValueAdapter(getActivity(), item.getChildItems()));
		}
		
	}

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {

		ListItem item = ((ListItem) l.getAdapter().getItem(position));		

		if (item.hasChilds()) {

			// если у справочного значения есть дочерние пункты - открываем их
			startActivity(item.getIntent(getActivity()));
			getActivity().overridePendingTransition(R.anim.pull_in_right, R.anim.push_out_left);
			
		}else{ 
//			intentOperationDetails.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			intentOperDetailsActivity.putExtra(AppContext.SELECTED_ITEM, item);			
			startActivity(intentOperDetailsActivity);
			getActivity().overridePendingTransition(R.anim.pull_in_left, R.anim.push_out_right);
			
			
		}
	
	}


}
