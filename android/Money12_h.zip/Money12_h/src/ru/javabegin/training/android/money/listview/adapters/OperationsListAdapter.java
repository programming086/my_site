package ru.javabegin.training.android.money.listview.adapters;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.OperationDbItem;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperationItem;
import ru.javabegin.training.android.money.objects.AppContext;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class OperationsListAdapter extends ArrayAdapter<OperationItem> {

	private AppContext appContext;

	private Context context;
	private Calendar calendar = Calendar.getInstance();

	private ArrayList<OperationItem> operationList;

	public OperationsListAdapter(Context context,
			ArrayList<OperationItem> operationList) {
		super(context, R.layout.balance_item_value, operationList);
		this.context = context;
		this.operationList = operationList;
	}

	public View getView(int position, View convertView, ViewGroup parent) {

		if (convertView == null) {

			ViewHolder holder = new ViewHolder();

			LayoutInflater inflater = (LayoutInflater) getContext()
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(R.layout.listview_item_operation, parent,
					false);

			holder.source = (TextView) convertView
					.findViewById(R.id.txt_oper_source);
			holder.date = (TextView) convertView
					.findViewById(R.id.txt_oper_date);
			holder.image = (ImageView) convertView
					.findViewById(R.id.img_source);
			holder.time = (TextView) convertView
					.findViewById(R.id.txt_oper_time);
			holder.amount = (TextView) convertView
					.findViewById(R.id.txt_oper_amount);
			holder.type = (TextView) convertView
					.findViewById(R.id.txt_oper_type);
			holder.currency = (TextView) convertView
					.findViewById(R.id.txt_oper_currency);
			holder.desc = (TextView) convertView.findViewById(R.id.txt_desc);

			convertView.setTag(holder);
		}

		ViewHolder holder = (ViewHolder) convertView.getTag();

		OperationItem item = getItem(position);

		holder.amount.setText(String.valueOf(item.getAmount()));
		holder.source.setText(item.getOperSourceItem().getName());
		holder.type.setText(" - (" + item.getOperTypeItem().getName() + ")");
		holder.currency.setText(item.getCurrencyItem().getShortName());

		String desc = item.getDescItem().getDisplayText();

		if (desc != null && desc.length() > 0) {
			desc = (desc.length() < 20) ? desc : desc.substring(0, 19) + " ...";
			holder.desc.setText(" (" + desc + ") ");
			holder.desc.setVisibility(View.VISIBLE);
		} else {
			holder.desc.setVisibility(View.GONE);
		}

		String imageName = OperationDbItem.OPER_SOURCE_TABLE.toLowerCase()+ item.getOperSourceItem().getId();
		
		try {
			holder.image.setImageBitmap(getImage(imageName));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		
		holder.date.setText(DateFormat.getDateInstance(DateFormat.MEDIUM).format(item.getDateTimeItem().getCalendar().getTime())+", ");
		holder.time.setText(DateFormat.getTimeInstance(DateFormat.SHORT).format(item.getDateTimeItem().getCalendar().getTime()));
		
		
		if (item.getOperTypeItem().getId() == Integer.valueOf(OperationType.INCOME.getId())){
			holder.type.setTextColor(context.getResources().getColor(R.color.green_dark));
		}else{
			holder.type.setTextColor(context.getResources().getColor(R.color.red_dark));
		}

		return convertView;
	}

	private Bitmap getImage(String name) {
		int imageId = context.getResources().getIdentifier(name, "drawable",
				context.getPackageName());
		return BitmapFactory.decodeResource(context.getResources(), imageId);
	}

	static class ViewHolder {
		public TextView date;
		public ImageView image;
		public TextView time;
		public TextView amount;
		public TextView source;
		public TextView type;
		public TextView currency;
		public TextView desc;
	}

	@Override
	public OperationItem getItem(int position) {
		return operationList.get(position);
	}
	
	public void update(ArrayList<OperationItem> operationList){
		this.operationList.clear();
		this.operationList.addAll(operationList);
		
		notifyDataSetChanged();
		
	}
}
