package ru.javabegin.training.android.money.listview.adapters;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import ru.javabegin.training.android.money.objects.AppContext;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;


public class SprNameAdapter extends AbstractAdapter<ListItem> {

	private static final long serialVersionUID = 1L;

	public SprNameAdapter(Context context, ArrayList<ListItem> objects) {
		super(context, objects);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		convertView = getView(convertView, parent);

		ViewHolder holder = (ViewHolder) convertView.getTag();

		ListItem item = (ListItem) getItem(position);

		Bitmap bitmap = null;

		holder.txtSprName.setTextColor(Color.BLACK);
		
		if (item.getSelectedChildItem() != null) { // выбрано новое значение

			holder.txtSprName.setText(item.getSelectTitle() +": " + item.getSelectedChildItem().getName());

			bitmap = item.getImage();

		} else if (item.getId() > 0) { // загруженное ранее значение  (при редактировании)
			holder.txtSprName.setText(item.getSelectTitle() +": " +item.getName());
			bitmap = item.getImage();
			
		} else {// ничего не выбрано
			holder.txtSprName.setTextColor(Color.GRAY);
			bitmap = super.getNoIconImage();
			holder.txtSprName.setText(item.getSelectTitle());
		}

		if (bitmap != null) {
			holder.image.setImageBitmap(bitmap);
		}

		return convertView;
	}


}
