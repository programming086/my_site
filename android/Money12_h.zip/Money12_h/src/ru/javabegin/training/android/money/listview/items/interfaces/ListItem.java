package ru.javabegin.training.android.money.listview.items.interfaces;

import java.util.ArrayList;

public interface ListItem extends Item{
	
	ArrayList<ListItem> getChildItems();
	
	ArrayList<ListItem> getRootItems();

	boolean hasChilds();
	
	String getTableName();

	ListItem getSelectedChildItem();
	
	String getName();
	
	int getId();
	
}
