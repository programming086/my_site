package ru.javabegin.training.android.money.listview.items.interfaces.impls;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.activities.DescriptionActivity;
import ru.javabegin.training.android.money.listview.items.interfaces.Item;
import ru.javabegin.training.android.money.objects.AppContext;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class DescriptionItem implements Item {

	private static final String ICON_NAME = "note";

	private static final long serialVersionUID = 1L;

	public static final int REQUEST_CODE = 1;
	public static final String TEXT = "ru.javabegin.training.android.money.objects.items.impl.text";

	private String displayText;


	@Override
	public Intent getIntent(Context context) {
		Intent intent = new Intent(context, DescriptionActivity.class);
		intent.putExtra(TEXT, displayText);
		return intent;
	}

	@Override
	public boolean isEnable() {
		return true;
	}

	@Override
	public Bitmap getImage() {
		int imageId = AppContext
				.getInstance()
				.getResources()
				.getIdentifier(ICON_NAME, "drawable",
						AppContext.getInstance().getPackageName());

		return BitmapFactory.decodeResource(AppContext.getInstance()
				.getResources(), imageId);
	}

	@Override
	public String getDisplayText() {
		return (displayText!=null && displayText.length()>0)?getShortText():null;
	}

	@Override
	public String getSelectTitle() {
		return AppContext.getInstance().getResources().getString(R.string.desc);
	}

	private String getShortText() {

		if (displayText == null) {
			return null;
		}

		String text = displayText.split("\n")[0];

		text = text.length() > 20 ? text.substring(0, 19).trim() + " ..."
				: text.trim();
		return text;

	}

	public void setDisplayText(String text) {
		this.displayText = text;
	}


	
	

}
