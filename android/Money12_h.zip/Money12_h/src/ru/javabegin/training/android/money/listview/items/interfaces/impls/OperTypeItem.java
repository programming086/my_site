package ru.javabegin.training.android.money.listview.items.interfaces.impls;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import ru.javabegin.training.android.money.listview.items.listeners.ChangeOperTypeListener;
import ru.javabegin.training.android.money.listview.items.listeners.ChangeOperTypeNotifier;
import ru.javabegin.training.android.money.listview.items.listeners.impls.ListenerRegistrator;
import ru.javabegin.training.android.money.objects.AppContext;

public class OperTypeItem extends AbstractSprItem implements ChangeOperTypeNotifier{
	
	private static final long serialVersionUID =  1L;
	
	public static final String TABLE_NAME = "spr_OperationType";

	public OperTypeItem() {
		setTableName(TABLE_NAME);
		setName(AppContext.getInstance().getResources().getString(R.string.operation_type));
		
	}
	
	
	@Override
	public ArrayList<ListItem> getChildItems(){
		return new ArrayList<ListItem>(DbItemCreator.getOperTypeDbItem().getChildItems(getId()));
	}
	
	
	@Override
	public ArrayList<ListItem> getRootItems(){
		return new ArrayList<ListItem>(DbItemCreator.getOperTypeDbItem().getRootItems());
	}
	
	
	@Override
	public void setSelectedChildItem(ListItem selectedChildItem) {		
		super.setSelectedChildItem(selectedChildItem);		
		notifyListeners();
	}


	@Override
	public void notifyListeners() {
		int id = getSelectedChildItem()!=null?getSelectedChildItem().getId():getId();
		for (ChangeOperTypeListener listener : ListenerRegistrator.getInstance().getListeners()) {
			listener.notifyItemSelected(id);
		}
		
	}
	

	@Override
	public String getSelectTitle() {
		return AppContext.getInstance().getResources().getString(R.string.operation_type);
	}

	
}
