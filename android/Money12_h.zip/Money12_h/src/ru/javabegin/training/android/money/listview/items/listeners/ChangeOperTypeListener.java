package ru.javabegin.training.android.money.listview.items.listeners;


// слушатель события
public interface ChangeOperTypeListener {
	void notifyItemSelected(int id); 
}
