package ru.javabegin.training.android.money.listview.items.listeners;


public interface ChangeOperTypeNotifier {
	void notifyListeners();
}
