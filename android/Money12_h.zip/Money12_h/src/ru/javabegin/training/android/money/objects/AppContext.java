package ru.javabegin.training.android.money.objects;

import android.app.Application;

public class AppContext extends Application {

	public static final int IMAGE_WIDTH_THMB = 64;
	public static final int IMAGE_HEIGHT_THMB = 64;
	
	public static final String OPERATION_ID = "ru.javabegin.training.android.money.objects.appContext.operationId";
	
	public static final String SELECTED_ITEM = "ru.javabegin.training.android.money.objects.appContext.selectedItem";
	
	public static final String SHOW_ROOT = "ru.javabegin.training.android.money.objects.appContext.showRoot";
	
	public static final String CALENDAR = "ru.javabegin.training.android.money.objects.appContext.calendar";
	
	 private static AppContext context;
	
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		context = this;
	}

	
	
	public static AppContext getInstance(){
		return context;
	}
	
	

}
