package ru.javabegin.training.android.money.database.abstracts.impls;

import ru.javabegin.training.android.money.database.abstracts.AbstractDbListItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperSourceItem;
import ru.javabegin.training.android.money.listview.items.listeners.ChangeOperTypeListener;
import android.database.Cursor;

public class OperSourceDbItem extends AbstractDbListItem<OperSourceItem> implements ChangeOperTypeListener{
	
	private int operTypeId;
	
	protected OperSourceDbItem() {}

	@Override
	protected String getChildItemsSQL(int id) {
		StringBuilder builder = new StringBuilder();
				
		builder.append("select " + " s1._id as " + ALIAS_ID
				+ ", s1.name  as " + ALIAS_NAME
				+ ", coalesce((select _id from " + OPER_SOURCE_TABLE
				+ " s2 where s2.parent_id=s1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + " from " + OPER_SOURCE_TABLE + " s1 "
				+ " where type_id="+operTypeId);

		builder.append(" and coalesce(s1.parent_id,0) = " + id);
		return builder.toString();
	}

	@Override
	protected String getRootItemsSQL() {
		StringBuilder builder = new StringBuilder();
		
		builder.append("select " + " s1._id as " + ALIAS_ID
				+ ", s1.name  as " + ALIAS_NAME
				+ ", coalesce((select _id from " + OPER_SOURCE_TABLE
				+ " s2 where s2.parent_id=s1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + " from " + OPER_SOURCE_TABLE + " s1 "
				+ " where type_id="+operTypeId);

		builder.append(" and coalesce(s1.parent_id,0) = 0");
		return builder.toString();
	}

	@Override
	public String getOneItemSQL(int itemId) {

		StringBuilder builder = new StringBuilder();

		builder.append("select "
				+ " s1._id as "
				+ ALIAS_ID
				+ ", s1.name  as "
				+ ALIAS_NAME
				+ ", coalesce((select _id from "
				+ OPER_SOURCE_TABLE
				+ " s2 where s2.parent_id=s1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD
				+ " from "
				+ OPER_SOURCE_TABLE
				+ " s1 "
				+ " where s1._id="+itemId);


		return builder.toString();
	}

	@Override
	protected String getLastItemSQL() {
		StringBuilder builder = new StringBuilder();
		builder.append("select "
				+ " s1._id as "
				+ ALIAS_ID
				+ ", s1.name  as "
				+ ALIAS_NAME
				+ ", coalesce((select _id from "
				+ OPER_SOURCE_TABLE
				+ " s2 where s2.parent_id=s1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD
				+ " from "
				+ OPER_SOURCE_TABLE
				+ " s1 "
				+ " where s1._id=(select source_id from "+LAST_OPERATION_TABLE+")");

		return builder.toString();
	}

	protected OperSourceItem fillItem(Cursor c) {
		OperSourceItem item = new OperSourceItem();
		item.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
		item.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));
		item.setHasChilds(super.getBooleanFromInt(c.getInt(c.getColumnIndex(ALIAS_HAS_CHILD))));		
		return item;
	}
	

	@Override
	public void notifyItemSelected(int id) {
		operTypeId = id;		
	}
	
	public void setOperTypeId(int operTypeId) {
		this.operTypeId = operTypeId;
	}
	
	public int getOperTypeId() {
		return operTypeId;
	}
	
}
