package ru.javabegin.training.android.money.listview.items.abstracts;

import java.util.ArrayList;

import ru.javabegin.training.android.money.activities.OperationDetailsActivity;
import ru.javabegin.training.android.money.activities.SelectValueActivity;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.enums.ItemType;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import ru.javabegin.training.android.money.objects.AppContext;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

// абстрактный класс для работы со справочными значениями
public abstract class AbstractSprItem implements ListItem {

	private static final long serialVersionUID = 1L;

	private boolean hasChilds;

	private ItemType itemType = ItemType.CHILD;
	
	private String tableName; // к какому типу справочника принадлежит
	
	protected AbstractSprItem() {
		// TODO Auto-generated constructor stub
	}
	


	protected AbstractSprItem getDefaultItem() {
		return DbItemCreator.getOperTypeDbItem().getDefaultItem();
	}

	private ListItem selectedChildItem;

	private int id;// выбранный id
	private String name;// выбранное значение

	@Override
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	

	@Override
	public String getDisplayText() {
		if (getSelectedChildItem() != null) {
			return getName() + ": " + getSelectedChildItem().getName();
		}
		return null;
	}
	
	public void updateIntents(Intent clickIntent, Intent resultIntent){
		setClickIntent(clickIntent);
		setResultIntent(resultIntent);
	}

	@Override
	public Bitmap getImage() {
		// иконку брать по id либо выбранного элемента (для корневого списка
		// справочников)
		// либо id текущего элемента (для списка справочников при выборе)
		int id = getSelectedChildItem() != null ? getSelectedChildItem()
				.getId() : getId();
		int imageId = AppContext
				.getInstance()
				.getResources()
				.getIdentifier(getTableName().toLowerCase() + id, "drawable",
						AppContext.getInstance().getPackageName());

		return BitmapFactory.decodeResource(AppContext.getInstance()
				.getResources(), imageId);
	}

	@Override
	public ListItem getSelectedChildItem() {
		return selectedChildItem;
	}

	public void setSelectedChildItem(ListItem selectedChildItem) {
		this.selectedChildItem = selectedChildItem;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	@Override
	public boolean hasChilds() {
		return hasChilds;
	}

	public void setHasChilds(boolean hasChilds) {
		this.hasChilds = hasChilds;
	}


	
	
	
	
	private transient Intent clickIntent;
	private transient Intent resultIntent;
	
	// по-умолчанию что делать при редактировании или открытии элемента
	@Override
	public Intent getClickIntent() {
		if (clickIntent != null) {
			clickIntent.putExtra(AppContext.SELECTED_ITEM, this);
		}
		return clickIntent;
	}
	
	public void setClickIntent(Intent clickIntent) {
		this.clickIntent = clickIntent;
	}
	
	@Override
	public Intent getResultIntent() {
		if (resultIntent!=null){
			resultIntent.putExtra(AppContext.SELECTED_ITEM, this);
		}
		return resultIntent;
	}
	
	public void setResultIntent(Intent resultIntent) {
		this.resultIntent = resultIntent;
	}

	
	protected Intent getOperDetailsIntent(){
		return new Intent(AppContext.getInstance(), OperationDetailsActivity.class);
	}
	
	protected Intent getSelectValueIntent(){
		return new Intent(AppContext.getInstance(), SelectValueActivity.class);
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result
				+ ((tableName == null) ? 0 : tableName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AbstractSprItem other = (AbstractSprItem) obj;
		if (id != other.id)
			return false;
		if (tableName == null) {
			if (other.tableName != null)
				return false;
		} else if (!tableName.equals(other.tableName))
			return false;
		return true;
	}

	@Override
	public ArrayList<ListItem> getChildItems(){ 
		return null;
	}
	
	@Override
	public ArrayList<ListItem> getRootItems() {
		return null;
	}
	
	@Override
	public ItemType getItemType() {
		return itemType;
	}
	
	public void setItemType(ItemType itemType) {
		this.itemType = itemType;
	}
	
	@Override
	public String getSelectTitle() {
		return null;
	}

}
