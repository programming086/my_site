package ru.javabegin.training.android.money.listview.items.interfaces.impls;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import ru.javabegin.training.android.money.objects.AppContext;
import android.content.Intent;

public class CurrencyItem extends AbstractSprItem {

	private static final long serialVersionUID = 1L;

	private static final String TABLE_NAME = "spr_Currency";
	
	private String shortName;
	
	public String getShortName() {
		return shortName;
	}
	
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	

	public CurrencyItem(Intent clickIntent, Intent resultIntent) {
		setTableName(TABLE_NAME);
		setName(AppContext.getInstance().getResources().getString(R.string.currency));
		updateIntents(clickIntent, resultIntent);
	}


	public CurrencyItem() {		
		setTableName(TABLE_NAME);
		setName(AppContext.getInstance().getResources().getString(R.string.currency));
		updateIntents(getSelectValueIntent(), getOperDetailsIntent());
	}
	
	

	@Override
	public ArrayList<ListItem> getChildItems() {
		return new ArrayList<ListItem>(DbItemCreator.getCurrencyDbItem().getChildItems(getId()));
	}
	
	@Override
	public ArrayList<ListItem> getRootItems() {
		return new ArrayList<ListItem>(DbItemCreator.getCurrencyDbItem().getRootItems());
	}
	
	@Override
	public String getSelectTitle() {
		return AppContext.getInstance().getResources().getString(R.string.currency);
	}
	

}
