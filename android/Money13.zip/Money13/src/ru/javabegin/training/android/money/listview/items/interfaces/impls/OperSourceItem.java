package ru.javabegin.training.android.money.listview.items.interfaces.impls;

import java.util.ArrayList;

import android.content.Intent;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import ru.javabegin.training.android.money.listview.items.listeners.ChangeOperTypeListener;
import ru.javabegin.training.android.money.objects.AppContext;

public class OperSourceItem extends AbstractSprItem implements ChangeOperTypeListener{
	
	private static final long serialVersionUID =  1L;
	
	private static final String TABLE_NAME = "spr_OperationSource";
	
	public OperSourceItem(Intent clickIntent, Intent resultIntent) {
		setTableName(TABLE_NAME);
		setName(AppContext.getInstance().getResources().getString(R.string.operation_source));
		updateIntents(clickIntent, resultIntent);
	}


	public OperSourceItem() {		
		setTableName(TABLE_NAME);
		setName(AppContext.getInstance().getResources().getString(R.string.operation_source));
		updateIntents(getSelectValueIntent(), getOperDetailsIntent());
	}
	

	@Override
	public ArrayList<ListItem> getChildItems() {
		return  new ArrayList<ListItem>(DbItemCreator.getOperSourceDbItem().getChildItems(getId()));
	}
	
	
	@Override
	public ArrayList<ListItem> getRootItems() {
		return  new ArrayList<ListItem>(DbItemCreator.getOperSourceDbItem().getRootItems());
	}
	
	@Override
	public void notifyItemSelected(int id) {
		setSelectedChildItem(null);
		setId(0);
		setName(AppContext.getInstance().getResources().getString(R.string.operation_source));
	}
	
	@Override
	public String getSelectTitle() {
		return AppContext.getInstance().getResources().getString(R.string.operation_source);
	}

}
