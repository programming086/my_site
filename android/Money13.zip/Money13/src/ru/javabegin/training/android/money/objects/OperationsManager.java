package ru.javabegin.training.android.money.objects;

import java.util.ArrayList;
import java.util.HashMap;

import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperationItem;

public class OperationsManager{
	
	public static OperationsManager instance;
	
	private OperationsManager() {}
	
	public static OperationsManager getInstance(){
		if (instance == null){
			instance = new OperationsManager();
		}
		
		return instance;
	}
	
	private HashMap<Integer, OperationItem> operationMap = new HashMap<Integer, OperationItem>();
	private ArrayList<OperationItem> operationList = new ArrayList<OperationItem>();
	
	
	public void setOperationList(ArrayList<OperationItem> list){
		operationList.clear();
		operationList.addAll(list);
		
		operationMap.clear();
		for (OperationItem item : list) {
			operationMap.put(item.getId(), item);
		}
	}
	
	public ArrayList<OperationItem> getOperationList() {
		return operationList;
	}
	
	
	public OperationItem getOperation(int id){
		return operationMap.get(id);
	}

}
