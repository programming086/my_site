package ru.javabegin.training.android.money.activities;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.enums.ItemType;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.listview.adapters.ItemAdapter;
import ru.javabegin.training.android.money.listview.adapters.SprNameAdapter;
import ru.javabegin.training.android.money.listview.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.listview.items.interfaces.Item;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.CurrencyItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.DateTimeItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.DescriptionItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.FromStorageItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperSourceItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperTypeItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperationItem;
import ru.javabegin.training.android.money.listview.items.listeners.ChangeOperTypeListener;
import ru.javabegin.training.android.money.listview.items.listeners.impls.ListenerRegistrator;
import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.OperationsManager;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

// активити для создания/редактирования операции 
public class OperationDetailsActivity extends AnimationActivity implements ChangeOperTypeListener{

	public static final String SPR_LIST = "ru.javabegin.training.android.money.activities.sprList";

	private LinkedHashMap<String, AbstractSprItem> selectedValuesMap = new LinkedHashMap<String, AbstractSprItem>(); // хранит
																												// выбранные
																												// значения

	private ListView lvSpr;
	private ListView lvItems;

	private ArrayList<ListItem> sprSelectList = new ArrayList<ListItem>();// для
																			// выбора
																			// справочных
																			// значений
	private ArrayList<Item> addInfoList = new ArrayList<Item>();// для хранения
																// данных,
																// введенных
																// вручную

	private EditText txtAmount;

	private OperationItem operationItem;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_operation_details);

		txtAmount = (EditText) findViewById(R.id.txt_amount_input);

		lvSpr = (ListView) findViewById(R.id.list_metadata);

		
		
		fillOperation();
	
		txtAmount.setText(String.valueOf(operationItem.getAmount()));
		
		
		// уникальным ключом для хранения выбранного значение будет имя класса
		selectedValuesMap.put(	operationItem.getOperTypeItem().toString(), operationItem.getOperTypeItem());
		selectedValuesMap.put(operationItem.getOperSourceItem().toString(), operationItem.getOperSourceItem());
		selectedValuesMap.put(operationItem.getCurrencyItem().toString(), operationItem.getCurrencyItem());				
		selectedValuesMap.put(operationItem.getStorageItem().toString(), operationItem.getStorageItem());
		selectedValuesMap.put(operationItem.getFromStorageItem().toString(), operationItem.getFromStorageItem());

		
 		operationItem.getOperTypeItem().setItemType(ItemType.ROOT);
 		operationItem.getOperSourceItem().setItemType(ItemType.ROOT);
 		operationItem.getCurrencyItem().setItemType(ItemType.ROOT);
 		operationItem.getStorageItem().setItemType(ItemType.ROOT);
		
		sprSelectList.add(operationItem.getOperTypeItem());
		sprSelectList.add(operationItem.getCurrencyItem());
		sprSelectList.add(operationItem.getOperSourceItem());		
		sprSelectList.add(operationItem.getStorageItem());
		

		addInfoList.add(operationItem.getDescItem());
		addInfoList.add(operationItem.getDateTimeItem());

			



		lvSpr.setOnItemClickListener(new SprClickListener());

		lvItems = (ListView) findViewById(R.id.list_desc);
		lvItems.setOnItemClickListener(new ItemClickListener());

		lvSpr.setAdapter(new SprNameAdapter(this, sprSelectList));
		lvItems.setAdapter(new ItemAdapter(this, addInfoList));

		addListeners();
		DbItemCreator.getOperSourceDbItem().setOperTypeId(operationItem.getOperTypeItem().getId());
		DbItemCreator.getFromStorageDbItem().setCurrencyId(operationItem.getCurrencyItem().getId());

		notifyItemSelected(operationItem.getOperTypeItem());
		
	}

	
	// заполнить операцию нужными объектами
	private void fillOperation() {
		
		int id = getIntent().getIntExtra(AppContext.OPERATION_ID, 0);
		
		if (id > 0) {// если id>0 - значит режим редактирования
			operationItem = OperationsManager.getInstance().getOperation(id);
			operationItem.setEditMode(true);
		} else {// новая операция
			operationItem = new OperationItem();

			operationItem.setDescItem(new DescriptionItem());
			operationItem.setDateTimeItem(new DateTimeItem());

			if (DbItemCreator.getOperationDbItem().hasLastOperation()) { // пробуем получить последние выбранные значения
				selectLastItems();
			}		
		}
		
		// operSourceItem используется не во всех типах операции (при получении последней операции типа трансфер operSourceItem = null)
		// TODO переделать, чтобы логика было более понятной
		if (operationItem.getOperSourceItem()==null){
			operationItem.setOperSourceItem(new OperSourceItem());
		}
		
		if (operationItem.getFromStorageItem()==null){
			operationItem.setFromStorageItem(new FromStorageItem());
		}

	}

	
	@Override
	public void finish() {
		// TODO Auto-generated method stub
		super.finish();
		removeListeners();
	}
	
	private void removeListeners() {
		ListenerRegistrator.getInstance().removeListener(operationItem.getOperSourceItem());
		ListenerRegistrator.getInstance().removeListener(DbItemCreator.getOperSourceDbItem());		
		ListenerRegistrator.getInstance().removeListener(DbItemCreator.getFromStorageDbItem());		
		ListenerRegistrator.getInstance().removeListener(this);				
	}

	
	private void addListeners(){
		ListenerRegistrator.getInstance().addListener(operationItem.getOperSourceItem());
		ListenerRegistrator.getInstance().addListener(DbItemCreator.getOperSourceDbItem());	
		ListenerRegistrator.getInstance().addListener(DbItemCreator.getFromStorageDbItem());	
		ListenerRegistrator.getInstance().addListener(this);		
	}

	private void selectLastItems() {
		operationItem.setAmount(DbItemCreator.getOperationDbItem().getLastItem().getAmount());
		operationItem.setCurrencyItem(DbItemCreator.getCurrencyDbItem().getLastItem());
		operationItem.setOperSourceItem(DbItemCreator.getOperSourceDbItem().getLastItem());
		operationItem.setOperTypeItem(DbItemCreator.getOperTypeDbItem().getLastItem());
		operationItem.setStorageItem(DbItemCreator.getStorageDbItem().getLastItem());
	}
	


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.operation_details, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {

		case R.id.save:
			
			if (canSave()) {

				BigDecimal amount = new BigDecimal(txtAmount.getText().toString());
				operationItem.setNewAmount(amount);
				operationItem.save();
				removeListeners();
				super.closeActivity();
			}
			break;

		case R.id.delete:

			AlertDialog.Builder builder = new AlertDialog.Builder(
					OperationDetailsActivity.this);
			builder.setMessage(getResources()
					.getString(R.string.confirm_delete));
			builder.setTitle(getResources().getString(R.string.confirm_title));

			builder.setNegativeButton("NO",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							dialog.cancel();
						}
					});

			builder.setPositiveButton("YES",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {

							if (operationItem.isEditMode()) {
								removeListeners();
								DbItemCreator.getOperationDbItem()
										.deleteOperation(operationItem);
							}
							OperationDetailsActivity.super.closeActivity();
							

							Toast.makeText(
									OperationDetailsActivity.this,
									getResources().getString(
											R.string.deleted_title),
									Toast.LENGTH_SHORT).show();
						}
					});

			builder.create().show();

			break;

		}

		return super.onOptionsItemSelected(item);
	}

	private boolean canSave() {
		
		// TODO проверять, чтобы сумма была больше 0 и выбраны все нужные значения
		
		// получаем актуальное id типа операции
		int id = operationItem.getOperTypeItem().getSelectedChildItem()!=null?operationItem.getOperTypeItem().getSelectedChildItem().getId():operationItem.getOperTypeItem().getId();
		
		if (id == OperationType.TRANSFER.getId()) {
			
			// сколько максимально можно перевести со счета
			ListItem item = operationItem.getFromStorageItem().getSelectedChildItem()!=null?operationItem.getFromStorageItem().getSelectedChildItem():operationItem.getFromStorageItem();
			BigDecimal maxAmount  = ((FromStorageItem)item).getAmount();
			
			//TODO показывать сообщение, если введенная сумма больше возможной
			
			System.out.println(maxAmount);
		}
		
		return true;
	}


	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);

		// если выбрано какое-то значение справочника
		if (intent.getExtras() != null && !intent.getExtras().isEmpty()) {

			AbstractSprItem selectedChildItem = (AbstractSprItem) intent
					.getSerializableExtra(AppContext.SELECTED_ITEM);

			AbstractSprItem parentItem = selectedValuesMap.get(selectedChildItem.toString());

			int selectedId = selectedChildItem.getId();
			int prevId = 0;

			// проверяем, выбрали новое значение или нет
			if (parentItem.getSelectedChildItem() != null) {
				prevId = parentItem.getSelectedChildItem().getId();
			}

			if (parentItem.getSelectedChildItem() == null) {
				prevId = parentItem.getId();
			}

			if (selectedId == prevId) {
				return;
			}

			parentItem.setSelectedChildItem(selectedChildItem);

			((SprNameAdapter) lvSpr.getAdapter()).notifyDataSetChanged();

		}

	}

	// слушатель для выбора справочных значений
	private class SprClickListener implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {

			ListItem item = (ListItem) parent.getAdapter().getItem(position);
			Intent intent = item.getClickIntent();
			startActivity(intent);
			overridePendingTransition(R.anim.pull_in_right,
					R.anim.push_out_left);

		}

	}

	// слушатель для изменения несправочных значений
	private class ItemClickListener implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {

			Item item = (Item) parent.getAdapter().getItem(position);

			switch (position) {
			case 0:
				startActivityForResult(
						item.getClickIntent(),
						DescriptionItem.REQUEST_CODE);
				break;

			case 1:
				startActivityForResult(
						item.getClickIntent(),
						DateTimeItem.REQUEST_CODE);
			}

			overridePendingTransition(R.anim.pull_in_right,
					R.anim.push_out_left);

		}

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == RESULT_OK) {

			switch (requestCode) {
			case DescriptionItem.REQUEST_CODE:
				operationItem.getDescItem().setDisplayText(
						data.getStringExtra(DescriptionItem.TEXT));
				((ItemAdapter) lvItems.getAdapter()).notifyDataSetChanged();
				break;
			case DateTimeItem.REQUEST_CODE:
				Calendar c = (Calendar) data
						.getSerializableExtra(AppContext.CALENDAR);
				operationItem.getDateTimeItem().setCalendar(c);
				((ItemAdapter) lvItems.getAdapter()).notifyDataSetChanged();
			}

		}

	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		super.onSaveInstanceState(outState);
		// outState.putSerializable(SPR_LIST, sprNamesMap);
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onRestoreInstanceState(savedInstanceState);
		// sprNamesMap = (LinkedHashMap<String, SprNameItem>)
		// savedInstanceState.get(SPR_LIST);
	}

	
	
	@Override
	public void notifyItemSelected(ListItem item) {
		
		if (item instanceof OperTypeItem) {// если изменился тип операции
			
			int id = item.getId();

			// манипуляция с пунктами, какие показывать, какие скрывать
			if (id == OperationType.TRANSFER.getId()) {
				operationItem.getFromStorageItem().setItemType(ItemType.ROOT);
				sprSelectList.add(3, operationItem.getFromStorageItem());
				sprSelectList.remove(operationItem.getOperSourceItem());

			} else {
				if (!sprSelectList.contains(operationItem.getOperSourceItem())) {
					sprSelectList.add(2, operationItem.getOperSourceItem());
				}

				if (sprSelectList.contains(operationItem.getFromStorageItem())) {
					sprSelectList.remove(operationItem.getFromStorageItem());
				}				

			}

			((ItemAdapter) lvItems.getAdapter()).notifyDataSetChanged();
		}else if (item instanceof CurrencyItem){// если изменилась валюта
			
			// получаем актуальное id типа операции
			int id = operationItem.getOperTypeItem().getSelectedChildItem()!=null?operationItem.getOperTypeItem().getSelectedChildItem().getId():operationItem.getOperTypeItem().getId();
			
			if (id == OperationType.TRANSFER.getId()) { //нужно сбросить счет-источник
				operationItem.getFromStorageItem().setId(0);
				operationItem.getFromStorageItem().setSelectedChildItem(null);
				operationItem.getFromStorageItem().setName(AppContext.getInstance().getResources().getString(R.string.storage_from));
			}
			
		}

	}
	

}
