package ru.javabegin.training.android.money.database.abstracts;

import java.util.ArrayList;

import android.database.Cursor;
import android.util.Log;

public abstract class AbstractDbListItem<T> extends AbstractDbItem {

	protected abstract T fillItem(Cursor c); // делегируем дочерним классам
												// заполнение объекта
	


	public T getOneItem(int itemId) {
		return fillOneItem(getOneItemSQL(itemId));
	}
	
	public ArrayList<T> getAllItems(){
		return fillList(getAllItemsSQL());
	}
	

	public ArrayList<T> getRootItems(){
		return fillList(getRootItemsSQL());
	}

	public ArrayList<T> getChildItems(int id){
		return fillList(getChildItemsSQL(id));
	}

	
	public T getLastItem(){
		return fillOneItem(getLastItemSQL());
	}
	
	
	// получить одну запись
	protected T fillOneItem(String sql) {
		T item = null;

		try {

			cursor = sqlExecutor.execFirstResult(sql);
//			Log.d(tag, sql);
			item = fillItem(cursor);
			closeCursor();

		} catch (Exception e) {
			Log.e(tag, e.getMessage());
		}

		return item;
	}


	// получить список записей
	protected ArrayList<T> fillList(String sql) {
		ArrayList<T> list = new ArrayList<T>();

		try {

//			Log.d(tag, sql);

			cursor = sqlExecutor.execSQL(sql);

//			Log.d(tag, DatabaseUtils.dumpCursorToString(cursor));

			while (cursor.moveToNext()) {
				list.add(fillItem(cursor));
			}

			closeCursor();

		} catch (Exception e) {
			Log.e(tag, e.getMessage());
		}

		return list;
	}
	

	

	protected boolean getBooleanFromInt(int number) {
		if (number > 0) {
			return true;
		} else {
			return false;
		}
	}

	public boolean hasRows(String sql) {
		cursor = sqlExecutor.execFirstResult(sql);
		int count = cursor.getCount();
		closeCursor();
		return getBooleanFromInt(count);
	}

	
	
	protected String getLastItemSQL() {
		return null;
	}

	protected String getOneItemSQL(int itemId) {
		return null;
	}

	protected String getChildItemsSQL(int parentId) {
		return null;
	}

	protected String getAllItemsSQL() {
		return null;
	}

	protected String getRootItemsSQL() {
		return null;
	}

	

}
