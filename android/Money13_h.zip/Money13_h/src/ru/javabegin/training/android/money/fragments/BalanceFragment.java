package ru.javabegin.training.android.money.fragments;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.adapters.BalanceAdapter;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

public class BalanceFragment extends Fragment {

	private GridView gridView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		// обязательно нужно реализовывать, тут мы показываем какую разметку
		// используем
		// так же здесь можно переопределять елементы, findViewByID и остальное
		// делается так view.findViewById...
		View view = inflater.inflate(R.layout.fragment_balance, container,
				false);

		gridView = (GridView) view.findViewById(R.id.grid_balance);

		gridView.setAdapter(new BalanceAdapter(getActivity(), DbItemCreator.getBalanceDbItem().getAllItems()));

		return view;
	}
	
	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		
		// TODO обновлять только нужные записи, постоянно делать запрос в базу - неправильно!
				
		((BalanceAdapter)gridView.getAdapter()).update(DbItemCreator.getBalanceDbItem().getAllItems());
	}
	
	

}
