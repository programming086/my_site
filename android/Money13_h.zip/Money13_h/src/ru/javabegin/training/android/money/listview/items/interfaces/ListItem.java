package ru.javabegin.training.android.money.listview.items.interfaces;

import java.util.ArrayList;

import ru.javabegin.training.android.money.enums.ItemType;

public interface ListItem extends Item{
	
	ArrayList<ListItem> getChildItems();
	
	ArrayList<ListItem> getRootItems();

	boolean hasChilds();
	
	String getTableName();

	ListItem getSelectedChildItem(); // для хранения выбранного справочного значения
	
	String getName();
	
	int getId();

	ItemType getItemType();
	
	boolean isEnable();
	
}
