package ru.javabegin.training.android.money.listview.items.interfaces.impls;

import java.math.BigDecimal;
import java.util.ArrayList;

import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import android.content.Intent;

// для типа операции "Перевод" (кошелек, с которого переводим)
public class FromStorageItem extends StorageItem{

	private static final long serialVersionUID = 1L;
	
	private BigDecimal amount;
	
	public FromStorageItem(Intent clickIntent, Intent resultIntent) {
		super(clickIntent, resultIntent);
	}

	public FromStorageItem() {	
		super();
	}

	@Override
	public ArrayList<ListItem> getChildItems() {
		return  new ArrayList<ListItem>(DbItemCreator.getFromStorageDbItem().getChildItems(getId()));
	}
	
	@Override
	public ArrayList<ListItem> getRootItems() {
		return  new ArrayList<ListItem>(DbItemCreator.getFromStorageDbItem().getRootItems());
	}
	
	public BigDecimal getAmount() {
		return amount;
	}
	
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	



}
