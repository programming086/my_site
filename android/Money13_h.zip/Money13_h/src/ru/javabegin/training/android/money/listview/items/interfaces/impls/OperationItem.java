package ru.javabegin.training.android.money.listview.items.interfaces.impls;

import java.io.Serializable;
import java.math.BigDecimal;

import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;

public class OperationItem implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private int id;
	private boolean editMode;
	
	private FromStorageItem fromStorageItem; // для трансфера: с какого счета переводим
	
	private OperTypeItem operTypeItem;
	private OperSourceItem operSourceItem;
	private StorageItem storageItem;
	private CurrencyItem currencyItem;
	private DescriptionItem descItem;
	private DateTimeItem dateTimeItem;
	
	private BigDecimal newAmount;// хранит новое введенное пользователем значение
	private BigDecimal amount;// хранит старое значение (при редактировании), до изменения - это нужно для правильного обновления баланса
	

	public OperTypeItem getOperTypeItem() {
		return operTypeItem;
	}

	public void setOperTypeItem(OperTypeItem operTypeItem) {
		this.operTypeItem = operTypeItem;
	}

	public OperSourceItem getOperSourceItem() {
		return operSourceItem;
	}

	public void setOperSourceItem(OperSourceItem operSourceItem) {
		this.operSourceItem = operSourceItem;
	}

	public StorageItem getStorageItem() {
		return storageItem;
	}

	public void setStorageItem(StorageItem storageItem) {
		this.storageItem = storageItem;
	}

	public CurrencyItem getCurrencyItem() {
		return currencyItem;
	}

	public void setCurrencyItem(CurrencyItem currencyItem) {
		this.currencyItem = currencyItem;
	}
	
	public DescriptionItem getDescItem() {
		return descItem;
	}
	
	public void setDescItem(DescriptionItem descItem) {
		this.descItem = descItem;
	}


	public BigDecimal getNewAmount() {
		return newAmount;
	}

	public void setNewAmount(BigDecimal newAmount) {
		this.newAmount = newAmount;
	}
	
	public BigDecimal getAmount() {
		return amount;
	}
	
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public boolean save() {
		return DbItemCreator.getOperationDbItem().saveOperation(this);
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	
	public DateTimeItem getDateTimeItem() {
		return dateTimeItem;
	}
	
	public void setDateTimeItem(DateTimeItem dateTimeItem) {
		this.dateTimeItem = dateTimeItem;
	}


	public boolean isEditMode() {
		return editMode;
	}
	
	public void setEditMode(boolean editMode) {
		this.editMode = editMode;
	}

	public FromStorageItem getFromStorageItem() {
		return fromStorageItem;
	}	
	
	public void setFromStorageItem(FromStorageItem fromStorageItem) {
		this.fromStorageItem = fromStorageItem;
	}	
	
	
}
