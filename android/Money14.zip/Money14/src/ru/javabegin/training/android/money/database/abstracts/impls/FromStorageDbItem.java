package ru.javabegin.training.android.money.database.abstracts.impls;

import java.math.BigDecimal;

import ru.javabegin.training.android.money.database.abstracts.AbstractDbListItem;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.CurrencyItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.FromStorageItem;
import ru.javabegin.training.android.money.listview.items.listeners.ChangeOperTypeListener;
import android.database.Cursor;


public class FromStorageDbItem extends AbstractDbListItem<FromStorageItem> implements ChangeOperTypeListener{
	
	private int currencyId;

	protected FromStorageDbItem() {}


	@Override
	protected String getChildItemsSQL(int id) {
		StringBuilder builder = new StringBuilder();

		builder.append("select " 
				+ " coalesce((select b.amount from balance b where b.storage_id=s1._id and b.currency_id="+currencyId+"),0) as "+ALIAS_AMOUNT+","
				+ "s1._id as " + ALIAS_ID + ", s1.name  as "
				+ ALIAS_NAME + ", coalesce((select _id from "
				+ STORAGE_TABLE
				+ " s2 where s2.parent_id=s1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + " from " + STORAGE_TABLE + " s1 "
				+ " where coalesce(s1.parent_id,0) = " + id
				+ " order by order_show");

		return builder.toString();
	}
	
	@Override
	protected String getOneItemSQL(int itemId) {

		StringBuilder builder = new StringBuilder();

		builder.append("select " 
				+ " coalesce((select b.amount from balance b where b.storage_id=s1._id and b.currency_id="+currencyId+"),0) as "+ALIAS_AMOUNT+","
				+ " s1._id as " + ALIAS_ID + ", s1.name  as "
				+ ALIAS_NAME + ", coalesce((select _id from "
				+ STORAGE_TABLE
				+ " s2 where s2.parent_id=s1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + " from " + STORAGE_TABLE + " s1 "
				+ " where s1._id="+itemId);

		return builder.toString();
	}
	
	@Override
	protected String getRootItemsSQL() {
		StringBuilder builder = new StringBuilder();

		builder.append("select " 
				+ " coalesce((select b.amount from balance b where b.storage_id=s1._id and b.currency_id="+currencyId+"),0) as "+ALIAS_AMOUNT+","
				+ " s1._id as " + ALIAS_ID + ", s1.name  as "
				+ ALIAS_NAME + ", coalesce((select _id from "
				+ STORAGE_TABLE
				+ " s2 where s2.parent_id=s1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + " from " + STORAGE_TABLE + " s1 "
				+" where coalesce(s1.parent_id,0) = 0");
		
		builder.append(" order by order_show");

		return builder.toString();
	}

	@Override
	protected FromStorageItem fillItem(Cursor c) {
		FromStorageItem item = new FromStorageItem();
		item.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
		item.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));
		item.setAmount(BigDecimal.valueOf(c.getDouble(c.getColumnIndex(ALIAS_AMOUNT))));
		item.setHasChilds(super.getBooleanFromInt(c.getInt(c.getColumnIndex(ALIAS_HAS_CHILD))));
		
		boolean enable = false;
		
		if (item.hasChilds() || c.getDouble(c.getColumnIndex(ALIAS_AMOUNT))>0){
			enable = true;
		}
		
		item.setEnable(enable);
		return item;
	}

	@Override
	public void notifyItemSelected(ListItem item) {
		if (item instanceof CurrencyItem){
			setCurrencyId(item.getId());		
		}
	}
	
	public void setCurrencyId(int currencyId) {
		this.currencyId = currencyId;
	}

	public int getCurrencyId() {
		return currencyId;
	}
	
}
