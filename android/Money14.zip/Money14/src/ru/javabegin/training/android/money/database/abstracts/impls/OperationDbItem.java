package ru.javabegin.training.android.money.database.abstracts.impls;

import java.math.BigDecimal;

import ru.javabegin.training.android.money.database.abstracts.AbstractDbListItem;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperationItem;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class OperationDbItem extends AbstractDbListItem<OperationItem> {

	protected OperationDbItem() {
	}

	private OperationType operationType;

	public void setOperationType(OperationType operationType) {
		this.operationType = operationType;
	}

	@Override
	protected String getAllItemsSQL() {
		StringBuilder builder = new StringBuilder();

		builder.append("select "
				+ " o.from_storage_id as "+ALIAS_FROM_STORAGE_ID
				+ ",o.currency_id as " + ALIAS_CURRENCY_ID
				+ ",t.name as " + ALIAS_TYPE_NAME + ",o.type_id as "
				+ ALIAS_TYPE_ID + ",o._id as " + ALIAS_ID + ",c.short_name as "
				+ ALIAS_CURRENCY + ",o.[amount] as " + ALIAS_AMOUNT
				+ ",o.[operation_datetime] as " + ALIAS_OPERATION_DATETIME
				+ ",o.[storage_id] as " + ALIAS_STORAGE_ID + ",s.[name] as "
				+ ALIAS_SOURCE + ",o.[description] as " + ALIAS_DESC
				+ ",o.[source_id] as " + ALIAS_SOURCE_ID + " from "
				+ OPERATIONS_TABLE + " o " + " left join " + CURRENCY_TABLE
				+ " c on o.currency_id=c.[_id]  " + " left join "
				+ OPER_SOURCE_TABLE + " s on o.source_id=s.[_id] "
				+ " left join " + OPER_TYPE_TABLE + " t on o.type_id=t.[_id] ");

		if (operationType != OperationType.ALL) {
			builder.append(" where o.type_id=" + operationType.getId());
			builder.append(" order by o.operation_datetime desc");
		} else {
			builder.append(" order by o.operation_datetime desc");
		}

		return builder.toString();
	}

	@Override
	protected String getOneItemSQL(int itemId) {

		StringBuilder builder = new StringBuilder();

		builder.append("select " 
				+ " o.from_storage_id as "+ALIAS_FROM_STORAGE_ID
				+ ",o._id as " + ALIAS_ID + ", o.amount  as "
				+ ALIAS_AMOUNT + " from " + OPERATIONS_TABLE + " o "
				+ " where o._id=" + itemId);

		builder.append("select " + "o.currency_id as " + ALIAS_CURRENCY_ID
				+ ",o.type_id as " + ALIAS_TYPE_ID + ",o._id as " + ALIAS_ID
				+ "," + "o.[amount] as " + ALIAS_AMOUNT
				+ ",o.[operation_datetime] as " + ALIAS_OPERATION_DATETIME
				+ ",o.[storage_id] as " + ALIAS_STORAGE_ID
				+ ",o.[description] as " + ALIAS_DESC + ",o.[source_id] as "
				+ ALIAS_SOURCE_ID + " from " + OPERATIONS_TABLE
				+ " o where o._id=" + itemId);

		return builder.toString();
	}

	@Override
	protected String getLastItemSQL() {
		StringBuilder builder = new StringBuilder();

		builder.append("select " 
				+ " o.from_storage_id as "+ALIAS_FROM_STORAGE_ID
				+ ",o.currency_id as " + ALIAS_CURRENCY_ID
				+ ",o.type_id as " + ALIAS_TYPE_ID + ",o._id as " + ALIAS_ID
				+ ",o.[amount] as " + ALIAS_AMOUNT
				+ ",o.[operation_datetime] as " + ALIAS_OPERATION_DATETIME
				+ ",o.[storage_id] as " + ALIAS_STORAGE_ID
				+ ",o.[source_id] as " + ALIAS_SOURCE_ID + " from "
				+ LAST_OPERATION_TABLE + " o");

		return builder.toString();
	}

	protected OperationItem fillItem(Cursor c) {
		OperationItem item = new OperationItem();
		item.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
		item.setAmount(BigDecimal.valueOf(c.getDouble(c.getColumnIndex(ALIAS_AMOUNT))));
		item.setCurrencyItem(DbItemCreator.getCurrencyDbItem().getOneItem(c.getInt(c.getColumnIndex(ALIAS_CURRENCY_ID))));
		item.setDateTimeItem(DbItemCreator.getDatetimeDbItem().getOneItem(item.getId()));
		item.setDescItem(DbItemCreator.getDescDbItem().getOneItem(item.getId()));
		item.setOperSourceItem(DbItemCreator.getOperSourceDbItem().getOneItem(c.getInt(c.getColumnIndex(ALIAS_SOURCE_ID))));			
		item.setOperTypeItem(DbItemCreator.getOperTypeDbItem().getOneItem(c.getInt(c.getColumnIndex(ALIAS_TYPE_ID))));
		item.setStorageItem(DbItemCreator.getStorageDbItem().getOneItem(c.getInt(c.getColumnIndex(ALIAS_STORAGE_ID))));
		item.setFromStorageItem(DbItemCreator.getFromStorageDbItem().getOneItem(c.getInt(c.getColumnIndex(ALIAS_FROM_STORAGE_ID))));

		return item;
	}

	public boolean hasLastOperation() {
		return super.hasRows("select _id from " + LAST_OPERATION_TABLE);
	}

	private SQLiteDatabase db = null;

	public boolean saveOperation(OperationItem operationItem) {

		boolean success = false;

		try {
			db = getDatabase();

			db.beginTransaction();

			// создаем или обновляем операцию (в базе данных также работает триггер)
			success = createOperation(operationItem);

			// обновляем данные по балансу
			success = checkBalance(operationItem);

			if (success) {// если все операции прошли успешно
				db.setTransactionSuccessful();
			}

		} catch (Exception e) {
			Log.e(tag, e.getMessage());
			return false;
		} finally {
			db.endTransaction();
		}

		return success;
	}

	private boolean checkBalance(OperationItem item) {

		boolean success = false;

		
		
		if (item.isEditMode()) { // если режим редактирования, то сначала нужно сделать откат текущей операции, чтобы правильно сохранились результаты
			
			int operTypeId = item.getOperTypeItem().getId();// берем id типа операции, которое было до редактирования
			
			// при трансфере - обновляем баланс 2 раза - для обоих счетов, откуда переводили и куда
			if(operTypeId == OperationType.TRANSFER.getId()){

				int oldCurrencyId = item.getCurrencyItem().getId();
				int oldStorageId = item.getFromStorageItem().getId();
				int oldOperTypeId = OperationType.OUTCOME.getId();
				
				success = DbItemCreator.getBalanceDbItem().revertBalance(oldOperTypeId, oldCurrencyId, oldStorageId, item.getAmount());
				
				oldCurrencyId = item.getCurrencyItem().getId();
				oldStorageId = item.getStorageItem().getId();
				oldOperTypeId = OperationType.INCOME.getId();
				
				success = DbItemCreator.getBalanceDbItem().revertBalance(oldOperTypeId, oldCurrencyId, oldStorageId, item.getAmount());

			} else {

				int oldCurrencyId = item.getCurrencyItem().getId();
				int oldStorageId = item.getStorageItem().getId();
				int oldOperTypeId = item.getOperTypeItem().getId();

				success = DbItemCreator.getBalanceDbItem().revertBalance(oldOperTypeId, oldCurrencyId, oldStorageId, item.getAmount());
			}
		}
		
		// заново определяем id типа операции, т.к. при редактировании его могли изменить
		int operTypeId = item.getOperTypeItem().getSelectedChildItem()!=null?item.getOperTypeItem().getSelectedChildItem().getId():item.getOperTypeItem().getId();
		
		// при трансфере - обновляем баланс 2 раза - для обоих счетов, откуда переводили и куда
		if(operTypeId == OperationType.TRANSFER.getId()){
			
			int fromStorageId = item.getFromStorageItem().getSelectedChildItem()!=null?item.getFromStorageItem().getSelectedChildItem().getId():item.getFromStorageItem().getId();			
			int currencyId = item.getCurrencyItem()	.getSelectedChildItem() != null ? item .getCurrencyItem().getSelectedChildItem().getId() : item.getCurrencyItem().getId();	
			
			success = DbItemCreator.getBalanceDbItem().updateBalance(currencyId, fromStorageId, OperationType.OUTCOME.getId(), item.getNewAmount());
	
			
			int storageId = item.getStorageItem().getSelectedChildItem() != null ? item .getStorageItem().getSelectedChildItem().getId(): item.getStorageItem().getId();			
			success = DbItemCreator.getBalanceDbItem().updateBalance(currencyId, storageId, OperationType.INCOME.getId(), item.getNewAmount());
					
					
		}else{
			
			// определяем нужные id
			int currencyId = item.getCurrencyItem().getSelectedChildItem() != null ? item .getCurrencyItem().getSelectedChildItem().getId(): item.getCurrencyItem().getId();
			int storageId = item.getStorageItem().getSelectedChildItem() != null ? item .getStorageItem().getSelectedChildItem().getId() : item.getStorageItem().getId();
						
			success = DbItemCreator.getBalanceDbItem().updateBalance(currencyId, storageId, operTypeId, item.getNewAmount());
		}
		
		return success;

	}
	
	


	private boolean createOperation(OperationItem operation) {

		SQLiteStatement stmt = null;

		try {

			if (operation.isEditMode()) {
				stmt = db
						.compileStatement("update "
								+ OPERATIONS_TABLE
								+ " set operation_datetime=?, amount=?, currency_id=?, source_id=?, storage_id=?, from_storage_id=?, type_id=?, description=? where _id=?");
				stmt.bindLong(9, operation.getId());

			} else {
				stmt = db
						.compileStatement("insert into "
								+ OPERATIONS_TABLE
								+ " (operation_datetime, amount, currency_id, source_id, storage_id, from_storage_id, type_id,  description) values (?,?,?,?,?,?,?,?)");
			}

			long date = operation.getDateTimeItem().getCalendar()
					.getTimeInMillis();

			// если есть измененные значения - берем их
			int currencyId = operation.getCurrencyItem().getSelectedChildItem() != null ? operation
					.getCurrencyItem().getSelectedChildItem().getId()
					: operation.getCurrencyItem().getId();
			int operSourceId = operation.getOperSourceItem()
					.getSelectedChildItem() != null ? operation
					.getOperSourceItem().getSelectedChildItem().getId()
					: operation.getOperSourceItem().getId();
			int storageId = operation.getStorageItem().getSelectedChildItem() != null ? operation
					.getStorageItem().getSelectedChildItem().getId()
					: operation.getStorageItem().getId();
					
			int fromStorageId = operation.getFromStorageItem().getSelectedChildItem() != null ? operation
							.getFromStorageItem().getSelectedChildItem().getId()
							: operation.getFromStorageItem().getId();
					
					
			int operTypeId = operation.getOperTypeItem().getSelectedChildItem() != null ? operation
					.getOperTypeItem().getSelectedChildItem().getId()
					: operation.getOperTypeItem().getId();

			stmt.bindLong(1, date);
			stmt.bindDouble(2, operation.getNewAmount().doubleValue());
			stmt.bindLong(3, currencyId);
			stmt.bindLong(4, operSourceId);
			stmt.bindLong(5, storageId);
			stmt.bindLong(6, fromStorageId);
			stmt.bindLong(7, operTypeId);

			if (operation.getDescItem().getDisplayText() == null) {
				stmt.bindNull(8);
			} else {
				stmt.bindString(8, operation.getDescItem().getDisplayText());
			}

			stmt.execute();

		} catch (Exception e) {
			Log.e(tag, e.getMessage());
			return false;
		}

		return true;

	}

	// удалить операцию и обновить баланс
	public boolean deleteOperation(OperationItem operationItem) {

		boolean success = false; // хранит, все ли операции завершились удачно

		try {

			db = getDatabase();

			db.beginTransaction();

			// сначала удаляем саму операцию, потом обновлям баланс
			success = deleteOperation(operationItem.getId());
			
			
			if (operationItem.getOperTypeItem().getId()==OperationType.TRANSFER.getId()){
				// при обновлении баланса выбираем базовые значения (до  редактирования)
				int oldCurrencyId = operationItem.getCurrencyItem().getId();
				int oldStorageId = operationItem.getFromStorageItem().getId();
				int oldOperTypeId = OperationType.OUTCOME.getId();
				
				success = DbItemCreator.getBalanceDbItem().revertBalance(oldOperTypeId, oldCurrencyId, oldStorageId, operationItem.getAmount());
				
				oldCurrencyId = operationItem.getCurrencyItem().getId();
				oldStorageId = operationItem.getStorageItem().getId();
				oldOperTypeId = OperationType.INCOME.getId();
				
				success = DbItemCreator.getBalanceDbItem().revertBalance(oldOperTypeId, oldCurrencyId, oldStorageId, operationItem.getAmount());
			
			}else{
				int oldCurrencyId = operationItem.getCurrencyItem().getId();
				int oldStorageId = operationItem.getStorageItem().getId();
				int oldOperTypeId = operationItem.getOperTypeItem().getId();
				
				success = DbItemCreator.getBalanceDbItem().revertBalance(oldOperTypeId, oldCurrencyId, oldStorageId, operationItem.getAmount());
			}


			if (success) { // если все операции завершили удачно
				db.setTransactionSuccessful();
			}

		} catch (Exception e) {
			Log.e(tag, e.getMessage());
			return false;
		} finally {
			db.endTransaction();
		}

		return success;

	}

	private boolean deleteOperation(int operationId) {
		SQLiteStatement stmt = null;
		try {

			stmt = db.compileStatement("delete from " + OPERATIONS_TABLE + " where _id=?");
			stmt.bindLong(1, operationId);
			stmt.execute();
		} catch (Exception e) {
			Log.e(tag, e.getMessage());
			return false;
		} finally {
			if (stmt != null) {
				stmt.close();
			}
		}

		return true;
	}

	

}
