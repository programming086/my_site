package ru.javabegin.training.android.money.database.interfaces.impls;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import ru.javabegin.training.android.money.database.interfaces.DbConnector;
import ru.javabegin.training.android.money.objects.AppContext;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class MoneyDbConnector implements DbConnector{
	
	protected static final String TAG = MoneyDbConnector.class.getName();

	protected DbHelper dbHelper;
	
	public MoneyDbConnector() {
		dbHelper = new DbHelper(AppContext.getInstance());
	}

	@Override
	public SQLiteDatabase getDatabase() {
		return dbHelper.getReadableDatabase();
	}

	@Override
	public void closeDatabase() {
		dbHelper.close();
	}
	
	private static class DbHelper extends SQLiteOpenHelper {

		public static final String DB_NAME = "money.db";
		public static final int DB_VERSION = 1;

		private String dbPath;
		private Context context;

		public DbHelper(Context context) {
			super(context, DB_NAME, null, DB_VERSION);

			dbPath = context.getApplicationInfo().dataDir + "/" + "databases/"
					+ DB_NAME;
			this.context = context;
			if (checkDataBaseExists()) {
				copyDataBase();
			}

		}

		@Override
		public void onCreate(SQLiteDatabase db) {

		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

		}

		private boolean checkDataBaseExists() {
			File dbFile = new File(dbPath);
			return dbFile.exists();
		}

		private void copyDataBase() {
			InputStream myInput = null;
			OutputStream myOutput = null;
			try {
				myInput = context.getAssets().open(DB_NAME);
				myOutput = new FileOutputStream(dbPath);
				byte[] buffer = new byte[1024];
				int length;
				while ((length = myInput.read(buffer)) > 0) {
					myOutput.write(buffer, 0, length);
				}

			} catch (Exception e) {
				Log.e(TAG, e.getMessage());
			} finally {
				try {
					myOutput.flush();
					myOutput.close();
					myInput.close();
				} catch (IOException e) {
					Log.e(TAG, e.getMessage());
				}
			}

		}
	}

}
