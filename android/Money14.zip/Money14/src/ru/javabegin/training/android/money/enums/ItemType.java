package ru.javabegin.training.android.money.enums;

public enum ItemType {
	
	ROOT, // с него начинается обзор всех элементов
	CHILD // конкретный элемент справочника

}
