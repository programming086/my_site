package ru.javabegin.training.android.money.fragments;

import java.util.ArrayList;

import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.adapters.CurrencyAdapter;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.CurrencyItem;
import android.widget.ListAdapter;

public class CurrencySettingsFragment extends AbstractListFragment {

	@Override
	protected ListAdapter getAdapter() {
		ArrayList<CurrencyItem> list = DbItemCreator.getCurrencyDbItem().getAllItems();
		CurrencyAdapter adapter = new CurrencyAdapter(getActivity(), list);
		return adapter;
	}

}
