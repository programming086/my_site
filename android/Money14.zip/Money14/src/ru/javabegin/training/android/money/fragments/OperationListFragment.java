package ru.javabegin.training.android.money.fragments;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.activities.OperationDetailsActivity;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.gui.MenuExpandableList;
import ru.javabegin.training.android.money.listview.adapters.OperationsListAdapter;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperationItem;
import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.OperationsManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;

// отображает список операций
public class OperationListFragment extends AbstractListFragment {

	private Intent operDetailsIntent;
	
	private OperationType operType;
	
	private OperationsListAdapter operationsAdapter;
	

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		operDetailsIntent = new Intent(getActivity(), OperationDetailsActivity.class);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);

		operType = (OperationType) getArguments().getSerializable(MenuExpandableList.OPERATION_TYPE);
		
		DbItemCreator.getOperationDbItem().setOperationType(operType);
		
		OperationsManager.getInstance().setOperationList(DbItemCreator.getOperationDbItem().getAllItems());
	}


	
	
	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		// TODO Auto-generated method stub
		super.onListItemClick(l, v, position, id);
		
		OperationItem item = (OperationItem)l.getAdapter().getItem(position);
		
		operDetailsIntent.putExtra(AppContext.OPERATION_ID, item.getId());
		getActivity().startActivity(operDetailsIntent);
		getActivity().overridePendingTransition(R.anim.pull_in_right, R.anim.push_out_left);
	}

	
	
	
	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		
		ArrayList<OperationItem> list = DbItemCreator.getOperationDbItem().getAllItems();
		
		// TODO исправить:  обновлять только нужные записи, постоянно делать запрос в базу - неправильно!	
		OperationsManager.getInstance().setOperationList(list);
		((OperationsListAdapter)getListAdapter()).update(list);
	}

	@Override
	protected ListAdapter getAdapter() {
		if (operationsAdapter==null){
			operationsAdapter = new OperationsListAdapter(getActivity(), OperationsManager.getInstance().getOperationList());
		}
		return operationsAdapter;	
	}



}
