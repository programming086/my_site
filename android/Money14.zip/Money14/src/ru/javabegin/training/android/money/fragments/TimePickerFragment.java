package ru.javabegin.training.android.money.fragments;

import java.util.Calendar;

import ru.javabegin.training.android.money.gui.datetime.interfaces.DatetimeChangeListener;
import ru.javabegin.training.android.money.objects.AppContext;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.os.Bundle;
import android.widget.TimePicker;

public class TimePickerFragment extends DialogFragment implements OnTimeSetListener {
	
	private static Calendar calendar;
	
	private DatetimeChangeListener listener;
	
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		
		calendar = (Calendar) getArguments().getSerializable(AppContext.CALENDAR);
		
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        return new TimePickerDialog(getActivity(), this, hour, minute, true);
	}

	@Override
	public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
		calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
		calendar.set(Calendar.MINUTE, minute);
		if (listener!=null){
			listener.changeValue(calendar);
		}
	}
	
	public void setDatetimeChangeListener(DatetimeChangeListener listener) {
		this.listener = listener;
	}
	
	
	
}
