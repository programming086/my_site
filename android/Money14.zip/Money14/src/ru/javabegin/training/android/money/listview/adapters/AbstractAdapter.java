package ru.javabegin.training.android.money.listview.adapters;

import java.io.Serializable;
import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.listview.items.interfaces.Item;
import ru.javabegin.training.android.money.objects.AppContext;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public abstract class AbstractAdapter<T extends Item> extends ArrayAdapter<T> implements
		Serializable {

	private static final long serialVersionUID = -6871278106989089049L;

	protected AppContext appContext;

	private ArrayList<T> list;
	
	protected AbstractAdapter(Context context, ArrayList<T> list) {
		super(context, R.id.spr_value, list);
		this.list = list;
		this.appContext = (AppContext) context.getApplicationContext();
	}

	protected View getView(View convertView, ViewGroup parent) {

		if (convertView == null) {

			LayoutInflater inflater = (LayoutInflater) getContext()
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(R.layout.listview_item_sprvalue,
					parent, false);

			ViewHolder holder = new ViewHolder();

			holder.txtSprName = (TextView) convertView
					.findViewById(R.id.spr_value);
			holder.image = (ImageView) convertView
					.findViewById(R.id.image_spr_value);
			holder.imageArrow = (ImageView) convertView
					.findViewById(R.id.image_arrow);

			convertView.setTag(holder);
		}

		return convertView;
	}

	@Override
	public T getItem(int position) {
		return list.get(position);
	}

	protected static class ViewHolder {
		public TextView txtSprName;
		public ImageView image;
		public ImageView imageArrow;
	}

	protected Bitmap getNoIconImage(){
		return BitmapFactory.decodeResource(appContext.getResources(), R.drawable.noicon);
	}
	


}
