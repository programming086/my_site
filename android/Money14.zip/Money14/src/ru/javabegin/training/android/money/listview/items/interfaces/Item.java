package ru.javabegin.training.android.money.listview.items.interfaces;

import java.io.Serializable;

import android.content.Intent;
import android.graphics.Bitmap;

public interface Item extends Serializable{	
	
	Intent getClickIntent();	// куда переходить по клику
	
	Intent getResultIntent(); // куда возвращать результат
	
	Bitmap getImage();
	
	String getDisplayText(); // пользовательское значение
	
	String getSelectTitle();	// подсказка, когда не выбрано значение	
	


}
