package ru.javabegin.training.android.money.listview.items.listeners;

import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;


// слушатель события
public interface ChangeOperTypeListener {
	void notifyItemSelected(ListItem item); 
}
