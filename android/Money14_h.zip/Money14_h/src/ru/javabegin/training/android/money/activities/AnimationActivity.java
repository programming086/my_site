package ru.javabegin.training.android.money.activities;

import ru.javabegin.training.android.money.R;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MenuItem;

public class AnimationActivity extends Activity{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		getActionBar().setDisplayHomeAsUpEnabled(true);
	}
	
	
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home: {

			closeActivity();

			return true;
		}

		default:
			break;
		}

		return super.onOptionsItemSelected(item);
	}
	
	
	protected void closeActivity() {
		finish();
		overridePendingTransition(R.anim.pull_in_left,
				R.anim.push_out_right);		
	}



	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
			finish();
			overridePendingTransition(R.anim.pull_in_left,
					R.anim.push_out_right);
			return true;
		}

		return super.onKeyDown(keyCode, event);
	}


}
