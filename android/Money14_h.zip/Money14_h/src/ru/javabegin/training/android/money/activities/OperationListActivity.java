package ru.javabegin.training.android.money.activities;

import java.util.Currency;
import java.util.Iterator;
import java.util.Locale;
import java.util.Set;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.gui.MenuExpandableList;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.view.Menu;
import android.view.MenuItem;

public class OperationListActivity extends Activity {

	private static MenuExpandableList menuExpandableList;

	private Intent intentOperDetailsActivity;

	private DrawerLayout drawerLayout;
	private ActionBarDrawerToggle drawerToggle;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_operation_list);
		
		menuExpandableList = new MenuExpandableList(this);
		
		intentOperDetailsActivity = new Intent(this, OperationDetailsActivity.class);
		
		getActionBar().setDisplayHomeAsUpEnabled(true);
		getActionBar().setHomeButtonEnabled(true);

		drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
		drawerLayout.setDrawerShadow(R.drawable.drawer_shadow, GravityCompat.START);
		drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

		drawerToggle = new ActionBarDrawerToggle(this, drawerLayout,
				R.drawable.ic_drawer, R.string.drawer_open,
				R.string.drawer_close);
		
		drawerLayout.setDrawerListener(drawerToggle);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.operation_list, menu);
	
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		if (drawerToggle.onOptionsItemSelected(item)) {
			return true;
		}

		if (item.isChecked()) {
			return true;
		}

		switch (item.getItemId()) {
		case R.id.menu_new_operation: {

			startActivity(intentOperDetailsActivity);
			overridePendingTransition(R.anim.pull_in_right,
					R.anim.push_out_left);

			return true;
		}

		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}
	

	
	


}
