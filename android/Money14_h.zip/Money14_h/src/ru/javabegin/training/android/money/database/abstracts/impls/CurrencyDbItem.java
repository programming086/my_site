package ru.javabegin.training.android.money.database.abstracts.impls;

import ru.javabegin.training.android.money.database.abstracts.AbstractDbListItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.CurrencyItem;
import android.database.Cursor;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class CurrencyDbItem extends AbstractDbListItem<CurrencyItem> {

	protected CurrencyDbItem() {
	}

	@Override
	protected String getChildItemsSQL(int id) {
		StringBuilder builder = new StringBuilder();

		builder.append("select " + " c1._id as " + ALIAS_ID + ", c1.name  as "
				+ ALIAS_NAME + ", coalesce((select _id from " + CURRENCY_TABLE
				+ " c2 where c2.parent_id=c1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + ", c1.code as " + ALIAS_CODE
				+ ", c1.country as "+ALIAS_COUNTRY
				+ ", coalesce(c1.visible,0) as "+ALIAS_VISIBLE
				+ " from " + CURRENCY_TABLE + " c1 where coalesce(c1.parent_id,0) = " + id
				+ " and visible=1 "
				+ " order by c1.country");

		return builder.toString();
	}
	
	@Override
	protected String getRootItemsSQL() {
		StringBuilder builder = new StringBuilder();

		builder.append("select " + " c1._id as " + ALIAS_ID + ", c1.name  as "
				+ ALIAS_NAME + ", coalesce((select _id from " + CURRENCY_TABLE
				+ " c2 where c2.parent_id=c1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + ", c1.code as " + ALIAS_CODE
				+ ", c1.country as "+ALIAS_COUNTRY
				+ ", coalesce(c1.visible,0) as "+ALIAS_VISIBLE
				+ " from " + CURRENCY_TABLE + " c1 where coalesce(c1.parent_id,0) = 0 " 
				+ " and visible=1 "
				+ " order by c1.country");

		return builder.toString();
	}
	
	
	@Override
	protected String getAllItemsSQL() {
		StringBuilder builder = new StringBuilder();

		builder.append("select " + " c1._id as " + ALIAS_ID + ", c1.name  as "
				+ ALIAS_NAME + ", coalesce((select _id from " + CURRENCY_TABLE
				+ " c2 where c2.parent_id=c1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + ", c1.code as " + ALIAS_CODE
				+ ", c1.country as "+ALIAS_COUNTRY
				+ ", coalesce(c1.visible,0) as "+ALIAS_VISIBLE
				+ " from " + CURRENCY_TABLE + " c1 where coalesce(c1.parent_id,0) = 0 " 
				+ " order by c1.country");

		return builder.toString();
	}
	
	
	

	@Override
	protected String getOneItemSQL(int itemId) {

		StringBuilder builder = new StringBuilder();

		builder.append("select " + " c1._id as " + ALIAS_ID + ", c1.name  as "
				+ ALIAS_NAME + ", coalesce((select _id from " + CURRENCY_TABLE
				+ " c2 where c2.parent_id=c1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + ", c1.code as " + ALIAS_CODE
				+ ", c1.country as "+ALIAS_COUNTRY
				+ ", coalesce(c1.visible,0) as "+ALIAS_VISIBLE
				+ " from " + CURRENCY_TABLE + " c1 " + " where c1._id="
				+ itemId);
		return builder.toString();
	}

	@Override
	protected String getLastItemSQL() {
		StringBuilder builder = new StringBuilder();
		builder.append("select " + " c1._id as " + ALIAS_ID + ", c1.name  as "
				+ ALIAS_NAME + ", coalesce((select _id from " + CURRENCY_TABLE
				+ " c2 where c2.parent_id=c1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + ", c1.code as " + ALIAS_CODE
				+ ", c1.country as "+ALIAS_COUNTRY
				+ ", coalesce(c1.visible,0) as "+ALIAS_VISIBLE
				+ " from " + CURRENCY_TABLE + " c1 "
				+ " where c1._id=(select currency_id from "
				+ LAST_OPERATION_TABLE + ")");

		return builder.toString();
	}

	@Override
	protected CurrencyItem fillItem(Cursor c) {
		CurrencyItem item = new CurrencyItem();
		item.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
		item.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));
		item.setCode(c.getString(c.getColumnIndex(ALIAS_CODE)));
		item.setCountry(c.getString(c.getColumnIndex(ALIAS_COUNTRY)));
		item.setHasChilds(super.getBooleanFromInt(c.getInt(c.getColumnIndex(ALIAS_HAS_CHILD))));
		item.setVisible(getBooleanFromInt(c.getInt(c.getColumnIndex(ALIAS_VISIBLE))));
		return item;
	}

	public boolean switchCurrency(int currencyId, boolean visible) {
		SQLiteStatement stmt = null;
		try {
			
			stmt = getDatabase().compileStatement("update "+CURRENCY_TABLE+" set visible=?  where _id=?");
			if (visible){
				stmt.bindLong(1, 1);
			}else{
				stmt.bindLong(1, 0);
			}
			
			stmt.bindLong(2, currencyId);
			
			System.out.println(currencyId+", "+visible);
			
			stmt.executeUpdateDelete();
			return true;
			
			
		} catch (Exception e) {
			Log.e(tag, e.getMessage());			
		} finally {
			if (stmt != null) {
				stmt.close();
			}
		}

		return false;	
	}
	
	public boolean updateCurrency(CurrencyItem currencyItem){
		SQLiteStatement stmt = null;
		try {
			
			stmt = getDatabase().compileStatement("update "+CURRENCY_TABLE+" set visible=?, name=?, code=?, country=? where _id=?");
			if (currencyItem.isVisible()){
				stmt.bindLong(1, 1);
			}else{
				stmt.bindLong(1, 0);
			}
			
			stmt.bindString(2, currencyItem.getName());
			stmt.bindString(3, currencyItem.getCode());
			stmt.bindString(4, currencyItem.getCountry());
			stmt.bindLong(5, currencyItem.getId());
			stmt.executeUpdateDelete();
			return true;
		} catch (Exception e) {
			Log.e(tag, e.getMessage());			
		} finally {
			if (stmt != null) {
				stmt.close();
			}
		}

		return false;
	}
	
}
