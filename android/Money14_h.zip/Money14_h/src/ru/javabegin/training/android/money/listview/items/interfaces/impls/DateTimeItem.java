package ru.javabegin.training.android.money.listview.items.interfaces.impls;

import java.text.DateFormat;
import java.util.Calendar;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.activities.DatetimeActivity;
import ru.javabegin.training.android.money.activities.OperationDetailsActivity;
import ru.javabegin.training.android.money.listview.items.interfaces.Item;
import ru.javabegin.training.android.money.objects.AppContext;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class DateTimeItem implements Item {

	private static final String ICON_NAME = "time";

	private static final long serialVersionUID = 1L;

	public static final int REQUEST_CODE = 2;
	

	private Calendar calendar;

	public DateTimeItem() {
		calendar = Calendar.getInstance();
	}
	
	public DateTimeItem(Calendar calendar) {
		this.calendar = calendar;
	}


	public void setCalendar(Calendar calendar) {
		this.calendar = calendar;
	}
	
	public Calendar getCalendar() {
		return calendar;
	}

	@Override
	public Bitmap getImage() {
		int imageId = AppContext
				.getInstance()
				.getResources()
				.getIdentifier(ICON_NAME, "drawable",
						AppContext.getInstance().getPackageName());

		return BitmapFactory.decodeResource(AppContext.getInstance()
				.getResources(), imageId);
	}

	@Override
	public String getDisplayText() {
		return DateFormat.getDateInstance().format(calendar.getTime())+" - "+DateFormat.getTimeInstance().format(calendar.getTime());
	}

	@Override
	public String getSelectTitle() {
		return AppContext.getInstance().getResources().getString(R.string.datetime);
	}
	
	private Intent resultIntent;

	@Override
	public Intent getResultIntent() {
		resultIntent = new Intent(AppContext.getInstance(), OperationDetailsActivity.class);
		return resultIntent;
	}
	
	public void setResultIntent(Intent resultIntent) {
		this.resultIntent = resultIntent;
	}	

	@Override
	public Intent getClickIntent() {
		Intent intent = new Intent(AppContext.getInstance(), DatetimeActivity.class);
		intent.putExtra(AppContext.CALENDAR, calendar);
		return intent;
	}
	
}
