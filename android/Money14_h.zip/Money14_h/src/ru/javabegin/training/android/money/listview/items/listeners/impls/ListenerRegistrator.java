package ru.javabegin.training.android.money.listview.items.listeners.impls;

import java.util.ArrayList;
import java.util.List;

import ru.javabegin.training.android.money.listview.items.listeners.ChangeOperTypeListener;
import ru.javabegin.training.android.money.listview.items.listeners.ChangeOperTypeListenerRegistrator;

// можно поместить в этот класс все виды регистраторов (реализовывать любые интерфейсы)
public class ListenerRegistrator implements ChangeOperTypeListenerRegistrator{
	
	private ListenerRegistrator() {}
	
	private static ListenerRegistrator instance;
	
	public static ListenerRegistrator getInstance(){
		if (instance==null){
			instance = new ListenerRegistrator();
		}
		
		return instance;
	}


	private List<ChangeOperTypeListener> listeners = new ArrayList<ChangeOperTypeListener>();



	@Override
	public List<ChangeOperTypeListener> getListeners() {
		return listeners;
	}

	@Override
	public void addListener(ChangeOperTypeListener listener) {
		listeners.add(listener);		
	}

	@Override
	public void removeListener(ChangeOperTypeListener listener) {
		listeners.remove(listener);		
	}

	@Override
	public void removeListeners() {
		listeners.clear();
		
	}

	
	
	

}
