package ru.javabegin.training.android.money.activities;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.listview.adapters.ItemAdapter;
import ru.javabegin.training.android.money.listview.adapters.SprNameAdapter;
import ru.javabegin.training.android.money.listview.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.listview.items.interfaces.Item;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.DateTimeItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.DescriptionItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperTypeItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperationItem;
import ru.javabegin.training.android.money.listview.items.listeners.ChangeOperTypeListener;
import ru.javabegin.training.android.money.listview.items.listeners.impls.ListenerRegistrator;
import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.ListManager;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

// активити для создания/редактирования операции 
public class OperationDetailsActivity extends AnimationActivity implements ChangeOperTypeListener{

	public static final String SPR_LIST = "ru.javabegin.training.android.money.activities.sprList";


	private ListView listViewSpr;
	private ListView listViewCustom;

	private ArrayList<ListItem> listViewSprItems = new ArrayList<ListItem>(); // список item для справочной информации
	private ArrayList<Item> listViewCustomItems = new ArrayList<Item>(); // список item для несправочной информации

	private EditText txtAmount;

	private OperationItem operationItem;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_operation_details);

		txtAmount = (EditText) findViewById(R.id.txt_amount_input);

		listViewSpr = (ListView) findViewById(R.id.list_metadata);
		
		
		int id = getIntent().getIntExtra(AppContext.OPERATION_ID, 0);
		
		if (id > 0) {// если id>0 - значит режим редактирования
			operationItem = ListManager.getInstance().getOperation(id);
			operationItem.setEditMode(true);
		} else {// новая операция
			operationItem = new OperationItem(true);
		}
	
		txtAmount.setText(String.valueOf(operationItem.getAmount()));
	
		
		listViewSprItems.add(operationItem.getOperTypeItem());
		listViewSprItems.add(operationItem.getToCurrencyItem());
		listViewSprItems.add(operationItem.getOperSourceItem());		
		listViewSprItems.add(operationItem.getToStorageItem());
		

		listViewCustomItems.add(operationItem.getDescItem());
		listViewCustomItems.add(operationItem.getDateTimeItem());

			



		listViewSpr.setOnItemClickListener(new SprClickListener());

		listViewCustom = (ListView) findViewById(R.id.list_desc);
		listViewCustom.setOnItemClickListener(new ItemClickListener());

		listViewSpr.setAdapter(new SprNameAdapter(this, listViewSprItems));
		listViewCustom.setAdapter(new ItemAdapter(this, listViewCustomItems));

		addListeners();
		DbItemCreator.getOperSourceDbItem().setOperTypeId(operationItem.getOperTypeItem().getId());

		notifyItemSelected(operationItem.getOperTypeItem());
		
	}

	
	
	

	@Override
	public void finish() {
		// TODO Auto-generated method stub
		super.finish();
		removeListeners();
	}
	
	private void removeListeners() {
		ListenerRegistrator.getInstance().removeListener(operationItem.getOperSourceItem());
		ListenerRegistrator.getInstance().removeListener(DbItemCreator.getOperSourceDbItem());		
		ListenerRegistrator.getInstance().removeListener(this);				
	}

	
	private void addListeners(){
		ListenerRegistrator.getInstance().addListener(operationItem.getOperSourceItem());
		ListenerRegistrator.getInstance().addListener(DbItemCreator.getOperSourceDbItem());	
		ListenerRegistrator.getInstance().addListener(this);		
	}

	


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.operation_details, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {

		case R.id.save_operation:
			
			if (canSave()) {

				BigDecimal amount = new BigDecimal(txtAmount.getText().toString());
				operationItem.setNewAmount(amount);
				operationItem.save();
				removeListeners();
				super.closeActivity();
			}
			break;

		case R.id.delete:

			AlertDialog.Builder builder = new AlertDialog.Builder(
					OperationDetailsActivity.this);
			builder.setMessage(getResources()
					.getString(R.string.confirm_delete));
			builder.setTitle(getResources().getString(R.string.confirm_title));

			builder.setNegativeButton("NO",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							dialog.cancel();
						}
					});

			builder.setPositiveButton("YES",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {

							if (operationItem.isEditMode()) {
								removeListeners();
								DbItemCreator.getOperationDbItem()
										.deleteOperation(operationItem);
							}
							OperationDetailsActivity.super.closeActivity();
							

							Toast.makeText(
									OperationDetailsActivity.this,
									getResources().getString(
											R.string.deleted_title),
									Toast.LENGTH_SHORT).show();
						}
					});

			builder.create().show();

			break;

		}

		return super.onOptionsItemSelected(item);
	}

	private boolean canSave() {
		
		// TODO проверять, чтобы сумма была больше 0 и выбраны все нужные значения
		
		// получаем актуальное id типа операции
		int id = operationItem.getOperTypeItem().getSelectedChildItem()!=null?operationItem.getOperTypeItem().getSelectedChildItem().getId():operationItem.getOperTypeItem().getId();
		
		if (id == OperationType.TRANSFER.getId()) {
			
		}
		
		return true;
	}


	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);

		// если выбрано какое-то значение справочника
		if (intent.getExtras() != null && !intent.getExtras().isEmpty()) {

			AbstractSprItem selectedChildItem = (AbstractSprItem) intent.getSerializableExtra(AppContext.SELECTED_ITEM);

			AbstractSprItem parentItem = (AbstractSprItem) currentChangingItem;

			int selectedId = selectedChildItem.getId();
			int prevId = 0;

			// проверяем, выбрали новое значение или нет
			if (parentItem.getSelectedChildItem() != null) {
				prevId = parentItem.getSelectedChildItem().getId();
			}

			if (parentItem.getSelectedChildItem() == null) {
				prevId = parentItem.getId();
			}

			if (selectedId == prevId) {
				return;
			}

			parentItem.setSelectedChildItem(selectedChildItem);

			((SprNameAdapter) listViewSpr.getAdapter()).notifyDataSetChanged();

		}

	}

	private ListItem currentChangingItem;
	
	// слушатель для выбора справочных значений
	private class SprClickListener implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

			ListItem item = (ListItem) parent.getAdapter().getItem(position);
			currentChangingItem = item; // сохраняем ссылку на item, который сейчас выбираем, чтобы знать, какое значение потом обновлять после выбора
			Intent intent = item.getClickIntent();
			intent.putExtra(AppContext.SELECT_ROOT, true);
			startActivity(intent);
			overridePendingTransition(R.anim.pull_in_right, R.anim.push_out_left);

		}

	}

	// слушатель для изменения несправочных значений
	private class ItemClickListener implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {

			Item item = (Item) parent.getAdapter().getItem(position);

			switch (position) {
			case 0: // редактирование Description
				startActivityForResult(item.getClickIntent(), DescriptionItem.REQUEST_CODE);
				break;

			case 1: // редактирование даты и времени
				startActivityForResult(item.getClickIntent(), DateTimeItem.REQUEST_CODE);
			}

			overridePendingTransition(R.anim.pull_in_right, R.anim.push_out_left);

		}

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == RESULT_OK) {

			switch (requestCode) {
			case DescriptionItem.REQUEST_CODE:
				operationItem.getDescItem().setDisplayText(
						data.getStringExtra(DescriptionItem.TEXT));
				((ItemAdapter) listViewCustom.getAdapter()).notifyDataSetChanged();
				break;
			case DateTimeItem.REQUEST_CODE:
				Calendar c = (Calendar) data
						.getSerializableExtra(AppContext.CALENDAR);
				operationItem.getDateTimeItem().setCalendar(c);
				((ItemAdapter) listViewCustom.getAdapter()).notifyDataSetChanged();
			}

		}

	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		super.onSaveInstanceState(outState);
		// outState.putSerializable(SPR_LIST, sprNamesMap);
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onRestoreInstanceState(savedInstanceState);
		// sprNamesMap = (LinkedHashMap<String, SprNameItem>)
		// savedInstanceState.get(SPR_LIST);
	}

	
	
	@Override
	public void notifyItemSelected(ListItem item) {
		
		if (item instanceof OperTypeItem) {// если изменился тип операции
			
			int id = item.getId();

			// манипуляция с пунктами, какие показывать, какие скрывать
			if (id == OperationType.TRANSFER.getId()) {
				listViewSprItems.add(3, operationItem.getFromStorageItem());
				listViewSprItems.remove(operationItem.getOperSourceItem());

			}else if (id == OperationType.CONVERT.getId()) {
				listViewSprItems.add(3, operationItem.getFromStorageItem());
				listViewSprItems.remove(operationItem.getOperSourceItem());
				
				
			} else {
				if (!listViewSprItems.contains(operationItem.getOperSourceItem())) {
					listViewSprItems.add(2, operationItem.getOperSourceItem());
				} 

				if (listViewSprItems.contains(operationItem.getFromStorageItem())) {
					listViewSprItems.remove(operationItem.getFromStorageItem());
				}				

			}

			((ItemAdapter) listViewCustom.getAdapter()).notifyDataSetChanged();
		}

	}
	

}
