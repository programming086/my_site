package ru.javabegin.training.android.money.database.abstracts;

import ru.javabegin.training.android.money.database.interfaces.impls.MoneyDbConnector;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public abstract class AbstractDbItem{

	private static MoneyDbConnector moneyDbAdapter = new MoneyDbConnector();

	protected String tag = null;

	protected Cursor cursor = null;

	public AbstractDbItem() {
		tag = this.getClass().getName();
	}

	protected SQLExecutor sqlExecutor = new SQLExecutor();

	public static final String ALIAS_ID = "_id";
	public static final String ALIAS_AMOUNT = "amount";
	public static final String ALIAS_CURRENCY = "currency";
	public static final String ALIAS_DESC = "description";
	public static final String ALIAS_OPERATION_DATETIME = "operationDateTime";
	public static final String ALIAS_SOURCE = "source";
	public static final String ALIAS_TYPE_NAME = "type";
	public static final String ALIAS_TYPE_ID = "type_id";
	public static final String ALIAS_SOURCE_ID = "sourceId";
	public static final String ALIAS_TO_STORAGE_ID = "toStorageId";
	public static final String ALIAS_FROM_STORAGE_ID = "fromStorageId";
	public static final String ALIAS_TO_CURRENCY_ID = "toCurrencyId";
	public static final String ALIAS_FROM_CURRENCY_ID = "fromCurrencyId";
	public static final String ALIAS_HAS_DISABLE_STATE = "hasDisableState";

	public static final String ALIAS_NAME = "itemName";
	public static final String ALIAS_CODE = "itemCode";
	public static final String ALIAS_COUNTRY = "itemCountry";
	public static final String ALIAS_HAS_CHILD = "hasChild";
	public static final String ALIAS_ALLOW = "visible";
	public static final String ALIAS_TABLE_NAME = "tableName";
	public static final String ALIAS_DATETIME = "dateTime";

	public static final String OPERATIONS_TABLE = "operations";
	public static final String LAST_OPERATION_TABLE = "last_operation";
	public static final String BALANCE_TABLE = "balance";
	public static final String STORAGE_TABLE = "spr_StorageType";
	public static final String OPER_TYPE_TABLE = "spr_OperationType";
	public static final String CURRENCY_TABLE = "spr_Currency";
	public static final String OPER_SOURCE_TABLE = "spr_OperationSource";
	public static final String METADATA_TABLE = "spr_Metadata";

	
	protected SQLiteDatabase getDatabase(){
		return moneyDbAdapter.getDatabase();
	}


	protected void closeCursor() {
		if (cursor != null) {
			cursor.close();
		}
	}

	protected class SQLExecutor {

		public Cursor execFirstResult(String sql) {
			return execFirstResult(sql, null);
		}

		public Cursor execFirstResult(String sql, String[] selectionArgs) {

			Cursor c = null;
			c = execSQL(sql, selectionArgs);
			c.moveToFirst();

			return c;
		}

		public Cursor execSQL(String sql) {
			Cursor c = execSQL(sql, null);
			return c;
		}

		public Cursor execSQL(String sql, String[] selectionArgs) {
//			Log.d(tag, sql);
			Cursor c = moneyDbAdapter.getDatabase().rawQuery(sql, selectionArgs);
			return c;
		}
	}

}
