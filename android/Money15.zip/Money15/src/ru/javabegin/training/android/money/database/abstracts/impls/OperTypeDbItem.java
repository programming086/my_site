package ru.javabegin.training.android.money.database.abstracts.impls;

import ru.javabegin.training.android.money.database.abstracts.AbstractDbListItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.OperTypeItem;
import android.database.Cursor;

public class OperTypeDbItem extends AbstractDbListItem<OperTypeItem> {


	@Override
	protected String getChildItemsSQL(int id) {
		StringBuilder builder = new StringBuilder();

		builder.append("select "
				+ " s1._id as "
				+ ALIAS_ID
				+ ", s1.name  as "
				+ ALIAS_NAME
				+ ", coalesce((select _id from "
				+ OPER_TYPE_TABLE
				+ " s2 where s2.parent_id=s1._id limit 1),0)  as  "+ALIAS_HAS_CHILD 
				+ " from " + OPER_TYPE_TABLE + " s1 "
				+ " where coalesce(s1.parent_id,0) = " + id
				+ " order by order_show");

		return builder.toString();
	}
	
	@Override
	protected String getRootItemsSQL() {
		StringBuilder builder = new StringBuilder();

		builder.append("select "
				+ " s1._id as "
				+ ALIAS_ID
				+ ", s1.name  as "
				+ ALIAS_NAME
				+ ", coalesce((select _id from "
				+ OPER_TYPE_TABLE
				+ " s2 where s2.parent_id=s1._id limit 1),0)  as  "+ALIAS_HAS_CHILD 
				+ " from " + OPER_TYPE_TABLE + " s1 "
				+ " where coalesce(s1.parent_id,0) = 0"
				+ " order by order_show");

		return builder.toString();
	}

	@Override
	protected String getOneItemSQL(int itemId) {

		StringBuilder builder = new StringBuilder();

		builder.append("select " + " op1._id as " + ALIAS_ID
				+ ", op1.name  as " + ALIAS_NAME
				+ ", coalesce((select _id from " + OPER_TYPE_TABLE
				+ " c2 where c2.parent_id=op1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + " from " + OPER_TYPE_TABLE + " op1 "
				+ " where op1._id="+itemId);

		return builder.toString();
	}

	@Override
	protected String getLastItemSQL() {
		StringBuilder builder = new StringBuilder();

		builder.append("select " + " op1._id as " + ALIAS_ID
				+ ", op1.name  as " + ALIAS_NAME
				+ ", coalesce((select _id from " + OPER_TYPE_TABLE
				+ " c2 where c2.parent_id=op1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + " from " + OPER_TYPE_TABLE + " op1 "
				+ " where op1._id=(select type_id from " + LAST_OPERATION_TABLE
				+ ")");

		return builder.toString();
	}

	protected OperTypeItem fillItem(Cursor c) {
		OperTypeItem item = new OperTypeItem();
		item.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));		
		item.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));
		item.setHasChilds(super.getBooleanFromInt(c.getInt(c.getColumnIndex(ALIAS_HAS_CHILD))));
		return item;
	}

	public OperTypeItem getDefaultItem() {
		
		StringBuilder builder = new StringBuilder();

		builder.append("select " + " op1._id as " + ALIAS_ID
				+ ", op1.name  as " + ALIAS_NAME
				+ ", coalesce((select _id from " + OPER_TYPE_TABLE
				+ " c2 where c2.parent_id=op1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + " from " + OPER_TYPE_TABLE + " op1 "
				+ " order by order_show asc limit 0,1 ");
		
		return super.fillOneItem(builder.toString());

	}

}
