package ru.javabegin.training.android.money.database.interfaces;

import android.database.sqlite.SQLiteDatabase;

public interface DbConnector {
	
	SQLiteDatabase getDatabase();
	
	void closeDatabase();

}
