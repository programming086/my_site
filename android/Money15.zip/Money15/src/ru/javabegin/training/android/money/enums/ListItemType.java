package ru.javabegin.training.android.money.enums;

public enum ListItemType {
	
	FROM, TO;

}
