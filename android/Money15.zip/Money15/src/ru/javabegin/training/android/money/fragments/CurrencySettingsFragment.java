package ru.javabegin.training.android.money.fragments;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.activities.CurrencyActivity;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.adapters.CurrencyAdapter;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.CurrencyItem;
import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.ListManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;

public class CurrencySettingsFragment extends AbstractListFragment {
	
	private Intent currencyDetailsIntent;

	@Override
	protected ListAdapter getAdapter() {		
		ArrayList<CurrencyItem> list = DbItemCreator.getCurrencyDbItem().getAllItems();		
		ListManager.getInstance().setCurrencyList(list);
		CurrencyAdapter adapter = new CurrencyAdapter(getActivity(), list);
		return adapter;
	}


	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		currencyDetailsIntent = new Intent(getActivity(), CurrencyActivity.class);
	}
	
	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		// TODO Auto-generated method stub
		super.onListItemClick(l, v, position, id);		
		currencyDetailsIntent.putExtra(AppContext.CURRENCY_INDEX, position);
		getActivity().startActivity(currencyDetailsIntent);
		getActivity().overridePendingTransition(R.anim.pull_in_right, R.anim.push_out_left);
	}
	
	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		
		ArrayList<CurrencyItem> list = DbItemCreator.getCurrencyDbItem().getAllItems();		
		
		// TODO исправить:  обновлять только нужные записи, постоянно делать запрос в базу - неправильно!	
		ListManager.getInstance().setCurrencyList(list);
		((CurrencyAdapter)getListAdapter()).update(list);
	}
}
