package ru.javabegin.training.android.money.listview.adapters;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.CurrencyDbItem;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.CurrencyItem;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

public class CurrencyAdapter extends ArrayAdapter<CurrencyItem> {
	private Context context;
	private ArrayList<CurrencyItem> currencyList;

	public CurrencyAdapter(Context context, ArrayList<CurrencyItem> currencyList) {
		super(context, R.layout.listview_item_currency, currencyList);
		this.context = context;
		this.currencyList = currencyList;
	}

	public View getView(final int position, View convertView, ViewGroup parent) {

		if (convertView == null) {

			ViewHolder holder = new ViewHolder();
			
			LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(R.layout.listview_item_currency, parent, false);

			holder.currencyImage = (ImageView) convertView.findViewById(R.id.currency_image);
			holder.currencyCountry = (TextView) convertView.findViewById(R.id.currency_country);
			holder.currencyName = (TextView) convertView.findViewById(R.id.currency_name);
			holder.currencyCode = (TextView) convertView.findViewById(R.id.currency_code);
			holder.currencySwitch = (Switch) convertView.findViewById(R.id.currency_switch);			

			convertView.setTag(holder);
		}

		final ViewHolder holder = (ViewHolder) convertView.getTag();

		CurrencyItem item = getItem(position);

		holder.currencyCountry.setText(item.getCountry());
		holder.currencyName.setText(item.getName());
		holder.currencyCode.setText("("+item.getCode()+")");
		holder.currencySwitch.setChecked(item.isAllow());
		
		holder.currencySwitch.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				DbItemCreator.getCurrencyDbItem().switchCurrency(getItem(position).getId(), holder.currencySwitch.isChecked());// обновляем в базе
				getItem(position).setAllow(holder.currencySwitch.isChecked());
			}
		});
		
		String imageName = CurrencyDbItem.CURRENCY_TABLE.toLowerCase()+ item.getId();
		
		try {
			holder.currencyImage.setImageBitmap(getImage(imageName));
		} catch (Exception e) {
			e.printStackTrace();
		}


		return convertView;
	}

	@Override
	public int getCount() {
		return currencyList.size();
	}

	@Override
	public CurrencyItem getItem(int index) {
		return currencyList.get(index);
	}

	@Override
	public long getItemId(int index) {
		return currencyList.get(index).getId();
	}

	protected static class ViewHolder {
		public TextView currencyCountry;
		public TextView currencyName;
		public TextView currencyCode;
		public ImageView currencyImage;
		public Switch currencySwitch;
	}
	
	private Bitmap getImage(String name) {
		int imageId = context.getResources().getIdentifier(name, "drawable",	context.getPackageName());	
		return BitmapFactory.decodeResource(context.getResources(), imageId);
	}

	

	
	public void update(ArrayList<CurrencyItem> currencyList){
		this.currencyList.clear();
		this.currencyList.addAll(currencyList);		
		notifyDataSetChanged();		
	}
	

}