package ru.javabegin.training.android.money.listview.adapters;

import java.util.ArrayList;

import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;

public class SprValueAdapter extends AbstractAdapter<ListItem> {

	private static final long serialVersionUID = 1L;

	public SprValueAdapter(Context context, ArrayList<ListItem> objects) {
		super(context, objects);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		convertView = getView(convertView, parent);

		ViewHolder holder = (ViewHolder) convertView.getTag();

		ListItem item = (ListItem) getItem(position);

		holder.txtSprName.setText(item.getName());		

		if (item.hasChilds()) {
			holder.imageArrow.setVisibility(View.VISIBLE);
		} else {
			holder.imageArrow.setVisibility(View.INVISIBLE);
		}

		Bitmap bitmap = item.getImage();

		if (bitmap != null) {
			holder.image.setImageBitmap(bitmap);
		} else {
			holder.image.setImageBitmap(super.getNoIconImage());
		}

		return convertView;

	}	


}
