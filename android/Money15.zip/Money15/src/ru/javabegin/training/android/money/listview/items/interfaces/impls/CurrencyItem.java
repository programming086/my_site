package ru.javabegin.training.android.money.listview.items.interfaces.impls;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.enums.ListItemType;
import ru.javabegin.training.android.money.listview.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import ru.javabegin.training.android.money.listview.items.listeners.ChangeOperTypeListener;
import ru.javabegin.training.android.money.listview.items.listeners.ChangeOperTypeNotifier;
import ru.javabegin.training.android.money.listview.items.listeners.impls.ListenerRegistrator;
import ru.javabegin.training.android.money.objects.AppContext;

public class CurrencyItem extends AbstractSprItem  implements ChangeOperTypeNotifier{

	private static final long serialVersionUID = 1L;

	private static final String TABLE_NAME = "spr_Currency";
	
	private boolean allow;
	private String code;
	private String country;
	
	private ListItemType listItemType = ListItemType.FROM; // по-умолчанию счет имеет тип "ИЗ"

	
	public CurrencyItem() {		
		setTableName(TABLE_NAME);
		setName(AppContext.getInstance().getResources().getString(R.string.currency));
	}
	
	public CurrencyItem(ListItemType listItemType) {
		this();
		this.listItemType = listItemType;
	}


	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}

	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}

	
	
	
	@Override
	public String getSelectTitle() {
		return AppContext.getInstance().getResources().getString(R.string.currency);
	}


	@Override
	public void notifyListeners() {		
		ListItem item = getSelectedChildItem()!=null?getSelectedChildItem():this;// передавать текущий или новый выбранный элемент
		for (ChangeOperTypeListener listener : ListenerRegistrator.getInstance().getListeners()) {
			listener.notifyItemSelected(item);
		}
		
	}
	
	@Override
	public void setSelectedChildItem(ListItem selectedChildItem) {
		// TODO Auto-generated method stub
		super.setSelectedChildItem(selectedChildItem);
		notifyListeners();
	}
	
	public boolean isAllow() {
		return allow;
	}
	
	public void setAllow(boolean allow) {
		this.allow = allow;
	}

	@Override
	public ArrayList<ListItem> getList(boolean selectRoot) {
		if (!selectRoot){
			return new ArrayList<ListItem>(DbItemCreator.getCurrencyDbItem().getChildItems(getId()));
		}else{
			return new ArrayList<ListItem>(DbItemCreator.getCurrencyDbItem().getRootItems());
		}
	}
	
	@Override
	public String toString() {
		return super.toString()+listItemType;
	}

	

}
