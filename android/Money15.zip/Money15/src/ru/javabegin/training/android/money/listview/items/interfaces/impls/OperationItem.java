package ru.javabegin.training.android.money.listview.items.interfaces.impls;

import java.io.Serializable;
import java.math.BigDecimal;

import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;

public class OperationItem implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private int id;
	private boolean editMode;	
	
	private OperTypeItem operTypeItem;
	private OperSourceItem operSourceItem;
	private StorageItem toStorageItem;
	private StorageItem fromStorageItem;
	
	
	private CurrencyItem toCurrencyItem;
	private CurrencyItem fromCurrencyItem;
	
	private DescriptionItem descItem;
	private DateTimeItem dateTimeItem;
	
	private BigDecimal newAmount;// хранит новое введенное пользователем значение
	private BigDecimal amount;// хранит старое значение (при редактировании), до изменения - это нужно для правильного обновления баланса
		
	
	public OperationItem() {
	}
	
	public OperationItem(boolean attemptFillLastValues) {// пытаемся установить последние выбранные значения
		if (attemptFillLastValues && DbItemCreator.getOperationDbItem().hasLastOperation()) {
			OperationItem item = DbItemCreator.getOperationDbItem().getLastItem();
			operTypeItem = item.getOperTypeItem();
			operSourceItem = item.getOperSourceItem();
			toStorageItem = item.getToStorageItem();
			fromStorageItem = item.getFromStorageItem();
			
			toCurrencyItem = item.getToCurrencyItem();
			fromCurrencyItem = item.getFromCurrencyItem();
			
			amount = item.getAmount();
			
			descItem = item.getDescItem();
			dateTimeItem = item.getDateTimeItem();
		}
	
		
	}

	public boolean save() {
		return DbItemCreator.getOperationDbItem().saveOperation(this);
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public boolean isEditMode() {
		return editMode;
	}


	public void setEditMode(boolean editMode) {
		this.editMode = editMode;
	}


	public OperTypeItem getOperTypeItem() {
		return operTypeItem;
	}


	public void setOperTypeItem(OperTypeItem operTypeItem) {
		this.operTypeItem = operTypeItem;
	}


	public OperSourceItem getOperSourceItem() {
		return operSourceItem;
	}


	public void setOperSourceItem(OperSourceItem operSourceItem) {
		this.operSourceItem = operSourceItem;
	}


	public StorageItem getToStorageItem() {
		return toStorageItem;
	}


	public void setToStorageItem(StorageItem toStorageItem) {
		this.toStorageItem = toStorageItem;
	}


	public StorageItem getFromStorageItem() {
		return fromStorageItem;
	}


	public void setFromStorageItem(StorageItem fromStorageItem) {
		this.fromStorageItem = fromStorageItem;
	}


	public CurrencyItem getToCurrencyItem() {
		return toCurrencyItem;
	}


	public void setToCurrencyItem(CurrencyItem toCurrencyItem) {
		this.toCurrencyItem = toCurrencyItem;
	}


	public CurrencyItem getFromCurrencyItem() {
		return fromCurrencyItem;
	}


	public void setFromCurrencyItem(CurrencyItem fromCurrencyItem) {
		this.fromCurrencyItem = fromCurrencyItem;
	}


	public DescriptionItem getDescItem() {
		return descItem;
	}


	public void setDescItem(DescriptionItem descItem) {
		this.descItem = descItem;
	}


	public DateTimeItem getDateTimeItem() {
		return dateTimeItem;
	}


	public void setDateTimeItem(DateTimeItem dateTimeItem) {
		this.dateTimeItem = dateTimeItem;
	}


	public BigDecimal getNewAmount() {
		return newAmount;
	}


	public void setNewAmount(BigDecimal newAmount) {
		this.newAmount = newAmount;
	}


	public BigDecimal getAmount() {
		return amount;
	}


	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	
}
