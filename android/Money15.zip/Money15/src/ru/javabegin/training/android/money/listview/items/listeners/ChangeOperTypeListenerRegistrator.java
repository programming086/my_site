package ru.javabegin.training.android.money.listview.items.listeners;

import java.util.List;

// регистратор
public interface ChangeOperTypeListenerRegistrator {
	
	List<ChangeOperTypeListener> getListeners();

    void addListener(ChangeOperTypeListener listener);

    public void removeListener(ChangeOperTypeListener listener);

    public void removeListeners();

}
