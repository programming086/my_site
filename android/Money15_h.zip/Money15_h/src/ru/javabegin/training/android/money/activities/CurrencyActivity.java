package ru.javabegin.training.android.money.activities;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.items.CurrencyItem;
import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.ListManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Switch;

public class CurrencyActivity extends AnimationActivity {

    private EditText editCurrencyName;
    private EditText editCurrencyCountry;
    private EditText editCurrencyCode;
    private Switch switchCurrency;

    private CurrencyItem currencyItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.activity_currency);

	editCurrencyName = (EditText) findViewById(R.id.editCurrencyName);
	editCurrencyCountry = (EditText) findViewById(R.id.editCurrencyCountry);
	editCurrencyCode = (EditText) findViewById(R.id.editCurrencyCode);
	switchCurrency = (Switch) findViewById(R.id.switchCurrencyEdit);

	int index = getIntent().getIntExtra(AppContext.CURRENCY_INDEX, 0);

	currencyItem = ListManager.getInstance().getCurrencyItem(index);

	editCurrencyName.setText(currencyItem.getName());
	editCurrencyCode.setText(currencyItem.getCode());
	editCurrencyCountry.setText(currencyItem.getCountry());
	switchCurrency.setChecked(currencyItem.isAllow());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
	// Inflate the menu; this adds items to the action bar if it is present.
	getMenuInflater().inflate(R.menu.currency, menu);
	return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

	switch (item.getItemId()) {

	case R.id.save_currency:
	    currencyItem.setName(editCurrencyName.getText().toString());
	    currencyItem.setCode(editCurrencyCode.getText().toString());
	    currencyItem.setCountry(editCurrencyCountry.getText().toString());
	    currencyItem.setAllow(switchCurrency.isChecked());

	    DbItemCreator.getCurrencyDbItem().updateCurrency(currencyItem);

	    super.closeActivity();
	    break;

	}

	return super.onOptionsItemSelected(item);
    }

}
