package ru.javabegin.training.android.money.activities;

import java.util.ArrayList;
import java.util.Calendar;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.listview.adapters.OperDetailsAdapter;
import ru.javabegin.training.android.money.listview.items.DateTimeItem;
import ru.javabegin.training.android.money.listview.items.DescriptionItem;
import ru.javabegin.training.android.money.listview.items.HeaderItem;
import ru.javabegin.training.android.money.listview.items.OperTypeItem;
import ru.javabegin.training.android.money.listview.items.OperationItem;
import ru.javabegin.training.android.money.listview.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.listview.items.interfaces.BaseItem;
import ru.javabegin.training.android.money.listview.items.interfaces.OpenActivityItem;
import ru.javabegin.training.android.money.listview.items.interfaces.SelectSprValueItem;
import ru.javabegin.training.android.money.listview.items.interfaces.Validator;
import ru.javabegin.training.android.money.listview.items.listeners.ChangeOperTypeListener;
import ru.javabegin.training.android.money.listview.items.listeners.impls.ListenerRegistrator;
import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.ListManager;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

// активити для создания/редактирования операции 
public class OperationDetailsActivity extends AnimationActivity implements ChangeOperTypeListener {

    public static final String SPR_LIST = "ru.javabegin.training.android.money.activities.sprList";

    private ListView listView;
    private ArrayList<BaseItem> items = new ArrayList<BaseItem>();
    private OperDetailsAdapter<BaseItem> adapter; // адаптер для отображения деталей операции
    private OperationItem operationItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.activity_operation_details);

	listView = (ListView) findViewById(R.id.list_metadata);

	int id = getIntent().getIntExtra(AppContext.OPERATION_ID, 0);

	if (id > 0) {// если id>0 - значит открывается уже существующая операция
	    operationItem = ListManager.getInstance().getOperation(id);
	    operationItem.setEditMode(true);
	} else {// новая операция
	    operationItem = new OperationItem(true);
	}

	listView.setOnItemClickListener(new ItemClickListener());

	adapter = new OperDetailsAdapter<BaseItem>(this, items);
	listView.setAdapter(adapter);

	addListeners();
	DbItemCreator.getOperSourceDbItem().setOperTypeId(operationItem.getOperTypeItem().getId());

	changeItems(OperationType.getType(operationItem.getOperTypeItem().getId()), items);

    }

    // меняет состав строк для каждого типа операции
    private void changeItems(OperationType operationType, ArrayList<BaseItem> items) {
	items.clear();

	switch (operationType) {
	case INCOME:

	    createIncomeItems(items);

	    break;
	case OUTCOME:

	    createOutcomeItems(items);

	    break;

	case CONVERT:

	    createConvertItems(items);

	    break;

	case TRANSFER:

	    createTransferItems(items);

	    break;

	default:

	    createIncomeItems(items);

	}

	((OperDetailsAdapter) listView.getAdapter()).notifyDataSetChanged();
    }

    private void createIncomeItems(ArrayList<BaseItem> items) {
	items.add(operationItem.getOperTypeItem());
	items.add(operationItem.getToAmountItem());
	items.add(operationItem.getToCurrencyItem());

	items.add(new HeaderItem(getResources().getString(R.string.to)));
	items.add(operationItem.getOperSourceItem());
	items.add(operationItem.getToStorageItem());

	items.add(new HeaderItem(getResources().getString(R.string.additional)));
	items.add(operationItem.getDescItem());
	items.add(operationItem.getDateTimeItem());
    }

    private void createOutcomeItems(ArrayList<BaseItem> items) {

	items.add(operationItem.getOperTypeItem());
	items.add(operationItem.getFromAmountItem());
	items.add(operationItem.getFromCurrencyItem());

	items.add(new HeaderItem(getResources().getString(R.string.from)));
	items.add(operationItem.getOperSourceItem());
	items.add(operationItem.getFromStorageItem());

	items.add(new HeaderItem(getResources().getString(R.string.additional)));
	items.add(operationItem.getDescItem());
	items.add(operationItem.getDateTimeItem());
    }

    private void createTransferItems(ArrayList<BaseItem> items) {
	items.add(operationItem.getOperTypeItem());
	items.add(operationItem.getFromAmountItem());
	items.add(operationItem.getFromCurrencyItem());

	items.add(new HeaderItem(getResources().getString(R.string.from)));
	items.add(operationItem.getFromStorageItem());

	items.add(new HeaderItem(getResources().getString(R.string.to)));
	items.add(operationItem.getToStorageItem());

	items.add(new HeaderItem(getResources().getString(R.string.additional)));
	items.add(operationItem.getDescItem());
	items.add(operationItem.getDateTimeItem());
    }

    private void createConvertItems(ArrayList<BaseItem> items) {
	items.add(operationItem.getOperTypeItem());

	items.add(new HeaderItem(getResources().getString(R.string.from)));
	items.add(operationItem.getFromAmountItem());
	items.add(operationItem.getFromCurrencyItem());
	items.add(operationItem.getFromStorageItem());

	items.add(new HeaderItem(getResources().getString(R.string.to)));
	items.add(operationItem.getToAmountItem());
	items.add(operationItem.getToCurrencyItem());
	items.add(operationItem.getToStorageItem());

	items.add(new HeaderItem(getResources().getString(R.string.additional)));
	items.add(operationItem.getDescItem());
	items.add(operationItem.getDateTimeItem());
    }

    @Override
    public void finish() {
	// TODO Auto-generated method stub
	super.finish();
	removeListeners();
    }

    private void removeListeners() {
	ListenerRegistrator.getInstance().removeListener(operationItem.getOperSourceItem());
	ListenerRegistrator.getInstance().removeListener(DbItemCreator.getOperSourceDbItem());
	ListenerRegistrator.getInstance().removeListener(this);
    }

    private void addListeners() {
	ListenerRegistrator.getInstance().addListener(operationItem.getOperSourceItem());
	ListenerRegistrator.getInstance().addListener(DbItemCreator.getOperSourceDbItem());
	ListenerRegistrator.getInstance().addListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
	// Inflate the menu; this adds items to the action bar if it is present.
	getMenuInflater().inflate(R.menu.operation_details, menu);
	return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

	switch (item.getItemId()) {

	case R.id.save_operation:

	    if (canSave()) {
		operationItem.save();
		removeListeners();
		super.closeActivity();
	    }

	    break;

	case R.id.delete:

	    AlertDialog.Builder builder = new AlertDialog.Builder(OperationDetailsActivity.this);
	    builder.setMessage(getResources().getString(R.string.confirm_delete));
	    builder.setTitle(getResources().getString(R.string.confirm_title));

	    builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
		public void onClick(DialogInterface dialog, int which) {
		    dialog.cancel();
		}
	    });

	    builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
		public void onClick(DialogInterface dialog, int which) {

		    if (operationItem.isEditMode()) {
			removeListeners();
			DbItemCreator.getOperationDbItem().deleteOperation(operationItem);
		    }
		    OperationDetailsActivity.super.closeActivity();

		    Toast.makeText(OperationDetailsActivity.this, getResources().getString(R.string.deleted_title), Toast.LENGTH_SHORT).show();
		}
	    });

	    builder.create().show();

	    break;

	}

	return super.onOptionsItemSelected(item);
    }

    private void showEmptyFieldDialog(Validator item) {
	AlertDialog.Builder builder = new AlertDialog.Builder(OperationDetailsActivity.this);
	builder.setMessage(item.getErrorValidateMessage());
	builder.setTitle(getResources().getString(R.string.empty_field));

	builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
	    public void onClick(DialogInterface dialog, int which) {
		dialog.cancel();
	    }
	});

	builder.create().show();
    }

    private boolean canSave() {

	boolean success = false;

	Validator errorItem = validate(operationItem.getOperTypeItem());

	if (errorItem != null) {
	    showEmptyFieldDialog(errorItem);
	    return false;
	}

	int operTypeid = operationItem.getOperTypeItem().getSelectedChildItem() != null ? operationItem.getOperTypeItem().getSelectedChildItem().getId() : operationItem.getOperTypeItem().getId();

	OperationType operationType = OperationType.getType(operTypeid);

	switch (operationType) {
	case INCOME:

	    errorItem = validate(operationItem.getToCurrencyItem(), operationItem.getOperSourceItem(), operationItem.getToStorageItem()/* , operationItem.getToAmountItem() */);

	    break;
	case OUTCOME:

	    errorItem = validate(operationItem.getFromCurrencyItem(), operationItem.getOperSourceItem(), operationItem.getFromStorageItem()/* , operationItem.getFromAmountItem() */);

	    break;

	case TRANSFER:

	    errorItem = validate(operationItem.getFromCurrencyItem(), operationItem.getFromStorageItem()/* , operationItem.getFromAmountItem() */, operationItem.getToStorageItem()/* , operationItem.getToAmountItem() */);

	    break;

	case CONVERT:

	    errorItem = validate(operationItem.getFromCurrencyItem(), operationItem.getFromStorageItem()/* , operationItem.getFromAmountItem() */, operationItem.getToCurrencyItem(), operationItem.getToStorageItem()/* , operationItem.getToAmountItem() */);

	    break;

	default:
	    break;
	}

	if (errorItem != null) {
	    showEmptyFieldDialog(errorItem);
	} else {
	    success = true;
	}

	return success;

    }

    private Validator validate(Validator... item) {

	for (int i = 0; i < item.length; i++) {
	    if (!item[i].validate()) {
		return item[i];
	    }
	}
	return null;
    }

    @Override
    protected void onNewIntent(Intent intent) {
	// TODO Auto-generated method stub
	super.onNewIntent(intent);

	// если выбрано какое-то значение справочника
	if (intent.getExtras() != null && !intent.getExtras().isEmpty()) {

	    AbstractSprItem selectedChildItem = (AbstractSprItem) intent.getSerializableExtra(AppContext.SELECTED_ITEM);

	    AbstractSprItem parentItem = (AbstractSprItem) currentChangingItem;

	    int selectedId = selectedChildItem.getId();
	    int prevId = 0;

	    // проверяем, выбрали новое значение или нет
	    if (parentItem.getSelectedChildItem() != null) {
		prevId = parentItem.getSelectedChildItem().getId();
	    }

	    if (parentItem.getSelectedChildItem() == null) {
		prevId = parentItem.getId();
	    }

	    if (selectedId == prevId) {
		return;
	    }

	    parentItem.setSelectedChildItem(selectedChildItem);

	    ((OperDetailsAdapter) listView.getAdapter()).notifyDataSetChanged();

	}

    }

    private SelectSprValueItem currentChangingItem;

    private class ItemClickListener implements OnItemClickListener {

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

	    BaseItem item = (BaseItem) parent.getAdapter().getItem(position);

	    if (item instanceof SelectSprValueItem) {

		// сохраняем ссылку на item, который сейчас выбираем, чтобы знать, какое значение потом обновлять после выбора

		currentChangingItem = (SelectSprValueItem) item;
		Intent intent = currentChangingItem.getClickIntent();
		intent.putExtra(AppContext.SELECT_ROOT, true);
		startActivity(intent);
		overridePendingTransition(R.anim.pull_in_right, R.anim.push_out_left);

	    } else if (item instanceof OpenActivityItem) {

		OpenActivityItem openActivityItem = (OpenActivityItem) item;

		startActivityForResult(openActivityItem.getClickIntent(), openActivityItem.getRequestCode());
		overridePendingTransition(R.anim.pull_in_right, R.anim.push_out_left);
	    }
	}

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	super.onActivityResult(requestCode, resultCode, data);

	if (resultCode == RESULT_OK) {

	    switch (requestCode) {
	    case DescriptionItem.REQUEST_CODE:
		operationItem.getDescItem().setDisplayText(data.getStringExtra(DescriptionItem.TEXT));
		break;
	    case DateTimeItem.REQUEST_CODE:
		Calendar c = (Calendar) data.getSerializableExtra(AppContext.CALENDAR);
		operationItem.getDateTimeItem().setCalendar(c);
	    }

	    ((OperDetailsAdapter) listView.getAdapter()).notifyDataSetChanged();

	}

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
	// TODO Auto-generated method stub
	super.onSaveInstanceState(outState);
	// outState.putSerializable(SPR_LIST, sprNamesMap);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onRestoreInstanceState(savedInstanceState);
	// sprNamesMap = (LinkedHashMap<String, SprNameItem>)
	// savedInstanceState.get(SPR_LIST);
    }

    @Override
    public void notifyItemSelected(SelectSprValueItem item) {

	if (item instanceof OperTypeItem) {// если изменился тип операции

	    int id = item.getId();

	    changeItems(OperationType.getType(id), items);

	}

    }
}
