package ru.javabegin.training.android.money.activities;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.fragments.SprListFragment;
import ru.javabegin.training.android.money.listview.items.interfaces.SelectSprValueItem;
import ru.javabegin.training.android.money.objects.AppContext;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;

// активити для выбора конкретного справочного значения
public class SelectValueActivity extends AnimationActivity {
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_spr_value);
		
		SelectSprValueItem listItem = (SelectSprValueItem)getIntent().getSerializableExtra(AppContext.SELECTED_ITEM);
		
		boolean selectRoot = getIntent().getBooleanExtra(AppContext.SELECT_ROOT, false);
		
		// показать список справочных значений
		Fragment fragment = new SprListFragment();
		Bundle args = new Bundle();
		args.putSerializable(AppContext.SELECTED_ITEM, listItem);
		
		if (selectRoot){
			args.putBoolean(AppContext.SELECT_ROOT, selectRoot);
		}

		fragment.setArguments(args);
		
		FragmentManager fragmentManager = getFragmentManager();
		fragmentManager.beginTransaction().replace(R.id.spr_frame, fragment).commit();
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.spr_value, menu);
		return true;
	}
	
	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);
	

	}


}
