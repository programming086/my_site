package ru.javabegin.training.android.money.database.abstracts.impls;

import java.math.BigDecimal;

import ru.javabegin.training.android.money.database.abstracts.AbstractDbListItem;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.listview.items.AmountItem;
import ru.javabegin.training.android.money.listview.items.CurrencyItem;
import ru.javabegin.training.android.money.listview.items.DateTimeItem;
import ru.javabegin.training.android.money.listview.items.DescriptionItem;
import ru.javabegin.training.android.money.listview.items.OperSourceItem;
import ru.javabegin.training.android.money.listview.items.OperTypeItem;
import ru.javabegin.training.android.money.listview.items.OperationItem;
import ru.javabegin.training.android.money.listview.items.StorageItem;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class OperationDbItem extends AbstractDbListItem<OperationItem> {

    private OperationType operationType;

    public void setOperationType(OperationType operationType) {
	this.operationType = operationType;
    }

    @Override
    protected String getAllItemsSQL() {
	StringBuilder builder = new StringBuilder();

	builder.append("select " + " o.from_storage_id as " + ALIAS_FROM_STORAGE_ID + ",o.to_currency_id as " + ALIAS_TO_CURRENCY_ID + ",o.from_currency_id as " + ALIAS_FROM_CURRENCY_ID + ",t.name as " + ALIAS_TYPE_NAME + ",o.type_id as " + ALIAS_TYPE_ID + ",o._id as " + ALIAS_ID + ",c.code as " + ALIAS_CURRENCY + ",o.[from_amount] as " + ALIAS_FROM_AMOUNT + ",o.[to_amount] as " + ALIAS_TO_AMOUNT + ",o.[operation_datetime] as " + ALIAS_OPERATION_DATETIME + ",o.[to_storage_id] as "
		+ ALIAS_TO_STORAGE_ID + ",o.[from_storage_id] as " + ALIAS_FROM_STORAGE_ID + ",s.[name] as " + ALIAS_SOURCE + ",o.[description] as " + ALIAS_DESC + ",o.[source_id] as " + ALIAS_SOURCE_ID + " from " + OPERATIONS_TABLE + " o " + " left join " + CURRENCY_TABLE + " c on o.to_currency_id=c.[_id]  " + " left join " + OPER_SOURCE_TABLE + " s on o.source_id=s.[_id] " + " left join " + OPER_TYPE_TABLE + " t on o.type_id=t.[_id] ");

	if (operationType != OperationType.ALL) {
	    builder.append(" where o.type_id=" + operationType.getId());
	    builder.append(" order by o.operation_datetime desc");
	} else {
	    builder.append(" order by o.operation_datetime desc");
	}

	return builder.toString();
    }

    @Override
    protected String getOneItemSQL(int itemId) {

	StringBuilder builder = new StringBuilder();

	builder.append("select " + "o.to_currency_id as " + ALIAS_TO_CURRENCY_ID + ",o.from_currency_id as " + ALIAS_FROM_CURRENCY_ID + ",o.type_id as " + ALIAS_TYPE_ID + ",o._id as " + ALIAS_ID + "," + "o.[from_amount] as " + ALIAS_FROM_AMOUNT + ",o.[to_amount] as " + ALIAS_TO_AMOUNT + ",o.[operation_datetime] as " + ALIAS_OPERATION_DATETIME + ",o.[to_storage_id] as " + ALIAS_TO_STORAGE_ID + ",o.[from_storage_id] as " + ALIAS_FROM_STORAGE_ID + ",o.[description] as " + ALIAS_DESC
		+ ",o.[source_id] as " + ALIAS_SOURCE_ID + " from " + OPERATIONS_TABLE + " o where o._id=" + itemId);

	return builder.toString();
    }

    @Override
    protected String getLastItemSQL() {
	StringBuilder builder = new StringBuilder();

	builder.append("select " + " o.from_storage_id as " + ALIAS_FROM_STORAGE_ID + ",o.to_currency_id as " + ALIAS_TO_CURRENCY_ID + ",o.from_currency_id as " + ALIAS_FROM_CURRENCY_ID + ",o.type_id as " + ALIAS_TYPE_ID + ",o._id as " + ALIAS_ID + ",o.[from_amount] as " + ALIAS_FROM_AMOUNT + ", o.[to_amount] as " + ALIAS_TO_AMOUNT + ",o.[operation_datetime] as " + ALIAS_OPERATION_DATETIME + ",o.[to_storage_id] as " + ALIAS_TO_STORAGE_ID + ",o.[from_storage_id] as " + ALIAS_FROM_STORAGE_ID
		+ ",o.[source_id] as " + ALIAS_SOURCE_ID + " from " + LAST_OPERATION_TABLE + " o");

	return builder.toString();
    }

    protected OperationItem fillItem(Cursor c) {
	OperationItem item = new OperationItem();
	item.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));

	item.setFromAmountItem(new AmountItem(c.getDouble(c.getColumnIndex(ALIAS_FROM_AMOUNT))));
	item.setToAmountItem(new AmountItem(c.getDouble(c.getColumnIndex(ALIAS_TO_AMOUNT))));

	item.setFromCurrencyItem(DbItemCreator.getCurrencyDbItem().getOneItem(c.getInt(c.getColumnIndex(ALIAS_FROM_CURRENCY_ID))));
	item.setToCurrencyItem(DbItemCreator.getCurrencyDbItem().getOneItem(c.getInt(c.getColumnIndex(ALIAS_TO_CURRENCY_ID))));

	item.setFromStorageItem(DbItemCreator.getStorageDbItem().getOneItem(c.getInt(c.getColumnIndex(ALIAS_FROM_STORAGE_ID))));
	item.setToStorageItem(DbItemCreator.getStorageDbItem().getOneItem(c.getInt(c.getColumnIndex(ALIAS_TO_STORAGE_ID))));

	item.setOperSourceItem(DbItemCreator.getOperSourceDbItem().getOneItem(c.getInt(c.getColumnIndex(ALIAS_SOURCE_ID))));
	item.setOperTypeItem(DbItemCreator.getOperTypeDbItem().getOneItem(c.getInt(c.getColumnIndex(ALIAS_TYPE_ID))));

	item.setDateTimeItem(DbItemCreator.getDatetimeDbItem().getOneItem(item.getId()));
	item.setDescItem(DbItemCreator.getDescDbItem().getOneItem(item.getId()));

	if (item.getOperTypeItem() == null) {
	    item.setOperTypeItem(new OperTypeItem());
	}

	if (item.getOperSourceItem() == null) {
	    item.setOperSourceItem(new OperSourceItem());
	}

	if (item.getToStorageItem() == null) {
	    item.setToStorageItem(new StorageItem());
	}

	if (item.getFromStorageItem() == null) {
	    item.setFromStorageItem(new StorageItem());
	}

	if (item.getToCurrencyItem() == null) {
	    item.setToCurrencyItem(new CurrencyItem());
	}

	if (item.getFromCurrencyItem() == null) {
	    item.setFromCurrencyItem(new CurrencyItem());
	}

	if (item.getDescItem() == null) {
	    item.setDescItem(new DescriptionItem());
	}

	if (item.getDateTimeItem() == null) {
	    item.setDateTimeItem(new DateTimeItem());
	}

	if (item.getFromAmountItem() == null) {
	    item.setFromAmountItem(new AmountItem(0));
	}

	if (item.getToAmountItem() == null) {
	    item.setToAmountItem(new AmountItem(0));
	}

	return item;
    }

    public boolean hasLastOperation() {
	return super.hasRows("select _id from " + LAST_OPERATION_TABLE);
    }

    private SQLiteDatabase db = null;

    public boolean saveOperation(OperationItem operationItem) {

	boolean success = false;

	try {
	    db = getDatabase();

	    db.beginTransaction();

	    // создаем или обновляем операцию (в базе данных также работает триггер)
	    success = createOperation(operationItem);

	    // обновляем данные по балансу
	    success = checkBalance(operationItem);

	    if (success) {// если все операции прошли успешно
		db.setTransactionSuccessful();
	    }

	} catch (Exception e) {
	    Log.e(tag, e.getMessage());
	    return false;
	} finally {
	    db.endTransaction();
	}

	return success;
    }

    private boolean checkBalance(OperationItem operation) {
	// при обновлении баланса сначала делаем откат, потом уже вносим новые данные

	boolean success = false;

	if (operation.isEditMode()) { // если режим редактирования, то сначала нужно сделать откат текущей операции, чтобы правильно сохранились результаты

	    success = rollbackBalance(operation);

	}

	success = updateBalance(operation);

	return success;

    }

    // обновление баланса после создания/редактирования операции
    private boolean updateBalance(OperationItem operation) {

	boolean success = false;
	// заново определяем id типа операции, т.к. при редактировании его могли изменить
	int operTypeId = operation.getOperTypeItem().getSelectedChildItem() != null ? operation.getOperTypeItem().getSelectedChildItem().getId() : operation.getOperTypeItem().getId();

	int toCurrencyId = 0;
	int toStorageId = 0;
	int fromCurrencyId = 0;
	int fromStorageId = 0;

	BigDecimal fromAmount = null;
	BigDecimal toAmount = null;

	switch (OperationType.getType(operTypeId)) {
	case INCOME:

	    toCurrencyId = operation.getToCurrencyItem().getSelectedChildItem() != null ? operation.getToCurrencyItem().getSelectedChildItem().getId() : operation.getToCurrencyItem().getId();
	    toStorageId = operation.getToStorageItem().getSelectedChildItem() != null ? operation.getToStorageItem().getSelectedChildItem().getId() : operation.getToStorageItem().getId();
	    toAmount = operation.getToAmountItem().getNewAmount() != null ? operation.getToAmountItem().getNewAmount() : operation.getToAmountItem().getAmount();

	    success = DbItemCreator.getBalanceDbItem().updateBalance(toCurrencyId, toStorageId, operTypeId, toAmount);

	    break;

	case OUTCOME:

	    fromCurrencyId = operation.getFromCurrencyItem().getSelectedChildItem() != null ? operation.getFromCurrencyItem().getSelectedChildItem().getId() : operation.getFromCurrencyItem().getId();
	    fromStorageId = operation.getFromStorageItem().getSelectedChildItem() != null ? operation.getFromStorageItem().getSelectedChildItem().getId() : operation.getFromStorageItem().getId();
	    fromAmount = operation.getFromAmountItem().getNewAmount() != null ? operation.getFromAmountItem().getNewAmount() : operation.getFromAmountItem().getAmount();

	    success = DbItemCreator.getBalanceDbItem().updateBalance(fromCurrencyId, fromStorageId, operTypeId, fromAmount);

	    break;

	case TRANSFER:

	    fromStorageId = operation.getFromStorageItem().getSelectedChildItem() != null ? operation.getFromStorageItem().getSelectedChildItem().getId() : operation.getFromStorageItem().getId();
	    fromCurrencyId = operation.getFromCurrencyItem().getSelectedChildItem() != null ? operation.getFromCurrencyItem().getSelectedChildItem().getId() : operation.getFromCurrencyItem().getId();
	    fromAmount = operation.getFromAmountItem().getNewAmount() != null ? operation.getFromAmountItem().getNewAmount() : operation.getFromAmountItem().getAmount();

	    success = DbItemCreator.getBalanceDbItem().updateBalance(fromCurrencyId, fromStorageId, OperationType.OUTCOME.getId(), fromAmount);

	    toStorageId = operation.getToStorageItem().getSelectedChildItem() != null ? operation.getToStorageItem().getSelectedChildItem().getId() : operation.getToStorageItem().getId();
	    success = DbItemCreator.getBalanceDbItem().updateBalance(fromCurrencyId, toStorageId, OperationType.INCOME.getId(), fromAmount);

	    break;

	case CONVERT:

	    fromStorageId = operation.getFromStorageItem().getSelectedChildItem() != null ? operation.getFromStorageItem().getSelectedChildItem().getId() : operation.getFromStorageItem().getId();
	    fromCurrencyId = operation.getFromCurrencyItem().getSelectedChildItem() != null ? operation.getFromCurrencyItem().getSelectedChildItem().getId() : operation.getFromCurrencyItem().getId();
	    fromAmount = operation.getFromAmountItem().getNewAmount() != null ? operation.getFromAmountItem().getNewAmount() : operation.getFromAmountItem().getAmount();

	    success = DbItemCreator.getBalanceDbItem().updateBalance(fromCurrencyId, fromStorageId, OperationType.OUTCOME.getId(), fromAmount);

	    toStorageId = operation.getToStorageItem().getSelectedChildItem() != null ? operation.getToStorageItem().getSelectedChildItem().getId() : operation.getToStorageItem().getId();
	    toCurrencyId = operation.getToCurrencyItem().getSelectedChildItem() != null ? operation.getToCurrencyItem().getSelectedChildItem().getId() : operation.getToCurrencyItem().getId();
	    toAmount = operation.getToAmountItem().getNewAmount() != null ? operation.getToAmountItem().getNewAmount() : operation.getToAmountItem().getAmount();

	    success = DbItemCreator.getBalanceDbItem().updateBalance(toCurrencyId, toStorageId, OperationType.INCOME.getId(), toAmount);

	    break;

	default:
	    break;
	}

	return success;
    }

    // возврат баланса в изначальное состояние (при редактировании)
    private boolean rollbackBalance(OperationItem operation) {

	boolean success = false;

	int currencyId = 0;
	int storageId = 0;
	int operTypeId = operation.getOperTypeItem().getId();

	switch (OperationType.getType(operTypeId)) {
	case INCOME:

	    currencyId = operation.getToCurrencyItem().getId();
	    storageId = operation.getToStorageItem().getId();
	    operTypeId = operation.getOperTypeItem().getId();

	    success = DbItemCreator.getBalanceDbItem().revertBalance(operTypeId, currencyId, storageId, operation.getToAmountItem().getAmount());

	    break;

	case OUTCOME:

	    currencyId = operation.getToCurrencyItem().getId();
	    storageId = operation.getToStorageItem().getId();
	    operTypeId = operation.getOperTypeItem().getId();

	    success = DbItemCreator.getBalanceDbItem().revertBalance(operTypeId, currencyId, storageId, operation.getFromAmountItem().getAmount());

	    break;

	case TRANSFER:

	    // при трансфере - откатываем баланс 2 раза - для обоих счетов, откуда переводили и куда

	    currencyId = operation.getFromCurrencyItem().getId();
	    storageId = operation.getFromStorageItem().getId();
	    operTypeId = OperationType.OUTCOME.getId();

	    success = DbItemCreator.getBalanceDbItem().revertBalance(operTypeId, currencyId, storageId, operation.getFromAmountItem().getAmount());

	    currencyId = operation.getFromCurrencyItem().getId();
	    storageId = operation.getToStorageItem().getId();
	    operTypeId = OperationType.INCOME.getId();

	    success = DbItemCreator.getBalanceDbItem().revertBalance(operTypeId, currencyId, storageId, operation.getFromAmountItem().getAmount());

	    break;

	case CONVERT: // конвертация похожа на трансфер, но можно указывать разные валюты и суммы

	    currencyId = operation.getFromCurrencyItem().getId();
	    storageId = operation.getFromStorageItem().getId();
	    operTypeId = OperationType.OUTCOME.getId();

	    success = DbItemCreator.getBalanceDbItem().revertBalance(operTypeId, currencyId, storageId, operation.getFromAmountItem().getAmount());

	    currencyId = operation.getToCurrencyItem().getId();
	    storageId = operation.getToStorageItem().getId();
	    operTypeId = OperationType.INCOME.getId();

	    success = DbItemCreator.getBalanceDbItem().revertBalance(operTypeId, currencyId, storageId, operation.getToAmountItem().getAmount());

	    break;

	default:
	    break;
	}

	return success;
    }

    private boolean createOperation(OperationItem operation) {

	SQLiteStatement stmt = null;

	try {

	    if (operation.isEditMode()) {
		stmt = db.compileStatement("update " + OPERATIONS_TABLE + " set operation_datetime=?, from_amount=?, to_amount=?, to_currency_id=?, from_currency_id=?, source_id=?, to_storage_id=?, from_storage_id=?, type_id=?, description=? where _id=?");
		stmt.bindLong(11, operation.getId());

	    } else {
		stmt = db.compileStatement("insert into " + OPERATIONS_TABLE + " (operation_datetime, from_amount, to_amount, to_currency_id, from_currency_id, source_id, to_storage_id, from_storage_id, type_id,  description) values (?,?,?,?,?,?,?,?,?,?)");
	    }

	    long date = operation.getDateTimeItem().getCalendar().getTimeInMillis();

	    // если есть измененные значения - берем их
	    int toCurrencyId = operation.getToCurrencyItem().getSelectedChildItem() != null ? operation.getToCurrencyItem().getSelectedChildItem().getId() : operation.getToCurrencyItem().getId();
	    int fromCurrencyId = operation.getFromCurrencyItem().getSelectedChildItem() != null ? operation.getFromCurrencyItem().getSelectedChildItem().getId() : operation.getFromCurrencyItem().getId();
	    int operSourceId = operation.getOperSourceItem().getSelectedChildItem() != null ? operation.getOperSourceItem().getSelectedChildItem().getId() : operation.getOperSourceItem().getId();
	    int toStorageId = operation.getToStorageItem().getSelectedChildItem() != null ? operation.getToStorageItem().getSelectedChildItem().getId() : operation.getToStorageItem().getId();
	    int fromStorageId = operation.getFromStorageItem().getSelectedChildItem() != null ? operation.getFromStorageItem().getSelectedChildItem().getId() : operation.getFromStorageItem().getId();
	    int operTypeId = operation.getOperTypeItem().getSelectedChildItem() != null ? operation.getOperTypeItem().getSelectedChildItem().getId() : operation.getOperTypeItem().getId();

	    double fromAmount = operation.getFromAmountItem().getNewAmount() != null ? operation.getFromAmountItem().getNewAmount().doubleValue() : operation.getFromAmountItem().getAmount().doubleValue();
	    double toAmount = operation.getToAmountItem().getNewAmount() != null ? operation.getToAmountItem().getNewAmount().doubleValue() : operation.getToAmountItem().getAmount().doubleValue();

	    stmt.bindLong(1, date);
	    stmt.bindDouble(2, fromAmount);
	    stmt.bindDouble(3, toAmount);
	    stmt.bindLong(4, toCurrencyId);
	    stmt.bindLong(5, fromCurrencyId);
	    stmt.bindLong(6, operSourceId);
	    stmt.bindLong(7, toStorageId);
	    stmt.bindLong(8, fromStorageId);
	    stmt.bindLong(9, operTypeId);

	    if (operation.getDescItem().getDisplayText() == null) {
		stmt.bindNull(10);
	    } else {
		stmt.bindString(10, operation.getDescItem().getDisplayText());
	    }

	    stmt.execute();

	} catch (Exception e) {
	    Log.e(tag, e.getMessage());
	    return false;
	}

	return true;

    }

    // удалить операцию и обновить баланс
    public boolean deleteOperation(OperationItem operationItem) {

	boolean success = false; // хранит, все ли операции завершились удачно

	try {

	    db = getDatabase();

	    db.beginTransaction();

	    if (operationItem.isEditMode()) {

		success = rollbackBalance(operationItem);

	    }

	    // сначала удаляем саму операцию, потом обновляем баланс
	    success = deleteOperation(operationItem.getId());

	    if (success) { // если все операции завершили удачно
		db.setTransactionSuccessful();
	    }

	} catch (Exception e) {
	    Log.e(tag, e.getMessage());
	    return false;
	} finally {
	    db.endTransaction();
	}

	return success;

    }

    private boolean deleteOperation(int operationId) {
	SQLiteStatement stmt = null;
	try {

	    stmt = db.compileStatement("delete from " + OPERATIONS_TABLE + " where _id=?");
	    stmt.bindLong(1, operationId);
	    stmt.execute();
	} catch (Exception e) {
	    Log.e(tag, e.getMessage());
	    return false;
	} finally {
	    if (stmt != null) {
		stmt.close();
	    }
	}

	return true;
    }

}
