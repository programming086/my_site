package ru.javabegin.training.android.money.fragments;

import android.app.ListFragment;
import android.os.Bundle;
import android.widget.ListAdapter;

public abstract class AbstractListFragment extends ListFragment {

    protected abstract ListAdapter getAdapter();

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onActivityCreated(savedInstanceState);
	setListAdapter(getAdapter());
    }

}
