package ru.javabegin.training.android.money.fragments;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.listview.adapters.OperDetailsAdapter;
import ru.javabegin.training.android.money.listview.items.interfaces.SelectSprValueItem;
import ru.javabegin.training.android.money.objects.AppContext;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;

// список всех общих справочников (для каждого из них пользователь будет выбирать значение)
public class SprListFragment extends AbstractListFragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {

	SelectSprValueItem item = ((SelectSprValueItem) l.getAdapter().getItem(position));

	if (item.hasChilds()) { // если у справочного значения есть дочерние пункты - открываем их
	    selectChilds(item);
	} else {
	    returnResult(item);
	}
    }

    protected void returnResult(SelectSprValueItem item) {
	Intent intent = item.getResultIntent();
	if (intent == null) {
	    return;
	}
	intent.putExtra(AppContext.SELECTED_ITEM, item);
	startActivity(intent);
	getActivity().overridePendingTransition(R.anim.pull_in_left, R.anim.push_out_right);
    }

    protected void selectChilds(SelectSprValueItem item) {
	Intent intent = item.getClickIntent();
	if (intent == null) {
	    return;
	}
	intent.putExtra(AppContext.SELECTED_ITEM, item);
	startActivity(intent);
	getActivity().overridePendingTransition(R.anim.pull_in_right, R.anim.push_out_left);
    }

    @Override
    protected ListAdapter getAdapter() {
	SelectSprValueItem item = (SelectSprValueItem) getArguments().getSerializable(AppContext.SELECTED_ITEM);

	boolean selectRoot = getArguments().getBoolean(AppContext.SELECT_ROOT, false);

	ArrayList<SelectSprValueItem> list = item.getList(selectRoot);

	return new OperDetailsAdapter<SelectSprValueItem>(getActivity(), list);

    }

}
