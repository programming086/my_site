package ru.javabegin.training.android.money.gui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.fragments.BalanceFragment;
import ru.javabegin.training.android.money.fragments.CommonSettingsFragment;
import ru.javabegin.training.android.money.fragments.CurrencySettingsFragment;
import ru.javabegin.training.android.money.fragments.OperationListFragment;
import ru.javabegin.training.android.money.listview.adapters.ExpandableListAdapter;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.view.Gravity;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.ExpandableListView.OnGroupCollapseListener;
import android.widget.ExpandableListView.OnGroupExpandListener;

public class MenuExpandableList {

    public static final String OPERATION_TYPE = "ru.javabegin.training.android.money.gui.MenuExpandableList.operationType";

    private Activity context;

    private DrawerLayout navDrawer;

    private ExpandableListAdapter listAdapter;
    private ExpandableListView expListView;

    private List<String> listGroup;// родительские пункты
    private HashMap<String, List<String>> mapChild; // дочерние пункты

    private static final int OPERATIONS_ALL = 0;

    public MenuExpandableList(final Activity context) {
	this.context = context;
	expListView = (ExpandableListView) context.findViewById(R.id.expLvMenu);
	navDrawer = (DrawerLayout) context.findViewById(R.id.drawer_layout);

	fillMenu();

	listAdapter = new ExpandableListAdapter(context, listGroup, mapChild);

	expListView.setAdapter(listAdapter);

	expListView.setOnGroupClickListener(new OnGroupClickListener() {
	    @Override
	    public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
		return false;
	    }
	});

	expListView.setOnGroupExpandListener(new OnGroupExpandListener() {
	    @Override
	    public void onGroupExpand(int groupPosition) {
	    }
	});

	expListView.setOnGroupCollapseListener(new OnGroupCollapseListener() {
	    @Override
	    public void onGroupCollapse(int groupPosition) {
	    }
	});

	expListView.setOnChildClickListener(new OnChildClickListener() {

	    @Override
	    public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {

		switch (groupPosition) {
		case 0: {// операции TODO поменять на константы

		    showOperations(OperationType.getType(childPosition));

		    break;
		}

		case 1: { // баланс

		    showBalance();

		    break;
		}

		case 2: {// настройки

		    if (childPosition == 0) {// общие

			Fragment fragment = new CommonSettingsFragment();
			FragmentManager fragmentManager = context.getFragmentManager();
			fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();

		    }

		    if (childPosition == 2) {// валюты

			Fragment fragment = new CurrencySettingsFragment();
			FragmentManager fragmentManager = context.getFragmentManager();
			fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();

		    }

		    break;
		}

		default:
		    break;
		}

		navDrawer.closeDrawer(Gravity.LEFT);
		return true;
	    }

	});

	showOperations(OperationType.getType(OPERATIONS_ALL));

    }

    protected void showBalance() {
	Fragment fragment = new BalanceFragment();

	FragmentManager fragmentManager = context.getFragmentManager();
	fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();

    }

    private void showOperations(OperationType operationType) {
	Fragment fragment = new OperationListFragment();
	Bundle args = new Bundle();
	args.putSerializable(OPERATION_TYPE, operationType);
	fragment.setArguments(args);

	FragmentManager fragmentManager = context.getFragmentManager();
	fragmentManager.beginTransaction().replace(R.id.content_frame, fragment).commit();

    }

    private void fillMenu() {
	listGroup = new ArrayList<String>();
	mapChild = new HashMap<String, List<String>>();

	listGroup.add(context.getResources().getString(R.string.menu_operations));

	listGroup.add(context.getResources().getString(R.string.menu_budget));

	listGroup.add(context.getResources().getString(R.string.menu_settings));

	List<String> menu1 = new ArrayList<String>();
	for (String child : context.getResources().getStringArray(R.array.child_menu_operations)) {
	    menu1.add(child);
	}

	List<String> menu2 = new ArrayList<String>();
	for (String child : context.getResources().getStringArray(R.array.child_menu_balance)) {
	    menu2.add(child);
	}

	List<String> menu3 = new ArrayList<String>();
	for (String child : context.getResources().getStringArray(R.array.child_menu_settings)) {
	    menu3.add(child);
	}

	mapChild.put(listGroup.get(0), menu1);
	mapChild.put(listGroup.get(1), menu2);
	mapChild.put(listGroup.get(2), menu3);

    }

}
