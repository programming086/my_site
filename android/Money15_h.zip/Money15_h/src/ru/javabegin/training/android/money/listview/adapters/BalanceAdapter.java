package ru.javabegin.training.android.money.listview.adapters;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.StorageDbItem;
import ru.javabegin.training.android.money.listview.items.BalanceItem;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class BalanceAdapter extends ArrayAdapter<BalanceItem> {
    private Context context;
    private ArrayList<BalanceItem> balanceList;

    public BalanceAdapter(Context context, ArrayList<BalanceItem> balanceList) {
	super(context, R.layout.balance_item_value, balanceList);
	this.context = context;
	this.balanceList = balanceList;
    }

    public View getView(int position, View convertView, ViewGroup parent) {

	if (convertView == null) {

	    ViewHolder holder = new ViewHolder();

	    LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	    convertView = inflater.inflate(R.layout.balance_item_value, parent, false);

	    holder.amount = (TextView) convertView.findViewById(R.id.balance_amount);
	    holder.image = (ImageView) convertView.findViewById(R.id.image_balance);
	    holder.storageName = (TextView) convertView.findViewById(R.id.storage_name);

	    convertView.setTag(holder);
	}

	ViewHolder holder = (ViewHolder) convertView.getTag();

	BalanceItem item = getItem(position);

	holder.amount.setText(String.valueOf(item.getAmount()) + " " + item.getCurrencyItem().getCode());
	holder.storageName.setText(String.valueOf(item.getStorageItem().getName()));

	String imageName = StorageDbItem.STORAGE_TABLE.toLowerCase() + item.getStorageItem().getId();

	try {
	    holder.image.setImageBitmap(getImage(imageName));
	} catch (Exception e) {
	    e.printStackTrace();
	}

	return convertView;
    }

    @Override
    public int getCount() {
	return balanceList.size();
    }

    @Override
    public BalanceItem getItem(int index) {
	return balanceList.get(index);
    }

    @Override
    public long getItemId(int index) {
	return balanceList.get(index).getId();
    }

    protected static class ViewHolder {
	public TextView amount;
	public TextView storageName;
	public ImageView image;
    }

    private Bitmap getImage(String name) {
	int imageId = context.getResources().getIdentifier(name, "drawable", context.getPackageName());
	return BitmapFactory.decodeResource(context.getResources(), imageId);
    }

    public void update(ArrayList<BalanceItem> balanceList) {
	this.balanceList.clear();
	this.balanceList.addAll(balanceList);

	notifyDataSetChanged();
    }

}