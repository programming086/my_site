package ru.javabegin.training.android.money.listview.items;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.listview.items.interfaces.SelectSprValueItem;
import ru.javabegin.training.android.money.listview.items.listeners.ChangeOperTypeListener;
import ru.javabegin.training.android.money.listview.items.listeners.ChangeOperTypeNotifier;
import ru.javabegin.training.android.money.listview.items.listeners.impls.ListenerRegistrator;
import ru.javabegin.training.android.money.objects.AppContext;

public class CurrencyItem extends AbstractSprItem implements ChangeOperTypeNotifier {

    private static final long serialVersionUID = 1L;

    private static final String TABLE_NAME = "spr_Currency";

    private boolean allow;
    private String code;
    private String country;

    public CurrencyItem() {
	setTableName(TABLE_NAME);
	setName(AppContext.getInstance().getResources().getString(R.string.currency));
    }

    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public String getCountry() {
	return country;
    }

    public void setCountry(String country) {
	this.country = country;
    }

    @Override
    public String getHint() {
	return AppContext.getInstance().getResources().getString(R.string.currency);
    }

    @Override
    public void notifyListeners() {
	SelectSprValueItem item = getSelectedChildItem() != null ? getSelectedChildItem() : this;// передавать текущий или новый выбранный элемент
	for (ChangeOperTypeListener listener : ListenerRegistrator.getInstance().getListeners()) {
	    listener.notifyItemSelected(item);
	}

    }

    @Override
    public void setSelectedChildItem(SelectSprValueItem selectedChildItem) {
	// TODO Auto-generated method stub
	super.setSelectedChildItem(selectedChildItem);
	notifyListeners();
    }

    public boolean isAllow() {
	return allow;
    }

    public void setAllow(boolean allow) {
	this.allow = allow;
    }

    @Override
    public ArrayList<SelectSprValueItem> getList(boolean selectRoot) {
	if (!selectRoot) {
	    return new ArrayList<SelectSprValueItem>(DbItemCreator.getCurrencyDbItem().getChildItems(getId()));
	} else {
	    return new ArrayList<SelectSprValueItem>(DbItemCreator.getCurrencyDbItem().getRootItems());
	}
    }

    @Override
    public String getErrorValidateMessage() {
	return AppContext.getInstance().getResources().getString(R.string.empty_currency);
    }
}
