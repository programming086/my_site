package ru.javabegin.training.android.money.listview.items;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.activities.DescriptionActivity;
import ru.javabegin.training.android.money.activities.OperationDetailsActivity;
import ru.javabegin.training.android.money.listview.items.abstracts.AbstractItem;
import ru.javabegin.training.android.money.listview.items.interfaces.OpenActivityItem;
import ru.javabegin.training.android.money.objects.AppContext;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class DescriptionItem extends AbstractItem implements OpenActivityItem {

	private static final String ICON_NAME = "note";

	private static final long serialVersionUID = 1L;

	public static final int REQUEST_CODE = 1;
	public static final String TEXT = "ru.javabegin.training.android.money.objects.items.impl.text";

	private String displayText;

	@Override
	public Bitmap getImage() {
		int imageId = AppContext.getInstance().getResources().getIdentifier(ICON_NAME, "drawable", AppContext.getInstance().getPackageName());

		return BitmapFactory.decodeResource(AppContext.getInstance().getResources(), imageId);
	}

	@Override
	public String getDisplayText() {
		return (displayText != null && displayText.length() > 0) ? getShortText() : null;
	}

	@Override
	public String getHint() {
		return AppContext.getInstance().getResources().getString(R.string.desc);
	}

	private String getShortText() {

		if (displayText == null) {
			return null;
		}

		String text = displayText.split("\n")[0];

		text = text.length() > 20 ? text.substring(0, 19).trim() + " ..." : text.trim();
		return text;

	}

	public void setDisplayText(String text) {
		this.displayText = text;
	}

	@Override
	public Intent getClickIntent() {
		Intent intent = new Intent(AppContext.getInstance(), DescriptionActivity.class);
		intent.putExtra(TEXT, displayText);
		return intent;
	}

	private Intent resultIntent;

	@Override
	public Intent getResultIntent() {
		resultIntent = new Intent(AppContext.getInstance(), OperationDetailsActivity.class);
		return resultIntent;
	}

	public void setResultIntent(Intent resultIntent) {
		this.resultIntent = resultIntent;
	}

	@Override
	public int getRequestCode() {
		return REQUEST_CODE;
	}

}
