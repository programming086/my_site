package ru.javabegin.training.android.money.listview.items;

import java.io.Serializable;

import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;

public class OperationItem implements Serializable {

    private static final long serialVersionUID = 1L;

    private int id;
    private boolean editMode;

    // сумма, откуда переводим деньги
    private AmountItem fromAmountItem;

    // сумма, куда переводим деньги
    private AmountItem toAmountItem;

    // тип операции
    private OperTypeItem operTypeItem;

    // источник операции
    private OperSourceItem operSourceItem;

    // счет, куда переводим деньги
    private StorageItem toStorageItem;

    // счет, откуда переводим деньги
    private StorageItem fromStorageItem;

    // валюта, куда переводим деньги
    private CurrencyItem toCurrencyItem;

    // валюта, откуда переводим деньги
    private CurrencyItem fromCurrencyItem;

    private DescriptionItem descItem;
    private DateTimeItem dateTimeItem;

    public OperationItem() {
    }

    public OperationItem(boolean attemptFillLastValues) {// пытаемся установить последние выбранные значения

	if (attemptFillLastValues && DbItemCreator.getOperationDbItem().hasLastOperation()) {
	    OperationItem item = DbItemCreator.getOperationDbItem().getLastItem();
	    operTypeItem = item.getOperTypeItem();
	    operSourceItem = item.getOperSourceItem();

	    fromStorageItem = item.getFromStorageItem();
	    toStorageItem = item.getToStorageItem();

	    fromCurrencyItem = item.getFromCurrencyItem();
	    toCurrencyItem = item.getToCurrencyItem();

	    fromAmountItem = item.getFromAmountItem();
	    toAmountItem = item.getToAmountItem();

	    descItem = item.getDescItem();
	    dateTimeItem = item.getDateTimeItem();
	}

	if (fromAmountItem == null) {
	    fromAmountItem = new AmountItem(0);
	}

	if (toAmountItem == null) {
	    toAmountItem = new AmountItem(0);
	}

	if (operTypeItem == null) {
	    operTypeItem = new OperTypeItem();
	}

	if (operSourceItem == null) {
	    operSourceItem = new OperSourceItem();
	}

	if (fromStorageItem == null) {
	    fromStorageItem = new StorageItem();
	}

	if (toStorageItem == null) {
	    toStorageItem = new StorageItem();
	}

	if (fromCurrencyItem == null) {
	    fromCurrencyItem = new CurrencyItem();
	}

	if (toCurrencyItem == null) {
	    toCurrencyItem = new CurrencyItem();
	}

	if (descItem == null) {
	    descItem = new DescriptionItem();
	}

	if (dateTimeItem == null) {
	    dateTimeItem = new DateTimeItem();
	}

    }

    public boolean save() {
	return DbItemCreator.getOperationDbItem().saveOperation(this);
    }

    public int getId() {
	return id;
    }

    public void setId(int id) {
	this.id = id;
    }

    public boolean isEditMode() {
	return editMode;
    }

    public AmountItem getFromAmountItem() {
	return fromAmountItem;
    }

    public void setFromAmountItem(AmountItem fromAmountItem) {
	this.fromAmountItem = fromAmountItem;
    }

    public AmountItem getToAmountItem() {
	return toAmountItem;
    }

    public void setToAmountItem(AmountItem toAmountItem) {
	this.toAmountItem = toAmountItem;
    }

    public void setEditMode(boolean editMode) {
	this.editMode = editMode;
    }

    public OperTypeItem getOperTypeItem() {
	return operTypeItem;
    }

    public void setOperTypeItem(OperTypeItem operTypeItem) {
	this.operTypeItem = operTypeItem;
    }

    public OperSourceItem getOperSourceItem() {
	return operSourceItem;
    }

    public void setOperSourceItem(OperSourceItem operSourceItem) {
	this.operSourceItem = operSourceItem;
    }

    public StorageItem getToStorageItem() {
	return toStorageItem;
    }

    public void setToStorageItem(StorageItem toStorageItem) {
	this.toStorageItem = toStorageItem;
    }

    public StorageItem getFromStorageItem() {
	return fromStorageItem;
    }

    public void setFromStorageItem(StorageItem fromStorageItem) {
	this.fromStorageItem = fromStorageItem;
    }

    public CurrencyItem getToCurrencyItem() {
	return toCurrencyItem;
    }

    public void setToCurrencyItem(CurrencyItem toCurrencyItem) {
	this.toCurrencyItem = toCurrencyItem;
    }

    public CurrencyItem getFromCurrencyItem() {
	return fromCurrencyItem;
    }

    public void setFromCurrencyItem(CurrencyItem fromCurrencyItem) {
	this.fromCurrencyItem = fromCurrencyItem;
    }

    public DescriptionItem getDescItem() {
	return descItem;
    }

    public void setDescItem(DescriptionItem descItem) {
	this.descItem = descItem;
    }

    public DateTimeItem getDateTimeItem() {
	return dateTimeItem;
    }

    public void setDateTimeItem(DateTimeItem dateTimeItem) {
	this.dateTimeItem = dateTimeItem;
    }

}
