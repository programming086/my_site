package ru.javabegin.training.android.money.listview.items.abstracts;

import ru.javabegin.training.android.money.activities.OperationDetailsActivity;
import ru.javabegin.training.android.money.activities.SelectValueActivity;
import ru.javabegin.training.android.money.listview.items.interfaces.SelectSprValueItem;
import ru.javabegin.training.android.money.listview.items.interfaces.Validator;
import ru.javabegin.training.android.money.objects.AppContext;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

// абстрактный класс для работы со справочными значениями
public abstract class AbstractSprItem extends AbstractItem implements SelectSprValueItem, Validator {

    private static final long serialVersionUID = 1L;

    public static final int REQUEST_CODE = 3;

    private boolean hasChilds;

    private String tableName; // к какому типу справочника принадлежит

    // при клике по-умолчанию открывается SelectValueActivity
    private transient Intent clickIntent = new Intent(AppContext.getInstance(), SelectValueActivity.class);

    // результат по-умолчанию возвращается в OperationDetailsActivity
    private transient Intent resultIntent = new Intent(AppContext.getInstance(), OperationDetailsActivity.class);

    protected AbstractSprItem() {
	// TODO Auto-generated constructor stub
    }

    private SelectSprValueItem selectedChildItem;

    private int id;// выбранный id
    private String name;// выбранное значение

    @Override
    public int getId() {
	return id;
    }

    public void setId(int id) {
	this.id = id;
    }

    @Override
    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    @Override
    public String getDisplayText() {

	if (getSelectedChildItem() != null) {
	    return getSelectedChildItem().getName();
	} else if (getId() > 0) { // загруженное ранее значение (при редактировании)
	    return getName();
	}

	return getHint();
    }

    @Override
    public Bitmap getImage() {
	// иконку брать по id либо выбранного элемента (для корневого списка справочников) либо id текущего элемента (для списка справочников при выборе)
	int id = getSelectedChildItem() != null ? getSelectedChildItem().getId() : getId();

	String imageName = null;

	if (id > 0) {
	    imageName = getTableName().toLowerCase() + id;
	} else {
	    imageName = getTableName().toLowerCase();
	}

	int imageId = AppContext.getInstance().getResources().getIdentifier(imageName, "drawable", AppContext.getInstance().getPackageName());
	return BitmapFactory.decodeResource(AppContext.getInstance().getResources(), imageId);
    }

    @Override
    public SelectSprValueItem getSelectedChildItem() {
	return selectedChildItem;
    }

    public void setSelectedChildItem(SelectSprValueItem selectedChildItem) {
	this.selectedChildItem = selectedChildItem;
    }

    public String getTableName() {
	return tableName;
    }

    public void setTableName(String tableName) {
	this.tableName = tableName;
    }

    @Override
    public boolean hasChilds() {
	return hasChilds;
    }

    public void setHasChilds(boolean hasChilds) {
	this.hasChilds = hasChilds;
    }

    // по-умолчанию что делать при редактировании или открытии элемента
    @Override
    public Intent getClickIntent() {
	if (clickIntent != null) {
	    clickIntent.putExtra(AppContext.SELECTED_ITEM, this);
	}
	return clickIntent;
    }

    public void setClickIntent(Intent clickIntent) {
	this.clickIntent = clickIntent;
    }

    @Override
    public Intent getResultIntent() {
	if (resultIntent != null) {
	    resultIntent.putExtra(AppContext.SELECTED_ITEM, this);
	}
	return resultIntent;
    }

    public void setResultIntent(Intent resultIntent) {
	this.resultIntent = resultIntent;
    }

    @Override
    public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + id;
	result = prime * result + ((tableName == null) ? 0 : tableName.hashCode());
	return result;
    }

    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (obj == null)
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	AbstractSprItem other = (AbstractSprItem) obj;
	if (id != other.id)
	    return false;
	if (tableName == null) {
	    if (other.tableName != null)
		return false;
	} else if (!tableName.equals(other.tableName))
	    return false;
	return true;
    }

    @Override
    public String getHint() {
	return null;
    }

    @Override
    public String toString() {
	return this.getClass().getSimpleName();
    }

    @Override
    public int getRequestCode() {
	return REQUEST_CODE;
    }

    @Override
    public boolean validate() {
	if (getSelectedChildItem() != null) {
	    return true;
	}

	if (getId() > 0) {
	    return true;
	}

	return false;
    }

}
