package ru.javabegin.training.android.money.listview.items.interfaces;

import android.view.LayoutInflater;
import android.view.View;

//базовый класс для всех элементов ListView
public interface BaseItem {

    int getViewType(); // для выбора типа item

    View getView(LayoutInflater inflater, View convertView);// каждая реализация будет подставлять свой View

    String getDisplayText(); // значение для отображения

}