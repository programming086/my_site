package ru.javabegin.training.android.money.listview.items.interfaces;

import java.io.Serializable;

import android.graphics.Bitmap;

public interface ImageItem extends BaseItem, Serializable {

    Bitmap getImage(); // иконка выбранного значения (или подставлять иконку по-умолчанию)

    String getHint(); // подсказка, когда не выбрано значение

}
