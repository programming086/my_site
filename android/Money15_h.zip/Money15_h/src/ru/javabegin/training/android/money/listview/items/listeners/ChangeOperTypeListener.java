package ru.javabegin.training.android.money.listview.items.listeners;

import ru.javabegin.training.android.money.listview.items.interfaces.SelectSprValueItem;


// слушатель события
public interface ChangeOperTypeListener {
	void notifyItemSelected(SelectSprValueItem item); 
}
