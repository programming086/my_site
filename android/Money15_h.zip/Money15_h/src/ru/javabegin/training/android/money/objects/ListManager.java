package ru.javabegin.training.android.money.objects;

import java.util.ArrayList;
import java.util.HashMap;

import ru.javabegin.training.android.money.listview.items.CurrencyItem;
import ru.javabegin.training.android.money.listview.items.OperationItem;


// хранит текущий список операций (чтобы не передавать объекты между активити)
public class ListManager{
	
	public static ListManager instance;
	
	private ListManager() {}
	
	public static ListManager getInstance(){
		if (instance == null){
			instance = new ListManager();
		}
		
		return instance;
	}
	
	private HashMap<Integer, OperationItem> operationMap = new HashMap<Integer, OperationItem>();
	private ArrayList<OperationItem> operationList = new ArrayList<OperationItem>();

	private ArrayList<CurrencyItem> currencyList = new ArrayList<CurrencyItem>();
	
	
	public ArrayList<CurrencyItem> getCurrencyList() {
		return currencyList;
	}
	
	public void setCurrencyList(ArrayList<CurrencyItem> currencyList) {
		this.currencyList = currencyList;
	}
	
	public CurrencyItem getCurrencyItem(int index){
		return currencyList.get(index);
	}
	
	
	public void setOperationList(ArrayList<OperationItem> list){
		operationList.clear();
		operationList.addAll(list);
		
		operationMap.clear();
		for (OperationItem item : list) {
			operationMap.put(item.getId(), item);
		}
	}
	
	public ArrayList<OperationItem> getOperationList() {
		return operationList;
	}
	
	
	public OperationItem getOperation(int index){
		return operationMap.get(index);
	}

}
