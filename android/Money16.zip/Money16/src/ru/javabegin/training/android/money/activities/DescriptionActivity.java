package ru.javabegin.training.android.money.activities;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.listview.items.DescriptionItem;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;

public class DescriptionActivity extends AnimationActivity {

	private EditText txtDesc;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_description);

		txtDesc = (EditText) findViewById(R.id.txt_desc);

		String text = getIntent().getStringExtra(DescriptionItem.TEXT);
		txtDesc.setText(text);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.description, menu);
		return true;
	}

	@Override
	protected void closeActivity() {
		Intent result = new Intent();
		result.putExtra(DescriptionItem.TEXT, txtDesc.getText().toString());
		setResult(RESULT_OK, result);
		super.closeActivity();
	}

	public void clearDesc(View view) {
		txtDesc.setText("");
	}

}
