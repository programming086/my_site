package ru.javabegin.training.android.money.database.abstracts.impls;


public class DbItemCreator {

    private static CurrencyDbItem currencyDbItem = new CurrencyDbItem();
    private static DateTimeDbItem datetimeDbItem = new DateTimeDbItem();
    private static DescriptionDbItem descDbItem = new DescriptionDbItem();
    private static OperationDbItem operationDbItem = new OperationDbItem();
    private static OperSourceDbItem operSourceDbItem = new OperSourceDbItem();
    private static OperTypeDbItem operTypeDbItem = new OperTypeDbItem();
    private static StorageDbItem storageDbItem = new StorageDbItem();
    private static BalanceDbItem balanceDbItem = new BalanceDbItem();
    private static StatisticsDbItem statisticsDbItem = new StatisticsDbItem();

    public static CurrencyDbItem getCurrencyDbItem() {
	return currencyDbItem;
    }

    public static DateTimeDbItem getDatetimeDbItem() {
	return datetimeDbItem;
    }

    public static DescriptionDbItem getDescDbItem() {
	return descDbItem;
    }

    public static OperationDbItem getOperationDbItem() {
	return operationDbItem;
    }

    public static OperSourceDbItem getOperSourceDbItem() {
	return operSourceDbItem;
    }

    public static OperTypeDbItem getOperTypeDbItem() {
	return operTypeDbItem;
    }

    public static StorageDbItem getStorageDbItem() {
	return storageDbItem;
    }

    public static BalanceDbItem getBalanceDbItem() {
	return balanceDbItem;
    }

    public static StatisticsDbItem getStatisticsDbItem() {
	return statisticsDbItem;
    }

}
