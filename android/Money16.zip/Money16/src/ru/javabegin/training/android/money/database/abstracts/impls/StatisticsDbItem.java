package ru.javabegin.training.android.money.database.abstracts.impls;

import ru.javabegin.training.android.money.database.abstracts.AbstractDbListItem;
import ru.javabegin.training.android.money.enums.BarType;
import ru.javabegin.training.android.money.listview.items.interfaces.GraphBar;
import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.graph.OperationTypeBar;
import android.R;
import android.database.Cursor;

public class StatisticsDbItem extends AbstractDbListItem<GraphBar> {

    private BarType barType;

    @Override
    protected String getOneItemSQL(int itemId) {
	this.barType = BarType.getType(itemId);

	StringBuilder builder = new StringBuilder();
	builder.append("select t.name as " + ALIAS_NAME);

	switch (barType) {
	case INCOME_GRAPH:
	    builder.append(",sum(to_amount) as " + ALIAS_SUM);
	    break;

	case OUTCOME_GRAPH:
	    builder.append(", sum(from_amount) as " + ALIAS_SUM);
	    break;

	default:
	    break;
	}

	builder.append(" from " + OPERATIONS_TABLE + " o inner join " + OPER_TYPE_TABLE + " t on o.type_id=t._id where o.type_id =" + itemId + " group by type_id");
	return builder.toString();

    }

    @Override
    protected OperationTypeBar fillItem(Cursor c) {
	OperationTypeBar bar = new OperationTypeBar();
	bar.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));
	bar.setValue(c.getFloat(c.getColumnIndex(ALIAS_SUM)));

	switch (barType) {
	case INCOME_GRAPH:
	    bar.setColor(AppContext.getInstance().getResources().getColor(R.color.holo_green_dark));
	    break;

	case OUTCOME_GRAPH:
	    bar.setColor(AppContext.getInstance().getResources().getColor(R.color.holo_orange_dark));
	    break;

	default:
	    break;
	}

	return bar;
    }

}
