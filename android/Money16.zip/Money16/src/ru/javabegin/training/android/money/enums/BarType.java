package ru.javabegin.training.android.money.enums;

import java.util.HashMap;
import java.util.Map;

public enum BarType {

    INCOME_GRAPH(1), OUTCOME_GRAPH(2);

    private static Map<Integer, BarType> map = new HashMap<Integer, BarType>();

    static {
	for (BarType oper : BarType.values()) {
	    map.put(oper.getId(), oper);
	}
    }

    private Integer id;

    private BarType(Integer id) {
	this.id = id;
    }

    public Integer getId() {
	return id;
    }

    public static BarType getType(int id) {
	return map.get(id);
    }

}
