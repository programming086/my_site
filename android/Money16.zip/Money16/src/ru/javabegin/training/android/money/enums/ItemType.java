package ru.javabegin.training.android.money.enums;

public enum ItemType {

    HEADER, EDIT_ITEM, OPEN_ACTIVITY_ITEM, OPERATION;

}
