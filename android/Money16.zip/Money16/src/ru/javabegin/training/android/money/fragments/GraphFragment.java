package ru.javabegin.training.android.money.fragments;

import java.util.ArrayList;
import java.util.List;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.enums.BarType;
import ru.javabegin.training.android.money.listview.items.interfaces.GraphBar;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.echo.holographlibrary.Bar;
import com.echo.holographlibrary.BarGraph;

public class GraphFragment extends Fragment {

    private BarGraph barGraph;

//    private PieGraph pieGraph;

    @Override
    public void onCreate(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onCreate(savedInstanceState);

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
	// TODO Auto-generated method stub
	super.onActivityCreated(savedInstanceState);

	GraphBar barIncome = DbItemCreator.getStatisticsDbItem().getOneItem(BarType.INCOME_GRAPH.getId());
	GraphBar barOutcome = DbItemCreator.getStatisticsDbItem().getOneItem(BarType.OUTCOME_GRAPH.getId());

	List<GraphBar> bars = new ArrayList<GraphBar>();

	bars.add(barIncome);
	bars.add(barOutcome);

	updateBarGraph(bars);
//	updatePieGraph(bars);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

	View view = inflater.inflate(R.layout.fragment_graph, container, false);
	barGraph = (BarGraph) view.findViewById(R.id.bar_graph);
//	pieGraph = (PieGraph) view.findViewById(R.id.pie_graph);

	return view;
    }

    private void updateBarGraph(List<GraphBar> bar) {

	ArrayList<Bar> points = new ArrayList<Bar>();

	for (GraphBar graphBar : bar) {

	    Bar d = new Bar();
	    d.setColor(graphBar.getColor());
	    d.setName(graphBar.getName());
	    d.setValue(graphBar.getValue());
	    points.add(d);
	}

	barGraph.setBars(points);

    }

    private void updatePieGraph(List<GraphBar> bar) {

//	for (GraphBar graphBar : bar) {
//	    PieSlice slice = new PieSlice();
//	    slice.setColor(graphBar.getColor());
//	    slice.setValue(graphBar.getValue());
//	    slice.setTitle(graphBar.getName());
//	    pieGraph.addSlice(slice);
//	}

    }
}
