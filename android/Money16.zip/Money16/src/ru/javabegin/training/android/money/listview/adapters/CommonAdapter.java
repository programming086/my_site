package ru.javabegin.training.android.money.listview.adapters;

import java.util.List;

import ru.javabegin.training.android.money.enums.ItemType;
import ru.javabegin.training.android.money.listview.items.interfaces.BaseItem;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

public class CommonAdapter<T extends BaseItem> extends ArrayAdapter<T> {

    private List<T> items;
    private LayoutInflater inflater;

    public CommonAdapter(Context context, List<T> items) {
	super(context, 0, items);
	inflater = LayoutInflater.from(context);
	this.items = items;
    }

    @Override
    public int getViewTypeCount() {
	return ItemType.values().length;

    }

    @Override
    public int getItemViewType(int position) {
	return items.get(position).getViewType();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
	return items.get(position).getView(inflater, convertView);
    }

    public void update(List<T> items) {
	this.items.clear();
	this.items.addAll(items);
	notifyDataSetChanged();
    }

}
