package ru.javabegin.training.android.money.listview.items;

import java.math.BigDecimal;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.enums.ItemType;
import ru.javabegin.training.android.money.listview.items.interfaces.ImageItem;
import ru.javabegin.training.android.money.listview.items.interfaces.Validator;
import ru.javabegin.training.android.money.objects.AppContext;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.widget.EditText;
import android.widget.ImageView;

public class AmountItem implements ImageItem, Validator {

    private static final String ICON_NAME = "money";

    public AmountItem() {
    }

    public AmountItem(double amount) {
	this.amount = new BigDecimal(amount);
    }

    private int id;

    public int getId() {
	return id;
    }

    public void setId(int id) {
	this.id = id;
    }

    private BigDecimal newAmount;// хранит новое введенное пользователем
    // значение
    private BigDecimal amount;// хранит старое значение (при редактировании), до изменения - это нужно для правильного обновления баланса

    @Override
    public int getViewType() {
	return ItemType.EDIT_ITEM.ordinal();
    }

    public BigDecimal getNewAmount() {
	return newAmount;
    }

    public void setNewAmount(BigDecimal newAmount) {
	this.newAmount = newAmount;
    }

    public BigDecimal getAmount() {
	return amount;
    }

    public void setAmount(BigDecimal amount) {
	this.amount = amount;
    }

    @Override
    public View getView(LayoutInflater inflater, View convertView) {

	if (convertView == null) {

	    convertView = inflater.inflate(R.layout.listview_item_amount, null);

	    ViewHolder holder = new ViewHolder();

	    holder.txtAmount = (EditText) convertView.findViewById(R.id.txt_amount_input);

	    holder.image = (ImageView) convertView.findViewById(R.id.image_amount);

	    convertView.setTag(holder);
	}

	final ViewHolder holder = (ViewHolder) convertView.getTag();

	holder.txtAmount.setTextColor(Color.BLACK);

	holder.txtAmount.setTag(this);

	if (newAmount != null) {
	    holder.txtAmount.setText(newAmount.toString());
	} else {
	    holder.txtAmount.setText(amount.toString());
	}

	holder.txtAmount.setOnFocusChangeListener(new OnFocusChangeListener() {

	    @Override
	    public void onFocusChange(View v, boolean hasFocus) {
		EditText edit = (EditText) v;
		try {
		    System.out.println(Integer.valueOf(edit.getText().toString()));
		    if (Integer.valueOf(edit.getText().toString()) == 0) {
			edit.setText("");
		    }

		} catch (Exception e) {
		    edit.setText("");
		}

	    }
	});

	holder.txtAmount.addTextChangedListener(new TextWatcher() {

	    @Override
	    public void onTextChanged(CharSequence s, int start, int before, int count) {

	    }

	    @Override
	    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
		// TODO Auto-generated method stub

	    }

	    @Override
	    public void afterTextChanged(Editable s) {
		if (s.length() == 0) {
		    return;
		}
		AmountItem item = (AmountItem) holder.txtAmount.getTag();
		item.setNewAmount(new BigDecimal(holder.txtAmount.getText().toString()));
	    }
	});

	holder.image.setImageBitmap(getImage());

	return convertView;
    }

    protected static class ViewHolder {
	public EditText txtAmount;
	public ImageView image;
    }

    @Override
    public Bitmap getImage() {
	int imageId = AppContext.getInstance().getResources().getIdentifier(ICON_NAME, "drawable", AppContext.getInstance().getPackageName());

	return BitmapFactory.decodeResource(AppContext.getInstance().getResources(), imageId);
    }

    @Override
    public String getDisplayText() {
	// TODO Auto-generated method stub
	return null;
    }

    @Override
    public String getHint() {
	// TODO Auto-generated method stub
	return null;
    }

    @Override
    public boolean validate() {
	if (newAmount != null && newAmount.doubleValue() > 0) {
	    return true;
	}

	if (amount != null && amount.doubleValue() > 0) {
	    return true;
	}

	return false;
    }

    @Override
    public String getErrorValidateMessage() {
	return AppContext.getInstance().getResources().getString(R.string.empty_amount);
    }
}
