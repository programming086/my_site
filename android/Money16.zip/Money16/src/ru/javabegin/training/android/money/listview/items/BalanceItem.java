package ru.javabegin.training.android.money.listview.items;

import java.math.BigDecimal;


public class BalanceItem {

	private int id;

	private CurrencyItem currencyItem;

	private BigDecimal amount;

	private StorageItem storageItem;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public CurrencyItem getCurrencyItem() {
		return currencyItem;
	}

	public void setCurrencyItem(CurrencyItem currencyItem) {
		this.currencyItem = currencyItem;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public StorageItem getStorageItem() {
		return storageItem;
	}

	public void setStorageItem(StorageItem storageItem) {
		this.storageItem = storageItem;
	}

}
