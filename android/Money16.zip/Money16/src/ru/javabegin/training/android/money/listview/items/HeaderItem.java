package ru.javabegin.training.android.money.listview.items;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.enums.ItemType;
import ru.javabegin.training.android.money.listview.items.interfaces.BaseItem;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

public class HeaderItem implements BaseItem {

    private String text;

    public HeaderItem(String text) {
	this.text = text;
    }

    @Override
    public int getViewType() {
	return ItemType.HEADER.ordinal();
    }

    @Override
    public View getView(LayoutInflater inflater, View convertView) {

	if (convertView == null) {

	    convertView = inflater.inflate(R.layout.listview_item_header, null);

	    ViewHolder holder = new ViewHolder();

	    holder.txtHeader = (TextView) convertView.findViewById(R.id.txt_header);

	    convertView.setTag(holder);
	}

	final ViewHolder holder = (ViewHolder) convertView.getTag();

	holder.txtHeader.setText(text);

	return convertView;
    }

    protected static class ViewHolder {
	public TextView txtHeader;
    }

    @Override
    public String getDisplayText() {
	return text;
    }

}
