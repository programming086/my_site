package ru.javabegin.training.android.money.listview.items;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.listview.items.interfaces.SelectSprValueItem;
import ru.javabegin.training.android.money.listview.items.listeners.ChangeOperTypeListener;
import ru.javabegin.training.android.money.objects.AppContext;

public class OperSourceItem extends AbstractSprItem implements ChangeOperTypeListener {

    private static final long serialVersionUID = 1L;

    private static final String TABLE_NAME = "spr_OperationSource";

    public OperSourceItem() {
	setTableName(TABLE_NAME);
	setName(AppContext.getInstance().getResources().getString(R.string.operation_source));
    }

    @Override
    public void notifyItemSelected(SelectSprValueItem item) {
	if (item instanceof OperTypeItem) {// реагировать только на изменение типа операции
	    setSelectedChildItem(null);
	    setId(0);
	    setName(AppContext.getInstance().getResources().getString(R.string.operation_source));
	}
    }

    @Override
    public String getHint() {
	return AppContext.getInstance().getResources().getString(R.string.operation_source);
    }

    @Override
    public ArrayList<SelectSprValueItem> getList(boolean selectRoot) {
	if (!selectRoot) {
	    return new ArrayList<SelectSprValueItem>(DbItemCreator.getOperSourceDbItem().getChildItems(getId()));
	} else {
	    return new ArrayList<SelectSprValueItem>(DbItemCreator.getOperSourceDbItem().getRootItems());
	}
    }

    @Override
    public String getErrorValidateMessage() {
	return AppContext.getInstance().getResources().getString(R.string.empty_opersource);
    }

}
