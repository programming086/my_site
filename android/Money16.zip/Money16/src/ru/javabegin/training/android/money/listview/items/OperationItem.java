package ru.javabegin.training.android.money.listview.items;

import java.io.Serializable;
import java.text.DateFormat;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.database.abstracts.impls.OperationDbItem;
import ru.javabegin.training.android.money.enums.ItemType;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.listview.items.interfaces.BaseItem;
import ru.javabegin.training.android.money.objects.AppContext;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class OperationItem implements BaseItem, Serializable {

    private static final long serialVersionUID = 1L;

    private int id;
    private boolean editMode;

    // сумма, откуда переводим деньги
    private AmountItem fromAmountItem;

    // сумма, куда переводим деньги
    private AmountItem toAmountItem;

    // тип операции
    private OperTypeItem operTypeItem;

    // источник операции
    private OperSourceItem operSourceItem;

    // счет, куда переводим деньги
    private StorageItem toStorageItem;

    // счет, откуда переводим деньги
    private StorageItem fromStorageItem;

    // валюта, куда переводим деньги
    private CurrencyItem toCurrencyItem;

    // валюта, откуда переводим деньги
    private CurrencyItem fromCurrencyItem;

    private DescriptionItem descItem;
    private DateTimeItem dateTimeItem;

    public OperationItem() {
    }

    public OperationItem(boolean attemptFillLastValues) {// пытаемся установить последние выбранные значения

	if (attemptFillLastValues && DbItemCreator.getOperationDbItem().hasLastOperation()) {
	    OperationItem item = DbItemCreator.getOperationDbItem().getLastItem();
	    operTypeItem = getOperTypeItem();
	    operSourceItem = getOperSourceItem();

	    fromStorageItem = getFromStorageItem();
	    toStorageItem = getToStorageItem();

	    fromCurrencyItem = getFromCurrencyItem();
	    toCurrencyItem = getToCurrencyItem();

	    fromAmountItem = getFromAmountItem();
	    toAmountItem = getToAmountItem();

	    descItem = getDescItem();
	    dateTimeItem = getDateTimeItem();
	}

	if (fromAmountItem == null) {
	    fromAmountItem = new AmountItem(0);
	}

	if (toAmountItem == null) {
	    toAmountItem = new AmountItem(0);
	}

	if (operTypeItem == null) {
	    operTypeItem = new OperTypeItem();
	}

	if (operSourceItem == null) {
	    operSourceItem = new OperSourceItem();
	}

	if (fromStorageItem == null) {
	    fromStorageItem = new StorageItem();
	}

	if (toStorageItem == null) {
	    toStorageItem = new StorageItem();
	}

	if (fromCurrencyItem == null) {
	    fromCurrencyItem = new CurrencyItem();
	}

	if (toCurrencyItem == null) {
	    toCurrencyItem = new CurrencyItem();
	}

	if (descItem == null) {
	    descItem = new DescriptionItem();
	}

	if (dateTimeItem == null) {
	    dateTimeItem = new DateTimeItem();
	}

    }

    public boolean save() {
	return DbItemCreator.getOperationDbItem().saveOperation(this);
    }

    public int getId() {
	return id;
    }

    public void setId(int id) {
	this.id = id;
    }

    public boolean isEditMode() {
	return editMode;
    }

    public AmountItem getFromAmountItem() {
	return fromAmountItem;
    }

    public void setFromAmountItem(AmountItem fromAmountItem) {
	this.fromAmountItem = fromAmountItem;
    }

    public AmountItem getToAmountItem() {
	return toAmountItem;
    }

    public void setToAmountItem(AmountItem toAmountItem) {
	this.toAmountItem = toAmountItem;
    }

    public void setEditMode(boolean editMode) {
	this.editMode = editMode;
    }

    public OperTypeItem getOperTypeItem() {
	return operTypeItem;
    }

    public void setOperTypeItem(OperTypeItem operTypeItem) {
	this.operTypeItem = operTypeItem;
    }

    public OperSourceItem getOperSourceItem() {
	return operSourceItem;
    }

    public void setOperSourceItem(OperSourceItem operSourceItem) {
	this.operSourceItem = operSourceItem;
    }

    public StorageItem getToStorageItem() {
	return toStorageItem;
    }

    public void setToStorageItem(StorageItem toStorageItem) {
	this.toStorageItem = toStorageItem;
    }

    public StorageItem getFromStorageItem() {
	return fromStorageItem;
    }

    public void setFromStorageItem(StorageItem fromStorageItem) {
	this.fromStorageItem = fromStorageItem;
    }

    public CurrencyItem getToCurrencyItem() {
	return toCurrencyItem;
    }

    public void setToCurrencyItem(CurrencyItem toCurrencyItem) {
	this.toCurrencyItem = toCurrencyItem;
    }

    public CurrencyItem getFromCurrencyItem() {
	return fromCurrencyItem;
    }

    public void setFromCurrencyItem(CurrencyItem fromCurrencyItem) {
	this.fromCurrencyItem = fromCurrencyItem;
    }

    public DescriptionItem getDescItem() {
	return descItem;
    }

    public void setDescItem(DescriptionItem descItem) {
	this.descItem = descItem;
    }

    public DateTimeItem getDateTimeItem() {
	return dateTimeItem;
    }

    public void setDateTimeItem(DateTimeItem dateTimeItem) {
	this.dateTimeItem = dateTimeItem;
    }

    @Override
    public int getViewType() {
	return ItemType.OPERATION.ordinal();
    }

    @Override
    public View getView(LayoutInflater inflater, View convertView) {

	if (convertView == null) {

	    ViewHolder holder = new ViewHolder();

	    convertView = inflater.inflate(R.layout.listview_item_operation, null);

	    holder.source = (TextView) convertView.findViewById(R.id.txt_oper_source);
	    holder.date = (TextView) convertView.findViewById(R.id.txt_oper_date);
	    holder.image = (ImageView) convertView.findViewById(R.id.img_source);
	    holder.time = (TextView) convertView.findViewById(R.id.txt_oper_time);
	    holder.amount = (TextView) convertView.findViewById(R.id.txt_oper_amount);
	    holder.type = (TextView) convertView.findViewById(R.id.txt_oper_type);
	    holder.currency = (TextView) convertView.findViewById(R.id.txt_oper_currency);
	    holder.desc = (TextView) convertView.findViewById(R.id.txt_desc);

	    convertView.setTag(holder);
	}

	ViewHolder holder = (ViewHolder) convertView.getTag();

	String imageName = null;

	switch (OperationType.getType(getOperTypeItem().getId())) {
	case INCOME:

	    holder.amount.setText(String.valueOf(getToAmountItem().getAmount()));
	    holder.source.setText(getOperSourceItem().getName());
	    holder.currency.setText(getToCurrencyItem().getCode());

	    imageName = OperationDbItem.OPER_SOURCE_TABLE.toLowerCase() + getOperSourceItem().getId();

	    break;
	case OUTCOME:
	    holder.amount.setText(String.valueOf(getFromAmountItem().getAmount()));
	    holder.source.setText(getOperSourceItem().getName());
	    holder.currency.setText(getFromCurrencyItem().getCode());

	    imageName = OperationDbItem.OPER_SOURCE_TABLE.toLowerCase() + getOperSourceItem().getId();

	    break;

	case TRANSFER:
	    holder.amount.setText(String.valueOf(getFromAmountItem().getAmount()));
	    holder.source.setText(getFromStorageItem().getName() + " > " + getToStorageItem().getName());
	    holder.currency.setText(getFromCurrencyItem().getCode());

	    imageName = OperationDbItem.OPER_TYPE_TABLE.toLowerCase() + getOperTypeItem().getId();

	    break;

	case CONVERT:
	    holder.amount.setText(String.valueOf(getFromAmountItem().getAmount()) + " " + getFromCurrencyItem().getCode() + " > ");
	    holder.source.setText(getFromStorageItem().getName() + " > " + getToStorageItem().getName());
	    holder.currency.setText(String.valueOf(getToAmountItem().getAmount()) + " " + getToCurrencyItem().getCode());

	    imageName = OperationDbItem.OPER_TYPE_TABLE.toLowerCase() + getOperTypeItem().getId();

	    break;

	default:
	    break;
	}

	try {
	    holder.image.setImageBitmap(getImage(imageName));
	} catch (Exception e) {
	    e.printStackTrace();
	}

	holder.type.setText(" - (" + getOperTypeItem().getName() + ")");

	String desc = getDescItem().getDisplayText();

	if (desc != null && desc.length() > 0) {
	    desc = (desc.length() < 20) ? desc : desc.substring(0, 19) + " ...";
	    holder.desc.setText(" (" + desc + ") ");
	    holder.desc.setVisibility(View.VISIBLE);
	} else {
	    holder.desc.setVisibility(View.GONE);
	}

	holder.date.setText(DateFormat.getDateInstance(DateFormat.MEDIUM).format(getDateTimeItem().getCalendar().getTime()) + ", ");
	holder.time.setText(DateFormat.getTimeInstance(DateFormat.SHORT).format(getDateTimeItem().getCalendar().getTime()));

	if (getOperTypeItem().getId() == Integer.valueOf(OperationType.INCOME.getId())) {
	    holder.type.setTextColor(AppContext.getInstance().getResources().getColor(R.color.green_dark));
	} else {
	    holder.type.setTextColor(AppContext.getInstance().getResources().getColor(R.color.red_dark));
	}

	return convertView;

    }

    private Bitmap getImage(String name) {
	int imageId = AppContext.getInstance().getResources().getIdentifier(name, "drawable", AppContext.getInstance().getPackageName());
	return BitmapFactory.decodeResource(AppContext.getInstance().getResources(), imageId);
    }

    protected static class ViewHolder {
	public TextView date;
	public ImageView image;
	public TextView time;
	public TextView amount;
	public TextView source;
	public TextView type;
	public TextView currency;
	public TextView desc;
    }

    @Override
    public String getDisplayText() {
	// TODO Auto-generated method stub
	return null;
    }

}
