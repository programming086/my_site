package ru.javabegin.training.android.money.listview.items;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.listview.items.interfaces.SelectSprValueItem;
import ru.javabegin.training.android.money.objects.AppContext;

public class StorageItem extends AbstractSprItem {

    private static final long serialVersionUID = 1L;

    private static final String TABLE_NAME = "spr_StorageType";

    public StorageItem() {
	setTableName(TABLE_NAME);
	setName(AppContext.getInstance().getResources().getString(R.string.storage));
    }

    @Override
    public String getHint() {
	return AppContext.getInstance().getResources().getString(R.string.storage);
    }

    @Override
    public ArrayList<SelectSprValueItem> getList(boolean selectRoot) {
	if (!selectRoot) {
	    return new ArrayList<SelectSprValueItem>(DbItemCreator.getStorageDbItem().getChildItems(getId()));
	} else {
	    return new ArrayList<SelectSprValueItem>(DbItemCreator.getStorageDbItem().getRootItems());
	}
    }

    @Override
    public String getErrorValidateMessage() {
	return AppContext.getInstance().getResources().getString(R.string.empty_storage);
    }

}
