package ru.javabegin.training.android.money.listview.items.abstracts;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.enums.ItemType;
import ru.javabegin.training.android.money.listview.items.interfaces.ImageItem;
import ru.javabegin.training.android.money.listview.items.interfaces.SelectSprValueItem;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public abstract class AbstractItem implements ImageItem {

    /**
	 * 
	 */
    private static final long serialVersionUID = -8788143842118167442L;

    @Override
    public int getViewType() {
	return ItemType.OPEN_ACTIVITY_ITEM.ordinal();
    }

    @Override
    public View getView(LayoutInflater inflater, View convertView) {

	if (convertView == null) {

	    convertView = inflater.inflate(R.layout.listview_item_sprvalue, null);

	    ViewHolder holder = new ViewHolder();

	    holder.txtSprName = (TextView) convertView.findViewById(R.id.spr_value);
	    holder.image = (ImageView) convertView.findViewById(R.id.image_spr_value);
	    holder.imageArrow = (ImageView) convertView.findViewById(R.id.image_arrow);

	    convertView.setTag(holder);
	}

	ViewHolder holder = (ViewHolder) convertView.getTag();

	// для выбора справочных значений - отображать стрелочки или нет (если есть дочерние пункты)
	if (this instanceof SelectSprValueItem) {

	    if (((SelectSprValueItem) this).hasChilds()) {
		holder.imageArrow.setVisibility(View.VISIBLE);
	    } else {
		holder.imageArrow.setVisibility(View.INVISIBLE);
	    }

	}

	if (getDisplayText() != null) { // выбрано новое значение

	    holder.txtSprName.setTextColor(Color.BLACK);

	    holder.txtSprName.setText(getDisplayText());

	} else {// ничего не выбрано
	    holder.txtSprName.setTextColor(Color.GRAY);
	    holder.txtSprName.setText(getHint());
	}

	holder.image.setImageBitmap(getImage());

	return convertView;
    }

    protected static class ViewHolder {
	public TextView txtSprName;
	public ImageView image;
	public ImageView imageArrow;
    }

}
