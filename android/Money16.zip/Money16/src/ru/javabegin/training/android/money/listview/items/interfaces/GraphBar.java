package ru.javabegin.training.android.money.listview.items.interfaces;


public interface GraphBar {

    String getName();

    float getValue();

    int getColor();

}
