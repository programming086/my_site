package ru.javabegin.training.android.money.listview.items.interfaces;

import android.content.Intent;

public interface OpenActivityItem extends ImageItem {

	Intent getClickIntent(); // куда переходить по клику

	Intent getResultIntent(); // куда возвращать результат

	int getRequestCode(); // код возврата, чтобы различать, чей результат

}
