package ru.javabegin.training.android.money.listview.items.interfaces;

import java.util.ArrayList;

public interface SelectSprValueItem extends OpenActivityItem, Validator {

    ArrayList<SelectSprValueItem> getList(boolean selectRoot);

    boolean hasChilds();

    String getTableName();

    SelectSprValueItem getSelectedChildItem(); // для хранения выбранного справочного значения

    String getName();

    int getId();

}
