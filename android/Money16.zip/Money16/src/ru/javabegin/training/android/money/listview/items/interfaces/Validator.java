package ru.javabegin.training.android.money.listview.items.interfaces;

public interface Validator {

    boolean validate();

    String getErrorValidateMessage();

}
