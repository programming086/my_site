package ru.javabegin.training.android.money.objects.graph;

import ru.javabegin.training.android.money.listview.items.interfaces.GraphBar;

public class OperationTypeBar implements GraphBar {

    private float value;
    private int color;
    private String name;

    public OperationTypeBar() {
	// TODO Auto-generated constructor stub
    }

    public OperationTypeBar(float value, int color, String name) {
	super();
	this.value = value;
	this.color = color;
	this.name = name;
    }

    public void setColor(int color) {
	this.color = color;
    }

    public void setName(String name) {
	this.name = name;
    }

    public void setValue(float value) {
	this.value = value;
    }

    @Override
    public String getName() {
	return name;
    }

    @Override
    public float getValue() {
	return value;
    }

    @Override
    public int getColor() {
	return color;
    }

}
