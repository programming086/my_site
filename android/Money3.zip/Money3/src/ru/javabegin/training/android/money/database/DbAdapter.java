package ru.javabegin.training.android.money.database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbAdapter {

	public static final String DB_NAME = "money.db";
	public static final int DB_VERSION = 1;
	
	private static final String TABLE_OPERATION = "operation";

	private DbHelper dbHelper;
	private Context context;
	private SQLiteDatabase db;


	public DbAdapter(Context context) {
		this.context = context;
	}

	public void createDatabaseInstance(){		
		dbHelper = new DbHelper(context);
		db = dbHelper.getReadableDatabase();
	}
	
	
	public void getTranscationList(){
		
		Cursor c = db.query(TABLE_OPERATION, null, null, null, null, null, null);
		
		if (c!=null){
			while (c.moveToNext()){				
				System.out.println(c.getInt(c.getColumnIndex("amount")));								
			}
		}
	}

	private static class DbHelper extends SQLiteOpenHelper {

		public DbHelper(Context context) {
			super(context, DB_NAME, null, DB_VERSION);

		}

		@Override
		public void onCreate(SQLiteDatabase db) {

		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

		}


	}
}
