package ru.javabegin.training.android.money.activities;

import java.util.List;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.DbAdapter;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.gui.MenuExpandableList;
import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.Operation;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class OperationsFragment extends Fragment {

	private TextView txtContent;
	private OperationType transactionType;
	
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		View view = inflater.inflate(R.layout.fragment_operations, container,
				false);

		txtContent = (TextView) view.findViewById(R.id.txt_content);
		
		switch (Integer.valueOf(getArguments().getInt(MenuExpandableList.OPERATION_TYPE))) {
			case 0: {
				this.transactionType = OperationType.INCOME;
				break;
			}
			case 1: {
				this.transactionType = OperationType.OUTCOME;
				break;
			}
		}

		fillTextContent();
	
		return view;
	}


	private void fillTextContent() {
		List<Operation> listOperations = AppContext.getDbAdapter().getOperations(transactionType);
		
		for (Operation operation : listOperations) {
			txtContent.setText(txtContent.getText()+operation.getAmount().toString()+"\n");
		}
		
	}

}
