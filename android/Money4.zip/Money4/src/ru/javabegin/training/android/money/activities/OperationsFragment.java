package ru.javabegin.training.android.money.activities;

import ru.javabegin.training.android.money.adapters.OperationsAdapter;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.gui.MenuExpandableList;
import ru.javabegin.training.android.money.objects.AppContext;
import android.app.ListFragment;
import android.os.Bundle;

public class OperationsFragment extends ListFragment {

	private OperationType operationType;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		
		int type = Integer.valueOf(getArguments().getInt(MenuExpandableList.OPERATION_TYPE));
		
		switch (type) {
		case 0: {
			this.operationType = OperationType.ALL;
			break;
		}
		case 1: {
			this.operationType = OperationType.INCOME;
			break;
		}
		case 2: {
			this.operationType = OperationType.OUTCOME;
			break;
		}
		}

		OperationsAdapter operationsAdapter = new OperationsAdapter(
				getActivity(), AppContext.getDbAdapter().getOperations(
						operationType), false);

		setListAdapter(operationsAdapter);
	}

}
