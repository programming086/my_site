package ru.javabegin.training.android.money.objects;

import java.io.File;
import java.io.IOException;

import ru.javabegin.training.android.money.database.DbAdapter;
import android.app.Application;

public class AppContext extends Application {

	private static final String ICONS_FOLDER = "icons";
	private File iconFolder;
	
	public static final int IMAGE_WIDTH_THMB = 64;
	public static final int IMAGE_HEIGHT_THMB = 64;
	
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		dbAdapter = new DbAdapter(this);
	}

	private static DbAdapter dbAdapter;

	public static DbAdapter getDbAdapter() {
		return dbAdapter;
	}

	

	public String getIconsFolder() {

		if (iconFolder==null){
			iconFolder = new File(getApplicationInfo().dataDir+"/"+ICONS_FOLDER);
		}
		
		if (!iconFolder.exists()) {
			try {
				if (!iconFolder.createNewFile()) {
					throw new Exception("can't create folder for icons!");
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			
		}
		
		return iconFolder.getAbsolutePath();
	}

}
