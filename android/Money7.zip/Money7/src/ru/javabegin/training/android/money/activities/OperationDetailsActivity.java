package ru.javabegin.training.android.money.activities;

import java.util.HashMap;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.fragments.SprListFragment;
import ru.javabegin.training.android.money.objects.spr.SelectedValue;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;

// активити для создания/редактирования операции 
public class OperationDetailsActivity extends AnimationActivity {

	public static final String MAP = "ru.javabegin.training.android.money.activities.map";


	private HashMap<String, SelectedValue> mapSelectedValues; // выбранные значения для
														// каждого типа
														// справочника

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_operation_details);

		mapSelectedValues = new HashMap<String, SelectedValue>();

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.operation_details, menu);
		return true;
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();

		// показать список всех справочников
		Fragment fragment = new SprListFragment();
		Bundle args = new Bundle();

		// передать список всех выбранных ранее значений (чтобы вместо
		// названия справочника выходило выбранное значение)
		if (mapSelectedValues != null) {
			args.putSerializable(MAP, mapSelectedValues); // TODO сделать передачу не через Serializable
			fragment.setArguments(args);
		}

		FragmentManager fragmentManager = getFragmentManager();
		fragmentManager.beginTransaction().replace(R.id.spr_metadata_fragment, fragment).commit();

	}

	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);

		// если выбрано какое-то значение справочника
		if (intent.getExtras() != null && !intent.getExtras().isEmpty()) {

			SelectedValue selectedValue = (SelectedValue) intent
					.getSerializableExtra(SelectedValue.VALUES);

			String mapKey = selectedValue.getBaseTableName();

			mapSelectedValues.put(mapKey, selectedValue);// добавить выбранное значени в общий список
			
		}

	}

	
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		super.onSaveInstanceState(outState);
		outState.putSerializable(MAP, mapSelectedValues);
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onRestoreInstanceState(savedInstanceState);
		mapSelectedValues = (HashMap<String, SelectedValue>) savedInstanceState.get(MAP);
	}

}
