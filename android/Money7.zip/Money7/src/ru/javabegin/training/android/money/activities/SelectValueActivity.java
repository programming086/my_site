package ru.javabegin.training.android.money.activities;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.fragments.SprValuesFragment;
import ru.javabegin.training.android.money.objects.spr.SelectedValue;
import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.view.Menu;

// активити для выбора конкретного справочного значения
public class SelectValueActivity extends AnimationActivity {
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_spr_value);
		
		SelectedValue selectedValue = (SelectedValue)getIntent().getSerializableExtra(SelectedValue.VALUES);
		
		// показать список справочных значений
		Fragment fragment = new SprValuesFragment();
		Bundle args = new Bundle();
		args.putSerializable(SelectedValue.VALUES, selectedValue);

		fragment.setArguments(args);
		
		FragmentManager fragmentManager = getFragmentManager();
		fragmentManager.beginTransaction().replace(R.id.spr_frame, fragment).commit();
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.spr_value, menu);
		return true;
	}


}
