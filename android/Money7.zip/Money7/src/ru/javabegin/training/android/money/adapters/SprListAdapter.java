package ru.javabegin.training.android.money.adapters;

import java.io.Serializable;
import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.objects.spr.SelectedValue;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class SprListAdapter extends ArrayAdapter<SelectedValue> implements
		Serializable {

	private static final long serialVersionUID = -6871278106989089049L;

	public SprListAdapter(Context context, ArrayList<SelectedValue> objects) {
		super(context, R.id.spr_name, objects);
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {

		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(R.layout.metadata_spr_value, parent, false);

			ViewHolder holder = new ViewHolder();

			holder.txtSprName = (TextView) convertView.findViewById(R.id.spr_name);	

			convertView.setTag(holder);
		}

		ViewHolder holder = (ViewHolder) convertView.getTag();

		SelectedValue sprValue = getItem(position);
		
		if (sprValue.isUserSelected()){ // если пользователь выбрал конкретное значение справочника
			holder.txtSprName.setText(sprValue.getValue());
			holder.txtSprName.setTextColor(getContext().getResources().getColor(R.color.green_dark));
		}else{
			if (isEnabled(position)){
				holder.txtSprName.setTextColor(Color.BLACK);
			}
			holder.txtSprName.setText("("+sprValue.getValue()+")");
		}

		return convertView;
	}

	private static class ViewHolder {
		public TextView txtSprName;
	}
	
	@Override
	public boolean isEnabled(int position) {
		if (position==0 || getItem(position-1).isUserSelected()){// если выбрали предыдущее значение (или это первый пункт в списке)
			return true;
		}
		return false;
	}
	

}
