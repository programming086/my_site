package ru.javabegin.training.android.money.adapters;

import java.io.Serializable;
import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.objects.spr.SelectedValue;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class SprValueAdapter extends ArrayAdapter<SelectedValue> implements
		Serializable {

	private static final long serialVersionUID = -6871278106989089049L;

	public SprValueAdapter(Context context, ArrayList<SelectedValue> objects) {
		super(context, R.id.spr_name, objects);
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {

		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater.inflate(R.layout.spr_value, parent, false);

			ViewHolder holder = new ViewHolder();

			holder.txtSprName = (TextView) convertView.findViewById(R.id.spr_value);
			holder.imageArrow = (ImageView) convertView.findViewById(R.id.image_arrow);

			convertView.setTag(holder);
		}

		ViewHolder holder = (ViewHolder) convertView.getTag();

		SelectedValue sprValue = getItem(position);
		
		holder.txtSprName.setText(sprValue.getValue());
	
		if (!sprValue.isHasChild()){
			holder.imageArrow.setVisibility(View.INVISIBLE);
		}
		

		return convertView;
	}

	private static class ViewHolder {
		public TextView txtSprName;
		public ImageView imageArrow;
	}
	

}
