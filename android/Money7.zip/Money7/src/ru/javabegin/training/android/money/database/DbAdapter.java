package ru.javabegin.training.android.money.database;

import java.util.ArrayList;

import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.objects.spr.SelectedValue;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbAdapter {

	public static final String DB_NAME = "money.db";
	public static final int DB_VERSION = 1;

	private DbHelper dbHelper;
	private Context context;
	private SQLiteDatabase db;
	
	public static final String ALIAS_ID = "_id";
	public static final String ALIAS_AMOUNT = "amount";
	public static final String ALIAS_CURRENCY = "currency";
	public static final String ALIAS_OPERATION_DATETIME = "operationDateTime";
	public static final String ALIAS_SOURCE = "source";
	public static final String ALIAS_TYPE = "type";
	public static final String ALIAS_TYPE_ID = "type_id";
	public static final String ALIAS_SOURCE_ID = "sourceId";

	public static final String ALIAS_SPR_VALUE = "sprValue";
	public static final String ALIAS_HAS_CHILD = "hasChild";
	public static final String ALIAS_TABLE_NAME = "tableName";
	public static final String ALIAS_ORDER = "orderShow";

	public DbAdapter(Context context) {
		this.context = context;
		dbHelper = new DbHelper(context);
		db = dbHelper.getReadableDatabase();
	}

	public Cursor getOperations(OperationType type) {

		Cursor c = null;
		StringBuilder builder = new StringBuilder();

		builder.append("select " + "t.name as " + ALIAS_TYPE + ",s.type_id as "
				+ ALIAS_TYPE_ID + ",o._id as " + ALIAS_ID + ",c.short_name as "
				+ ALIAS_CURRENCY + ",o.[amount] as " + ALIAS_AMOUNT
				+ ",o.[operation_datetime] as " + ALIAS_OPERATION_DATETIME
				+ ",s.[name] as " + ALIAS_SOURCE + ",o.[source_id] as "
				+ ALIAS_SOURCE_ID + " from operations o "
				+ " inner join spr_currency c on o.currency_id=c.[_id]  "
				+ " inner join spr_operationsource s on o.source_id=s.[_id] "
				+ " inner join spr_operationtype t on s.type_id=t.[_id] ");

		if (type != OperationType.ALL) {
			builder.append(" where o.type_id=?");
			c = db.rawQuery(builder.toString(), new String[] { type.getId() });
		} else {
			c = db.rawQuery(builder.toString(), null);
		}

		return c;

	}

	// показать пункты справочника
	public ArrayList<SelectedValue> getSprValues(SelectedValue selectedValue) {

		Cursor c = null;
		StringBuilder builder = new StringBuilder();

		builder.append("select s1._id as " + ALIAS_ID + ", s1.name  as "
				+ ALIAS_SPR_VALUE + ", coalesce((select _id from "
				+ selectedValue.getBaseTableName()
				+ " s2 where s2.parent_id=s1._id limit 1),0)  as "
				+ ALIAS_HAS_CHILD + " from " + selectedValue.getBaseTableName() + " s1 ");
		
		if (selectedValue.isShowChilds()){
			builder.append(" where coalesce(s1.parent_id,0) = "+ selectedValue.getId() + " order by name");// все дочерние объекты для выбранного 	
		}else{
			builder.append(" where coalesce(s1.parent_id,0) = 0 order by name");// все корневые элементы			
		}
		
		
		c = db.rawQuery(builder.toString(), null);

		ArrayList<SelectedValue> sprList = new ArrayList<SelectedValue>();

		while (c.moveToNext()) {
			SelectedValue sprValue = new SelectedValue();
			sprValue.setId(c.getInt(c.getColumnIndex(DbAdapter.ALIAS_ID)));
			sprValue.setValue(c.getString(c.getColumnIndex(DbAdapter.ALIAS_SPR_VALUE)));
			sprValue.setBaseTableName(selectedValue.getBaseTableName());
			sprValue.setPosition(selectedValue.getPosition());

			int hasChild = c.getInt(c.getColumnIndex(DbAdapter.ALIAS_HAS_CHILD));

			if (hasChild > 0) {
				sprValue.setHasChild(true);
			} else {
				sprValue.setHasChild(false);
			}

			sprList.add(sprValue);
		}

		return sprList;

	}

	// показать все справочники
	public ArrayList<SelectedValue> getSprList() {
		
		Cursor c = null;
		StringBuilder builder = new StringBuilder();

		builder.append("select " + 
				"_id as " + ALIAS_ID + 
				",name as " + ALIAS_SPR_VALUE + 
				",table_name as " + ALIAS_TABLE_NAME +
				",order_show as " + ALIAS_ORDER +
				" from spr_Metadata order by order_show");

		c = db.rawQuery(builder.toString(), null);

		ArrayList<SelectedValue> sprList = new ArrayList<SelectedValue>();

		while (c.moveToNext()) {
			SelectedValue sprValue = new SelectedValue();
			sprValue.setId(c.getInt(c.getColumnIndex(DbAdapter.ALIAS_ID)));
			sprValue.setValue(c.getString(c.getColumnIndex(DbAdapter.ALIAS_SPR_VALUE)));
			sprValue.setBaseTableName(c.getString(c.getColumnIndex(DbAdapter.ALIAS_TABLE_NAME)));
			sprValue.setPosition(c.getInt(c.getColumnIndex(DbAdapter.ALIAS_ORDER)));

			sprList.add(sprValue);
		}

		return sprList;

	}

	

	private static class DbHelper extends SQLiteOpenHelper {

		public DbHelper(Context context) {
			super(context, DB_NAME, null, DB_VERSION);

		}

		@Override
		public void onCreate(SQLiteDatabase db) {

		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

		}

	}
	


}
