package ru.javabegin.training.android.money.fragments;

import java.util.ArrayList;
import java.util.HashMap;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.activities.OperationDetailsActivity;
import ru.javabegin.training.android.money.activities.SelectValueActivity;
import ru.javabegin.training.android.money.adapters.SprListAdapter;
import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.spr.SelectedValue;
import android.app.ListFragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

// список всех общих справочников (для каждого из них пользователь будет выбирать значение)
public class SprListFragment extends ListFragment {

	private Intent intentSelectValueActivity;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		intentSelectValueActivity = new Intent(getActivity(), SelectValueActivity.class);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);

	
		ArrayList<SelectedValue> sprList = AppContext.getDbAdapter().getSprList();


		if (getArguments() != null && !getArguments().isEmpty()) {

			// список типов справочников, для которых уже есть выбранные
			// значения 
			HashMap<String, SelectedValue> mapSelectedValue = (HashMap<String, SelectedValue>) getArguments().getSerializable(OperationDetailsActivity.MAP);

			if (mapSelectedValue != null && !mapSelectedValue.isEmpty()) {
				
				for (SelectedValue sprValue : sprList) {
					
					if (mapSelectedValue.containsKey(sprValue.getBaseTableName())){
						sprValue.setValue(mapSelectedValue.get(sprValue.getBaseTableName()).getValue());// заменяем название таблицы на выбранное справочное значение
						sprValue.setUserSelected(true);
					}
					
					
				}
				
			}
		}

		setListAdapter(new SprListAdapter(getActivity(), sprList));

	}

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {

		SelectedValue selectedValue = ((SelectedValue) l.getAdapter().getItem(position));
		
		intentSelectValueActivity.putExtra(SelectedValue.VALUES, selectedValue);
		selectedValue.setShowChilds(false);

		startActivity(intentSelectValueActivity);
		getActivity().overridePendingTransition(R.anim.pull_in_right,
				R.anim.push_out_left);

	}

}
