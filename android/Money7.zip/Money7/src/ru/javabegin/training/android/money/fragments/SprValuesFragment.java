package ru.javabegin.training.android.money.fragments;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.activities.OperationDetailsActivity;
import ru.javabegin.training.android.money.activities.SelectValueActivity;
import ru.javabegin.training.android.money.adapters.SprValueAdapter;
import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.spr.SelectedValue;
import android.app.ListFragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

// список пунктов внутри справочника
public class SprValuesFragment extends ListFragment {

	private Intent intentSelectValueActivity;
	private Intent intentOperDetailsActivity;

	private SelectedValue selectedValue;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		intentSelectValueActivity = new Intent(getActivity(), SelectValueActivity.class);
		intentOperDetailsActivity = new Intent(getActivity(), OperationDetailsActivity.class);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);
		
		selectedValue = (SelectedValue)getArguments().getSerializable(SelectedValue.VALUES);

		ArrayList<SelectedValue> sprValuesList = AppContext.getDbAdapter().getSprValues(selectedValue);

		setListAdapter(new SprValueAdapter(getActivity(), sprValuesList));

	}

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {

		SelectedValue sprValue = ((SelectedValue) l.getAdapter().getItem(position));

		if (sprValue.isHasChild()) {

			// если у справочного знаения есть дочерние пункты - открываем их
			intentSelectValueActivity.putExtra(SelectedValue.VALUES, sprValue);
			sprValue.setShowChilds(true);

			startActivity(intentSelectValueActivity);
			getActivity().overridePendingTransition(R.anim.pull_in_right, R.anim.push_out_left);
			
		}else{ 
//			intentOperationDetails.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			
			intentOperDetailsActivity.putExtra(SelectedValue.VALUES, sprValue);
			
			startActivity(intentOperDetailsActivity);
			getActivity().overridePendingTransition(R.anim.pull_in_left, R.anim.push_out_right);
		}
	}

}
