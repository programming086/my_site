package ru.javabegin.training.android.money.objects.spr;

import java.io.Serializable;

// хранит значения при выборе справочников и их пунктов (для передачи между разными активити)
public class SelectedValue implements Serializable {
	
	public static final String VALUES = "ru.javabegin.training.android.money.objects.spr.Values";

	private static final long serialVersionUID = -1619045347770223522L;

	private int id;// выбранный id
	private String value;// выбранное значение
	private boolean userSelected;// выбрал ли пользователь конкретное значение справочника
	private boolean hasChild;// есть ли дочерние пункты у справочного значения

	private boolean showChilds;// показывать дочерние пункты от этого или нет
	
	
	
	// для показа названий справочников
	private String baseTableName;// название базовой справ. таблицы (метаданные о справочниках)
	private int position;// порядок в списке справочников
	
	
	
	public SelectedValue() {
		// TODO Auto-generated constructor stub
	}
	
	public SelectedValue(String value, int id) {
		this.value = value;
		this.id = id;
	}


	

	public boolean isShowChilds() {
		return showChilds;
	}
	
	public void setShowChilds(boolean showChilds) {
		this.showChilds = showChilds;
	}
	
	public String getBaseTableName() {
		return baseTableName;
	}
	
	public void setBaseTableName(String baseTableName) {
		this.baseTableName = baseTableName;
	}
	
	public int getPosition() {
		return position;
	}
	
	public void setPosition(int position) {
		this.position = position;
	}
	
	public boolean isHasChild() {
		return hasChild;
	}
	
	public void setHasChild(boolean hasChild) {
		this.hasChild = hasChild;
	}

	
	
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public boolean isUserSelected() {
		return userSelected;
	}
	
	public void setUserSelected(boolean selected) {
		this.userSelected = selected;
	}

}
