package ru.javabegin.training.android.money.fragments;

import ru.javabegin.training.android.money.adapters.OperationsAdapter;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.gui.MenuExpandableList;
import ru.javabegin.training.android.money.objects.AppContext;
import android.app.ListFragment;
import android.database.Cursor;
import android.os.Bundle;

// отображает список операций
public class OperationsFragment extends ListFragment {

	private OperationType operationType;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);

		OperationType operType = (OperationType)getArguments().getSerializable(MenuExpandableList.OPERATION_TYPE);

		cursor = AppContext.getDbAdapter().getOperations(operType);
		OperationsAdapter operationsAdapter = new OperationsAdapter(getActivity(), cursor, false);

		setListAdapter(operationsAdapter);
	}

	private Cursor cursor;

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		cursor.close();
	}

}
