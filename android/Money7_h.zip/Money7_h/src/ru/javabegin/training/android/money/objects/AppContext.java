package ru.javabegin.training.android.money.objects;

import ru.javabegin.training.android.money.database.DbAdapter;
import android.app.Application;

public class AppContext extends Application {

	public static final int IMAGE_WIDTH_THMB = 64;
	public static final int IMAGE_HEIGHT_THMB = 64;
	
	 private static AppContext context;
	
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		dbAdapter = new DbAdapter(this);
		context = this;
	}

	private static DbAdapter dbAdapter;

	public static DbAdapter getDbAdapter() {
		return dbAdapter;
	}
	
	public static AppContext getAppContext(){
		return context;
	}

	

}
