package ru.javabegin.training.android.money.objects.items.abstracts;

import ru.javabegin.training.android.money.activities.SelectValueActivity;
import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.items.interfaces.items.ListItem;
import android.content.Context;
import android.content.Intent;

// абстрактный класс для работы со справочными значениями
public abstract class AbstractSprItem implements ListItem{

	public static final String SELECTED_ITEM = "ru.javabegin.training.android.money.objects.spr.selectedItem";

	private static final long serialVersionUID = 1L;

	
	private boolean hasChilds;
	private boolean enable = true;// по-умолчанию элемент доступен
	
	private String tableName; // к какому типу справочника принадлежит
	// элемент (из spr_Metadata)
	
	
	protected AbstractSprItem() {
		// TODO Auto-generated constructor stub
	}
	

	protected AbstractSprItem getDefaultItem(){
		return AppContext.getDbAdapter().getDefaultOperTypeValue(this);
	}
	
	private ListItem selectedChildItem;
	
	private int id;// выбранный id
	private String name;// выбранное значение

	
	@Override
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	@Override
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}




	@Override
	public ListItem getSelectedChildItem() {
		return selectedChildItem;
	}

	public void setSelectedChildItem(ListItem selectedChildItem) {
		this.selectedChildItem = selectedChildItem;
	}
	

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
	@Override
	public boolean hasChilds(){
		return hasChilds;
	}
	
	public void setHasChilds(boolean hasChilds) {
		this.hasChilds = hasChilds;
	}
	
	@Override
	public boolean isEnable() {
		return enable;
	}
	
	public void setEnabled(boolean enable) {
		this.enable = enable;
	}
	
	
	@Override
	public Intent getIntent(Context context) {
		Intent intent = new Intent(context, SelectValueActivity.class);
		intent.putExtra(SELECTED_ITEM, this);
		return intent;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result
				+ ((tableName == null) ? 0 : tableName.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AbstractSprItem other = (AbstractSprItem) obj;
		if (id != other.id)
			return false;
		if (tableName == null) {
			if (other.tableName != null)
				return false;
		} else if (!tableName.equals(other.tableName))
			return false;
		return true;
	}

	

	
	

	

}
