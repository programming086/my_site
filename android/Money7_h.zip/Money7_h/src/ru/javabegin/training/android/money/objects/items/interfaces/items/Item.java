package ru.javabegin.training.android.money.objects.items.interfaces.items;

import java.io.Serializable;

import android.content.Context;
import android.content.Intent;

public interface Item extends Serializable{	
	
	Intent getIntent(Context context);	
	
	boolean isEnable();
	
}
