package ru.javabegin.training.android.money.objects.items.interfaces.listeners;

import ru.javabegin.training.android.money.objects.items.interfaces.items.ListItem;

public interface ItemSelectListener {
	void notifyItemSelected(ListItem selectedItem);
}
