package ru.javabegin.training.android.money.objects.items.interfaces.listeners;

import java.util.List;

import ru.javabegin.training.android.money.objects.items.interfaces.items.ListItem;

public interface ItemSelectNotifier {
	
	List<ItemSelectListener> getListeners();

    void addListener(ItemSelectListener listener);

    public void removeListener(ItemSelectListener listener);

    public void removeListeners();

    public void notifyListeners(ListItem selectedItem);

}
