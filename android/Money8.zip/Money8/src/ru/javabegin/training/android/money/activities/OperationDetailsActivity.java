package ru.javabegin.training.android.money.activities;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.adapters.SprNameAdapter;
import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.objects.items.impl.CurrencyItem;
import ru.javabegin.training.android.money.objects.items.impl.OperSourceItem;
import ru.javabegin.training.android.money.objects.items.impl.OperTypeItem;
import ru.javabegin.training.android.money.objects.items.impl.OperationItem;
import ru.javabegin.training.android.money.objects.items.impl.StorageItem;
import ru.javabegin.training.android.money.objects.items.interfaces.items.ListItem;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ListView;

// активити для создания/редактирования операции 
public class OperationDetailsActivity extends AnimationActivity {

	public static final String SPR_LIST = "ru.javabegin.training.android.money.activities.sprList";

	private LinkedHashMap<String, AbstractSprItem> sprMap = new LinkedHashMap<String, AbstractSprItem>(); // выбранные

	private ListView lvSpr;
	private ArrayList<ListItem> list = new ArrayList<ListItem>();
	private EditText txtAmount;

	private OperTypeItem operTypeItem = new OperTypeItem(true);
	private OperSourceItem operSourceItem = new OperSourceItem(operTypeItem);
	private CurrencyItem currencyItem = new CurrencyItem(true);
	private StorageItem storageItem = new StorageItem(true);

	private OperationItem operation;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_operation_details);

		txtAmount = (EditText) findViewById(R.id.txt_amount_input);

		lvSpr = (ListView) findViewById(R.id.list_metadata);

		sprMap.put(operTypeItem.getTableName(), operTypeItem);
		sprMap.put(operSourceItem.getTableName(), operSourceItem);
		sprMap.put(currencyItem.getTableName(), currencyItem);
		sprMap.put(storageItem.getTableName(), storageItem);

		list.add(operTypeItem);
		list.add(operSourceItem);
		list.add(currencyItem);
		list.add(storageItem);
		

		long id = getIntent().getLongExtra(AppContext.OPERATION_ID, 0);

		if (id > 0) { // режим редактирования операции
			operTypeItem.setSelectedChildItem(AppContext.getDbAdapter()
					.getOperTypeItem(id));
			operSourceItem.setSelectedChildItem(AppContext.getDbAdapter()
					.getOperSourceItem(id));
			currencyItem.setSelectedChildItem(AppContext.getDbAdapter()
					.getCurrencyItem(id));
			storageItem.setSelectedChildItem(AppContext.getDbAdapter()
					.getStorageItem(id));

			operation = AppContext.getDbAdapter().getOperationItem(id);
			
			txtAmount.setText(String.valueOf(operation.getAmount()));

		}

		operTypeItem.addListener(operSourceItem);
		lvSpr.setOnItemClickListener(new ListViewClickListener());
		lvSpr.setAdapter(new SprNameAdapter(this, list));

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.operation_details, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {

		case R.id.save:
			if (operation == null) {
				operation = new OperationItem();
			}
			operation.setAmount(Double.valueOf(txtAmount.getText().toString()));
			operation.setOperTypeItem(operTypeItem);
			operation.setOperSourceItem(operSourceItem);
			operation.setStorageItem(storageItem);
			operation.setCurrencyItem(currencyItem);
			operation.save();
			super.closeActivity();
			break;

		}

		return super.onOptionsItemSelected(item);
	}


	

	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);

		// если выбрано какое-то значение справочника
		if (intent.getExtras() != null && !intent.getExtras().isEmpty()) {

			AbstractSprItem selectedChildItem = (AbstractSprItem) intent
					.getSerializableExtra(AbstractSprItem.SELECTED_ITEM);

			AbstractSprItem parentItem = sprMap.get(selectedChildItem
					.getTableName());

			// если выбрали то же самое значение - ничего не делать
			if (parentItem.getSelectedChildItem() != null) {

				int selectedId = selectedChildItem.getId();

				int prevId = parentItem.getSelectedChildItem().getId();

				if (selectedId == prevId) {
					return;
				}

			}

			parentItem.setSelectedChildItem(selectedChildItem);

			((SprNameAdapter) lvSpr.getAdapter()).notifyDataSetChanged();

		}

	}

	private class ListViewClickListener implements OnItemClickListener {

		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {

			ListItem item = (ListItem) parent.getAdapter().getItem(position);
			startActivity(item.getIntent(OperationDetailsActivity.this));
			overridePendingTransition(R.anim.pull_in_right,
					R.anim.push_out_left);

		}

	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		super.onSaveInstanceState(outState);
		// outState.putSerializable(SPR_LIST, sprNamesMap);
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onRestoreInstanceState(savedInstanceState);
		// sprNamesMap = (LinkedHashMap<String, SprNameItem>)
		// savedInstanceState.get(SPR_LIST);
	}

}
