package ru.javabegin.training.android.money.adapters;

import java.util.ArrayList;

import ru.javabegin.training.android.money.objects.items.interfaces.items.ListItem;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.view.ViewGroup;

public class SprValueAdapter extends AbstractAdapter {

	private static final long serialVersionUID = 1L;

	public SprValueAdapter(Context context, ArrayList<ListItem> objects) {
		super(context, objects);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		convertView = getView(convertView, parent);

		ViewHolder holder = (ViewHolder) convertView.getTag();

		ListItem selectedValue = (ListItem) getItem(position);

		holder.txtSprName.setText(selectedValue.getName());

		if (selectedValue.hasChilds()) {
			holder.imageArrow.setVisibility(View.VISIBLE);
		} else {
			holder.imageArrow.setVisibility(View.INVISIBLE);
		}

		Bitmap bitmap = getImage(position);

		if (bitmap != null) {
			holder.image.setImageBitmap(bitmap);
		} else {
			holder.image.setImageBitmap(super.getNoIconImage());
		}

		return convertView;

	}
	
	private Bitmap getImage(int position) {
		int imageId = appContext.getResources().getIdentifier(
				getItem(position).getTableName().toLowerCase()
						+ getItem(position).getId(), "drawable",
				appContext.getPackageName());

	
		return BitmapFactory.decodeResource(appContext.getResources(), imageId);

	}

}
