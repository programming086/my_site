package ru.javabegin.training.android.money.objects.items.abstracts;

import java.util.ArrayList;
import java.util.List;

import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.items.interfaces.items.ListItem;
import ru.javabegin.training.android.money.objects.items.interfaces.listeners.ItemSelectListener;
import ru.javabegin.training.android.money.objects.items.interfaces.listeners.ItemSelectNotifier;

public abstract class AbstractSprItemNotifier extends AbstractSprItem implements ItemSelectNotifier{

	
	private static final long serialVersionUID = 1L;
	
	private List<ItemSelectListener> listeners = new ArrayList<ItemSelectListener>();



	@Override
	public List<ItemSelectListener> getListeners() {
		return listeners;
	}

	@Override
	public void addListener(ItemSelectListener listener) {
		listeners.add(listener);		
	}

	@Override
	public void removeListener(ItemSelectListener listener) {
		listeners.remove(listener);		
	}

	@Override
	public void removeListeners() {
		listeners.clear();
		
	}

	@Override
	public void notifyListeners(ListItem selectedItem) {
		for (ItemSelectListener listener : listeners) {
			listener.notifyItemSelected(selectedItem);
		}
		
	}

	
}
