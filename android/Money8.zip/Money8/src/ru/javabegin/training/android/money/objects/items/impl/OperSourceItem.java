package ru.javabegin.training.android.money.objects.items.impl;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.objects.items.interfaces.items.ListItem;
import ru.javabegin.training.android.money.objects.items.interfaces.listeners.ItemSelectListener;

public class OperSourceItem extends AbstractSprItem implements ItemSelectListener{
	
	private static final long serialVersionUID =  1L;
	
	private static final String TABLE_NAME = "spr_OperationSource";
	
	private OperTypeItem operTypeItem;
	
	public OperSourceItem(OperTypeItem operTypeItem) {
		this();
		this.operTypeItem = operTypeItem;		
	}
	
	
	
	public OperSourceItem() {
		setTableName(TABLE_NAME);
		setName(AppContext.getAppContext().getResources().getString(R.string.operation_source));	
	}
	
	
	
	public void setOperTypeItem(OperTypeItem operTypeItem) {
		this.operTypeItem = operTypeItem;
	}
	
	
	public OperTypeItem getOperTypeItem() {
		return operTypeItem;
	}


	@Override
	public ArrayList<ListItem> getList() {
		return  AppContext.getDbAdapter().getOperSourceList(this, operTypeItem);
	}
	
	@Override
	public boolean isEnable() {
		return operTypeItem.getSelectedChildItem()!=null;
	}



	@Override
	public void notifyItemSelected(ListItem selectedItem) {
		if (selectedItem instanceof OperTypeItem){
			setSelectedChildItem(null);
		}
		
	}
	

}
