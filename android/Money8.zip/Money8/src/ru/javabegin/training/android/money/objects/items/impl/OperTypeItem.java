package ru.javabegin.training.android.money.objects.items.impl;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.objects.AppContext;
import ru.javabegin.training.android.money.objects.items.abstracts.AbstractSprItemNotifier;
import ru.javabegin.training.android.money.objects.items.interfaces.items.ListItem;

public class OperTypeItem extends AbstractSprItemNotifier {
	
	private static final long serialVersionUID =  1L;
	
	public static final String TABLE_NAME = "spr_OperationType";
	
	public OperTypeItem() {
		setTableName(TABLE_NAME);
		setName(AppContext.getAppContext().getResources().getString(R.string.operation_type));
	}
	
	public OperTypeItem(boolean showDefaultItem) {
		this();
		if (showDefaultItem){
			setSelectedChildItem(super.getDefaultItem());
		}
	}
	
	
	@Override
	public ArrayList<ListItem> getList(){
		return AppContext.getDbAdapter().getOperTypeList(this);
	}
	
		
	
	
	@Override
	public void setSelectedChildItem(ListItem selectedChildItem) {
		super.setSelectedChildItem(selectedChildItem);
		
		notifyListeners(selectedChildItem);
	}
	
	
		
}
