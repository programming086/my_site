package ru.javabegin.training.android.money.objects.items.impl;

import ru.javabegin.training.android.money.objects.AppContext;

public class OperationItem {
	
	private int id;
	
	private OperTypeItem operTypeItem;
	private OperSourceItem operSourceItem;
	private StorageItem storageItem;
	private CurrencyItem currencyItem;
	
	private double amount;

	public OperTypeItem getOperTypeItem() {
		return operTypeItem;
	}

	public void setOperTypeItem(OperTypeItem operTypeItem) {
		this.operTypeItem = operTypeItem;
	}

	public OperSourceItem getOperSourceItem() {
		return operSourceItem;
	}

	public void setOperSourceItem(OperSourceItem operSourceItem) {
		this.operSourceItem = operSourceItem;
	}

	public StorageItem getStorageItem() {
		return storageItem;
	}

	public void setStorageItem(StorageItem storageItem) {
		this.storageItem = storageItem;
	}

	public CurrencyItem getCurrencyItem() {
		return currencyItem;
	}

	public void setCurrencyItem(CurrencyItem currencyItem) {
		this.currencyItem = currencyItem;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public boolean save() {
		return AppContext.getDbAdapter().saveOperation(this);	
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	

}
