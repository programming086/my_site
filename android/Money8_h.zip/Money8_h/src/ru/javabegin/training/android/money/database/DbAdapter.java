package ru.javabegin.training.android.money.database;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;

import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.objects.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.objects.items.impl.CurrencyItem;
import ru.javabegin.training.android.money.objects.items.impl.OperSourceItem;
import ru.javabegin.training.android.money.objects.items.impl.OperTypeItem;
import ru.javabegin.training.android.money.objects.items.impl.OperationItem;
import ru.javabegin.training.android.money.objects.items.impl.StorageItem;
import ru.javabegin.training.android.money.objects.items.interfaces.items.ListItem;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

public class DbAdapter {

	private static final String TAG = DbAdapter.class.getName();

	private DbHelper dbHelper;

	public static final String ALIAS_ID = "_id";
	public static final String ALIAS_AMOUNT = "amount";
	public static final String ALIAS_CURRENCY = "currency";
	public static final String ALIAS_OPERATION_DATETIME = "operationDateTime";
	public static final String ALIAS_SOURCE = "source";
	public static final String ALIAS_TYPE = "type";
	public static final String ALIAS_TYPE_ID = "type_id";
	public static final String ALIAS_SOURCE_ID = "sourceId";
	public static final String ALIAS_HAS_DISABLE_STATE = "hasDisableState";

	public static final String ALIAS_NAME = "itemName";
	public static final String ALIAS_SHORT_NAME = "itemShortName";
	public static final String ALIAS_HAS_CHILD = "hasChild";
	public static final String ALIAS_TABLE_NAME = "tableName";

	public static final String OPERATIONS_TABLE = "operations";
	public static final String STORAGE_TABLE = "spr_StorageType";
	public static final String OPER_TYPE_TABLE = "spr_OperationType";
	public static final String CURRENCY_TABLE = "spr_Currency";
	public static final String OPER_SOURCE_TABLE = "spr_OperationSource";

	public DbAdapter(Context context) {
		dbHelper = new DbHelper(context);
	}

	public SQLiteDatabase getDatabase() {
		return dbHelper.getReadableDatabase();
	}

	public void closeDatabase() {
		dbHelper.close();
	}

	public Cursor getOperations(OperationType type) {

		StringBuilder builder = new StringBuilder();
		SQLiteDatabase db = getDatabase();

		Cursor c = null;

		try {
			builder.append("select "
					+ "t.name as "
					+ ALIAS_TYPE
					+ ",s.type_id as "
					+ ALIAS_TYPE_ID
					+ ",o._id as "
					+ ALIAS_ID
					+ ",c.short_name as "
					+ ALIAS_CURRENCY
					+ ",o.[amount] as "
					+ ALIAS_AMOUNT
					+ ",o.[operation_datetime] as "
					+ ALIAS_OPERATION_DATETIME
					+ ",s.[name] as "
					+ ALIAS_SOURCE
					+ ",o.[source_id] as "
					+ ALIAS_SOURCE_ID
					+ " from operations o "
					+ " inner join spr_currency c on o.currency_id=c.[_id]  "
					+ " inner join spr_operationsource s on o.source_id=s.[_id] "
					+ " inner join spr_operationtype t on s.type_id=t.[_id] ");

			if (type != OperationType.ALL) {
				builder.append(" where o.type_id=?");
				c = db.rawQuery(builder.toString(),
						new String[] { String.valueOf(type.getId()) });
			} else {
				c = db.rawQuery(builder.toString(), null);
			}
			
			builder.append(" order by o.operation_datetime desc");

			Log.d(TAG, type.toString());
			Log.d(TAG, builder.toString());

		} catch (Exception e) {
			Log.e(TAG, e.getMessage());
		}

		return c;

	}

	public ArrayList<ListItem> getOperTypeList(ListItem item) {

		StringBuilder builder = new StringBuilder();
		ArrayList<ListItem> sprList = null;
		Cursor c = null;

		try {
			builder.append("select "
					+ " s1._id as "
					+ ALIAS_ID
					+ ", s1.name  as "
					+ ALIAS_NAME
					+ ", coalesce((select _id from "
					+ item.getTableName()
					+ " s2 where s2.parent_id=s1._id limit 1),0)  as  ALIAS_HAS_CHILD "
					+ " from " + item.getTableName()
					+ " s1 order by order_show");

			Log.d(TAG, builder.toString());

			SQLiteDatabase db = getDatabase();
			c = db.rawQuery(builder.toString(), null);

			sprList = new ArrayList<ListItem>();

			while (c.moveToNext()) {
				AbstractSprItem tmpItem = new OperTypeItem();
				tmpItem.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
				tmpItem.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));
				sprList.add(tmpItem);
			}

		} catch (Exception e) {
			Log.e(TAG, e.getMessage());
		} finally {
			if (c != null) {
				c.close();
			}
		}

		return sprList;
	}

	public OperTypeItem getOperTypeItem(long id) {

		StringBuilder builder = new StringBuilder();
		Cursor c = null;

		OperTypeItem item = null;

		try {

			builder.append("select "
					+ " op1._id as "
					+ ALIAS_ID
					+ ", op1.name  as "
					+ ALIAS_NAME
					+ ", coalesce((select _id from "
					+ OPER_TYPE_TABLE
					+ " c2 where c2.parent_id=op1._id limit 1),0)  as "
					+ ALIAS_HAS_CHILD
					+ " from "
					+ OPER_TYPE_TABLE
					+ " op1 "
					+ " where op1._id=(select type_id from operations o where o._id="
					+ id + ")");

			Log.d(TAG, builder.toString());

			SQLiteDatabase db = getDatabase();
			c = db.rawQuery(builder.toString(), null);

			c.moveToFirst();
			item = new OperTypeItem();
			item.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
			item.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));

			int hasChild = c.getInt(c.getColumnIndex(ALIAS_HAS_CHILD));

			if (hasChild > 0) {
				item.setHasChilds(true);
			} else {
				item.setHasChilds(false);
			}

		} catch (Exception e) {
			Log.e(TAG, e.getMessage());
		} finally {
			if (c != null) {
				c.close();
			}
		}

		return item;
	}

	public OperationItem getOperationItem(long id) {

		StringBuilder builder = new StringBuilder();
		Cursor c = null;

		OperationItem item = null;

		try {

			builder.append("select " + " o._id as " + ALIAS_ID
					+ ", o.amount  as " + ALIAS_AMOUNT + " from "
					+ OPERATIONS_TABLE + " o " + " where o._id=" + id);

			Log.d(TAG, builder.toString());

			SQLiteDatabase db = getDatabase();
			c = db.rawQuery(builder.toString(), null);

			c.moveToFirst();
			item = new OperationItem();
			item.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
			item.setAmount(c.getDouble(c.getColumnIndex(ALIAS_AMOUNT)));

		} catch (Exception e) {
			Log.e(TAG, e.getMessage());
		} finally {
			if (c != null) {
				c.close();
			}
		}

		return item;
	}

	public ArrayList<ListItem> getCurrencyList(CurrencyItem item) {

		StringBuilder builder = new StringBuilder();
		Cursor c = null;
		ArrayList<ListItem> sprList = null;

		try {

			builder.append("select " + " c1._id as " + ALIAS_ID
					+ ", c1.name  as " + ALIAS_NAME
					+ ", coalesce((select _id from " + item.getTableName()
					+ " c2 where c2.parent_id=c1._id limit 1),0)  as "
					+ ALIAS_HAS_CHILD + ", c1.short_name as "
					+ ALIAS_SHORT_NAME + " from " + item.getTableName()
					+ " c1 " + " where coalesce(c1.parent_id,0) = "
					+ item.getId() + " order by order_show");

			Log.d(TAG, builder.toString());

			SQLiteDatabase db = getDatabase();
			c = db.rawQuery(builder.toString(), null);

			sprList = new ArrayList<ListItem>();

			while (c.moveToNext()) {
				CurrencyItem tmpItem = new CurrencyItem();
				tmpItem.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
				tmpItem.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));
				tmpItem.setShortName(c.getString(c
						.getColumnIndex(ALIAS_SHORT_NAME)));

				int hasChild = c.getInt(c.getColumnIndex(ALIAS_HAS_CHILD));

				if (hasChild > 0) {
					tmpItem.setHasChilds(true);
				} else {
					tmpItem.setHasChilds(false);
				}

				sprList.add(tmpItem);
			}

		} catch (Exception e) {
			Log.e(TAG, e.getMessage());
		} finally {
			if (c != null) {
				c.close();
			}
		}

		return sprList;
	}

	public CurrencyItem getCurrencyItem(long id) {

		StringBuilder builder = new StringBuilder();
		Cursor c = null;

		CurrencyItem item = null;

		try {

			builder.append("select "
					+ " c1._id as "
					+ ALIAS_ID
					+ ", c1.name  as "
					+ ALIAS_NAME
					+ ", coalesce((select _id from "
					+ CURRENCY_TABLE
					+ " c2 where c2.parent_id=c1._id limit 1),0)  as "
					+ ALIAS_HAS_CHILD
					+ ", c1.short_name as "
					+ ALIAS_SHORT_NAME
					+ " from "
					+ CURRENCY_TABLE
					+ " c1 "
					+ " where c1._id=(select currency_id from operations o where o._id="
					+ id + ")");

			Log.d(TAG, builder.toString());

			SQLiteDatabase db = getDatabase();
			c = db.rawQuery(builder.toString(), null);

			c.moveToFirst();
			item = new CurrencyItem();
			item.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
			item.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));
			item.setShortName(c.getString(c.getColumnIndex(ALIAS_SHORT_NAME)));

			int hasChild = c.getInt(c.getColumnIndex(ALIAS_HAS_CHILD));

			if (hasChild > 0) {
				item.setHasChilds(true);
			} else {
				item.setHasChilds(false);
			}

			return item;

		} catch (Exception e) {
			Log.e(TAG, e.getMessage());
		} finally {
			if (c != null) {
				c.close();
			}
		}

		return item;
	}

	public ArrayList<ListItem> getStorageList(StorageItem item) {

		StringBuilder builder = new StringBuilder();
		Cursor c = null;
		ArrayList<ListItem> sprList = null;

		try {

			builder.append("select " + " c1._id as " + ALIAS_ID
					+ ", c1.name  as " + ALIAS_NAME
					+ ", coalesce((select _id from " + item.getTableName()
					+ " c2 where c2.parent_id=c1._id limit 1),0)  as "
					+ ALIAS_HAS_CHILD + " from " + item.getTableName() + " c1 "
					+ " where coalesce(c1.parent_id,0) = " + item.getId()
					+ " order by order_show");

			Log.d(TAG, builder.toString());

			SQLiteDatabase db = getDatabase();
			c = db.rawQuery(builder.toString(), null);

			sprList = new ArrayList<ListItem>();

			while (c.moveToNext()) {
				StorageItem tmpItem = new StorageItem();
				tmpItem.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
				tmpItem.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));

				int hasChild = c.getInt(c.getColumnIndex(ALIAS_HAS_CHILD));

				if (hasChild > 0) {
					tmpItem.setHasChilds(true);
				} else {
					tmpItem.setHasChilds(false);
				}

				sprList.add(tmpItem);
			}

		} catch (Exception e) {
			Log.e(TAG, e.getMessage());
		} finally {
			if (c != null) {
				c.close();
			}
		}

		return sprList;
	}

	public StorageItem getStorageItem(long id) {

		StringBuilder builder = new StringBuilder();
		Cursor c = null;

		StorageItem item = null;

		try {

			builder.append("select "
					+ " s1._id as "
					+ ALIAS_ID
					+ ", s1.name  as "
					+ ALIAS_NAME
					+ ", coalesce((select _id from "
					+ STORAGE_TABLE
					+ " c2 where c2.parent_id=s1._id limit 1),0)  as "
					+ ALIAS_HAS_CHILD
					+ " from "
					+ STORAGE_TABLE
					+ " s1 "
					+ " where s1._id=(select storage_id from operations o where o._id="
					+ id + ")");

			Log.d(TAG, builder.toString());

			SQLiteDatabase db = getDatabase();
			c = db.rawQuery(builder.toString(), null);

			c.moveToFirst();
			item = new StorageItem();
			item.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
			item.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));

			int hasChild = c.getInt(c.getColumnIndex(ALIAS_HAS_CHILD));

			if (hasChild > 0) {
				item.setHasChilds(true);
			} else {
				item.setHasChilds(false);
			}

			return item;

		} catch (Exception e) {
			Log.e(TAG, e.getMessage());
		} finally {
			if (c != null) {
				c.close();
			}
		}

		return item;
	}

	public ArrayList<ListItem> getOperSourceList(OperSourceItem item,
			OperTypeItem operTypeItem) {

		StringBuilder builder = new StringBuilder();
		Cursor c = null;
		ArrayList<ListItem> sprList = null;

		try {
			builder.append("select " + " s1._id as " + ALIAS_ID
					+ ", s1.name  as " + ALIAS_NAME
					+ ", coalesce((select _id from " + item.getTableName()
					+ " s2 where s2.parent_id=s1._id limit 1),0)  as "
					+ ALIAS_HAS_CHILD + " from " + item.getTableName() + " s1 "
					+ " where type_id="
					+ operTypeItem.getSelectedChildItem().getId());

			builder.append(" and coalesce(s1.parent_id,0) = " + item.getId());

			Log.d(TAG, builder.toString());

			SQLiteDatabase db = getDatabase();
			c = db.rawQuery(builder.toString(), null);

			sprList = new ArrayList<ListItem>();

			while (c.moveToNext()) {
				AbstractSprItem tmpItem = new OperSourceItem(operTypeItem);
				tmpItem.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
				tmpItem.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));

				int hasChild = c.getInt(c.getColumnIndex(ALIAS_HAS_CHILD));

				if (hasChild > 0) {
					tmpItem.setHasChilds(true);
				} else {
					tmpItem.setHasChilds(false);
				}

				sprList.add(tmpItem);
			}

		} catch (Exception e) {
			Log.e(TAG, e.getMessage());
		} finally {
			if (c != null) {
				c.close();
			}
		}

		return sprList;
	}

	public OperSourceItem getOperSourceItem(long id) {

		StringBuilder builder = new StringBuilder();
		Cursor c = null;
		OperSourceItem item = null;

		try {
			builder.append("select "
					+ " s1._id as "
					+ ALIAS_ID
					+ ", s1.name  as "
					+ ALIAS_NAME
					+ ", coalesce((select _id from "
					+ OPER_SOURCE_TABLE
					+ " s2 where s2.parent_id=s1._id limit 1),0)  as "
					+ ALIAS_HAS_CHILD
					+ " from "
					+ OPER_SOURCE_TABLE
					+ " s1 "
					+ " where s1._id=(select source_id from operations o where o._id="
					+ id + ")");

			Log.d(TAG, builder.toString());

			SQLiteDatabase db = getDatabase();
			c = db.rawQuery(builder.toString(), null);

			c.moveToFirst();
			item = new OperSourceItem();
			item.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
			item.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));

			int hasChild = c.getInt(c.getColumnIndex(ALIAS_HAS_CHILD));

			if (hasChild > 0) {
				item.setHasChilds(true);
			} else {
				item.setHasChilds(false);
			}

		} catch (Exception e) {
			Log.e(TAG, e.getMessage());
		} finally {
			if (c != null) {
				c.close();
			}
		}

		return item;
	}

	public OperTypeItem getDefaultOperTypeValue(ListItem item) {

		StringBuilder builder = new StringBuilder();
		Cursor c = null;
		OperTypeItem tmpItem = null;
		SQLiteStatement stmt = null;

		try {

			builder.append("select " + " s1._id as " + ALIAS_ID
					+ ", s1.name  as " + ALIAS_NAME + " from "
					+ item.getTableName()
					+ " s1 order by order_show asc limit 0,1 ");

			Log.d(TAG, builder.toString());
			SQLiteDatabase db = getDatabase();

			c = db.rawQuery(builder.toString(), null);

			while (c.moveToNext()) {
				tmpItem = new OperTypeItem();
				tmpItem.setId(c.getInt(c.getColumnIndex(ALIAS_ID)));
				tmpItem.setName(c.getString(c.getColumnIndex(ALIAS_NAME)));

			}

		} catch (Exception e) {
			Log.e(TAG, e.getMessage());
		} finally {
			if (c != null) {
				c.close();
			}
		}

		return tmpItem;
	}

	public boolean saveOperation(OperationItem operation) {
		SQLiteStatement stmt = null;
		try {
			SQLiteDatabase db = getDatabase();

			if (operation.getId() > 0) {// режим редактирования
				stmt = db
						.compileStatement("update operations set operation_datetime=?, amount=?, currency_id=?, source_id=?, storage_id=?, type_id=? where _id="
								+ operation.getId());
			} else {
				stmt = db
						.compileStatement("insert into operations (operation_datetime, amount, currency_id, source_id, storage_id, type_id) values (?,?,?,?,?,?)");
			}

			stmt.bindLong(1, new Date().getTime());
			stmt.bindDouble(2, operation.getAmount());
			stmt.bindLong(3, operation.getCurrencyItem().getSelectedChildItem()
					.getId());
			stmt.bindLong(4, operation.getOperSourceItem()
					.getSelectedChildItem().getId());
			stmt.bindLong(5, operation.getStorageItem().getSelectedChildItem()
					.getId());
			stmt.bindLong(6, operation.getOperTypeItem().getSelectedChildItem()
					.getId());

			stmt.execute();

			return true;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			stmt.close();
		}

		return false;
	}

	private static class DbHelper extends SQLiteOpenHelper {

		public static final String DB_NAME = "money.db";
		public static final int DB_VERSION = 1;

		private String dbPath;
		private Context context;

		public DbHelper(Context context) {
			super(context, DB_NAME, null, DB_VERSION);

			dbPath = context.getApplicationInfo().dataDir + "/" + "databases/"
					+ DB_NAME;
			this.context = context;
			if (checkDataBaseExists()) {
				copyDataBase();
			}

		}

		@Override
		public void onCreate(SQLiteDatabase db) {

		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

		}

		private boolean checkDataBaseExists() {
			File dbFile = new File(dbPath);
			return dbFile.exists();
		}

		private void copyDataBase() {
			InputStream myInput = null;
			OutputStream myOutput = null;
			try {
				myInput = context.getAssets().open(DB_NAME);
				myOutput = new FileOutputStream(dbPath);
				byte[] buffer = new byte[1024];
				int length;
				while ((length = myInput.read(buffer)) > 0) {
					myOutput.write(buffer, 0, length);
				}

			} catch (Exception e) {
				Log.e(TAG, e.getMessage());
			} finally {
				try {
					myOutput.flush();
					myOutput.close();
					myInput.close();
				} catch (IOException e) {
					Log.e(TAG, e.getMessage());
				}
			}

		}
	}

	public boolean deleteOperation(int id) {
		SQLiteStatement stmt = null;
		try {
			SQLiteDatabase db = getDatabase();

			stmt = db.compileStatement("delete from operations where _id=?");

			stmt.bindLong(1, id);
			stmt.execute();

			return true;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			stmt.close();
		}

		return false;

	}

}
