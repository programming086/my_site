package ru.javabegin.training.android.money.fragments;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.activities.OperationDetailsActivity;
import ru.javabegin.training.android.money.adapters.SprValueAdapter;
import ru.javabegin.training.android.money.objects.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.objects.items.interfaces.items.ListItem;
import android.app.ListFragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

// список всех общих справочников (для каждого из них пользователь будет выбирать значение)
public class SprListFragment extends ListFragment {
	
	private Intent intentOperDetailsActivity;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		intentOperDetailsActivity = new Intent(getActivity(), OperationDetailsActivity.class);
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);

		ListItem item = (ListItem) getArguments().getSerializable(AbstractSprItem.SELECTED_ITEM);

		if (item != null) {
			setListAdapter(new SprValueAdapter(getActivity(), item.getList()));
		}

	}

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {

		ListItem item = ((ListItem) l.getAdapter().getItem(position));		

		if (item.hasChilds()) {

			// если у справочного знаения есть дочерние пункты - открываем их
			startActivity(item.getIntent(getActivity()));
			getActivity().overridePendingTransition(R.anim.pull_in_right, R.anim.push_out_left);
			
		}else{ 
//			intentOperationDetails.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			intentOperDetailsActivity.putExtra(AbstractSprItem.SELECTED_ITEM, item);			
			startActivity(intentOperDetailsActivity);
			getActivity().overridePendingTransition(R.anim.pull_in_left, R.anim.push_out_right);
			
			
		}
	
	}


}
