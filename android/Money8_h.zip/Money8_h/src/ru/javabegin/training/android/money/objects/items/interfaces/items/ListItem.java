package ru.javabegin.training.android.money.objects.items.interfaces.items;

import java.util.ArrayList;

public interface ListItem extends Item{
	
	ArrayList<ListItem> getList();

	boolean hasChilds();
	
	String getTableName();

	ListItem getSelectedChildItem();
	
	int getId();
	
	String getName();
	
}
