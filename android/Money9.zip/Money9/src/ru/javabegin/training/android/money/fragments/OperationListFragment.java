package ru.javabegin.training.android.money.fragments;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.activities.OperationDetailsActivity;
import ru.javabegin.training.android.money.activities.OperationListActivity;
import ru.javabegin.training.android.money.adapters.OperationsAdapter;
import ru.javabegin.training.android.money.enums.OperationType;
import ru.javabegin.training.android.money.gui.MenuExpandableList;
import ru.javabegin.training.android.money.objects.AppContext;
import android.app.ListFragment;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

// отображает список операций
public class OperationListFragment extends ListFragment {

	// private OperationType operationType;
	private Intent operDetailsIntent;
	
	private OperationType operType;
	

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		operDetailsIntent = new Intent(getActivity(), OperationDetailsActivity.class);

	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onActivityCreated(savedInstanceState);

		operType = (OperationType) getArguments().getSerializable(MenuExpandableList.OPERATION_TYPE);

		cursor = AppContext.getDbAdapter().getOperations(operType);
		OperationsAdapter operationsAdapter = new OperationsAdapter(getActivity(), cursor, false);
		setListAdapter(operationsAdapter);
	}

	private Cursor cursor;

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		cursor.close();
	}

	@Override
	public void onListItemClick(ListView l, View v, int position, long id) {
		// TODO Auto-generated method stub
		super.onListItemClick(l, v, position, id);

		operDetailsIntent.putExtra(AppContext.OPERATION_ID, (int)id);
		getActivity().startActivity(operDetailsIntent);
		getActivity().overridePendingTransition(R.anim.pull_in_right,
				R.anim.push_out_left);
	}

	
	@Override
	public void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		
		cursor = AppContext.getDbAdapter().getOperations(operType);
		((OperationsAdapter)getListAdapter()).changeCursor(cursor);
	}



}
