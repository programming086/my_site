package ru.javabegin.training.android.money.database.abstracts.impls;

import java.util.Calendar;

import ru.javabegin.training.android.money.database.abstracts.AbstractSprListItem;
import ru.javabegin.training.android.money.listview.items.interfaces.impls.DateTimeItem;
import android.database.Cursor;

public class DateTimeDbItem extends AbstractSprListItem<DateTimeItem> {
	

	@Override
	protected String getSql(long id) {
		StringBuilder builder = new StringBuilder();
		builder.append("select operation_datetime as "+ALIAS_DATETIME+" from "+OPERATIONS_TABLE+" where _id="+id);
		return builder.toString();
	}

	

	protected DateTimeItem fillItem(Cursor c) {		
		Calendar calendar = Calendar.getInstance();
		DateTimeItem item = new DateTimeItem();
		calendar.setTimeInMillis(c.getLong(c.getColumnIndex(ALIAS_DATETIME)));
		item.setCalendar(calendar);
		return item;
	}




}
