package ru.javabegin.training.android.money.listview.adapters;

import java.util.ArrayList;

import ru.javabegin.training.android.money.listview.items.interfaces.Item;
import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;

public class ItemAdapter extends AbstractAdapter<Item> {

	private static final long serialVersionUID = 1L;

	public ItemAdapter(Context context, ArrayList<Item> objects) {
		super(context, objects);
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		convertView = getView(convertView, parent);

		ViewHolder holder = (ViewHolder) convertView.getTag();

		Item item = (Item) getItem(position);
			
		if (item.getSelectedText() != null) {
			holder.txtSprName.setText(item.getShortText());
			holder.txtSprName.setTextColor(Color.BLACK);
		}else{
			holder.txtSprName.setText(item.getTitleText());
			holder.txtSprName.setTextColor(Color.GRAY);
		}

		holder.image.setImageBitmap(item.getImage());

		return convertView;
	}

	@Override
	public boolean isEnabled(int position) {
		return getItem(position).isEnable();
	}

}
