package ru.javabegin.training.android.money.listview.items.interfaces.impls;

import java.util.ArrayList;

import ru.javabegin.training.android.money.R;
import ru.javabegin.training.android.money.database.abstracts.impls.DbItemCreator;
import ru.javabegin.training.android.money.listview.items.abstracts.AbstractSprItem;
import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;
import ru.javabegin.training.android.money.listview.items.listeners.ItemSelectListener;
import ru.javabegin.training.android.money.objects.AppContext;

public class OperSourceItem extends AbstractSprItem implements ItemSelectListener{
	
	private static final long serialVersionUID =  1L;
	
	private static final String TABLE_NAME = "spr_OperationSource";
	
	private static OperTypeItem operTypeItem;
	
	public OperSourceItem(OperTypeItem operType) {
		this();
		operTypeItem = operType;		
	}
	
	
	
	public OperSourceItem() {
		setTableName(TABLE_NAME);
		setName(AppContext.getInstance().getResources().getString(R.string.operation_source));	
	}
	
	
	
	public OperTypeItem getOperTypeItem() {
		return operTypeItem;
	}


	@Override
	public ArrayList<ListItem> getList() {
		return  new ArrayList<ListItem>(DbItemCreator.getOperSourceDbItem().getListItems(this));
	}
	
	@Override
	public boolean isEnable() {
		return operTypeItem.getSelectedChildItem()!=null;
	}



	@Override
	public void notifyItemSelected(ListItem selectedItem) {
		if (selectedItem instanceof OperTypeItem){
			setSelectedChildItem(null);
		}
		
	}
	
}
