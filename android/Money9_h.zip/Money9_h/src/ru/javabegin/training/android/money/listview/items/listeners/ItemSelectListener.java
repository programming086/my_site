package ru.javabegin.training.android.money.listview.items.listeners;

import ru.javabegin.training.android.money.listview.items.interfaces.ListItem;

public interface ItemSelectListener {
	void notifyItemSelected(ListItem selectedItem);
}
