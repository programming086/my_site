using System;

namespace MyPhotoshop
{
	public class Photo
	{
		public int width;
		public int height;
		public double[,,] data;
	}
}

