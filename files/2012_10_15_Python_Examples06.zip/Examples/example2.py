# coding=utf-8
__author__ = 'ktisha'

from example1 import my_shiny_new_decorator


@my_shiny_new_decorator
def another_stand_alone_function():
    print "Оставь меня в покое"

another_stand_alone_function()
#выведет:
# Я - код, который отработает до вызова функции
# Оставь меня в покое
# А я - код, срабатывающий после