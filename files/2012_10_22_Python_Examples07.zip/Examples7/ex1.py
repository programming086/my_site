__author__ = 'ktisha'

def foo(): pass

foo.__class__
#<type 'function'>

foo.__dict__
#{}

(42).__dict__
#Traceback (most recent call last):
#File "<stdin>", line 1, in <module>
#AttributeError: 'int' object has no attribute '__dict__'

(42).__class__
#<type 'int'>

class A(object):
    qux = 'A'
    def __init__(self, name):
        self.name = name

    def foo(self):
        print 'foo'

a = A('a')

a.__dict__
#{'name': 'a'}
a.__class__
#<class '__main__.A'>
type(a)
#<class '__main__.A'>
a.__class__ is type(a)
#True

# self.foo = bar  == self.__dict__['foo'] = bar