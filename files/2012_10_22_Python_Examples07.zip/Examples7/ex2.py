__author__ = 'ktisha'

from ex1 import A

class B(object):
    qux = 'B'
    def __init__(self):
        self.name = 'B object'

    def bar(self):
        print 'bar'


a = A("name")
a.__dict__
#{'name': 'a'}
a.foo()
#foo
a.__class__
#<class '__main__.A'>
a.__class__ = B
a.__class__
#<class '__main__.B'>

a.__dict__
#{'name': 'a'}

a.foo()
#Traceback (most recent call last):
#File "<stdin>", line 1, in <module>
#AttributeError: 'B' object has no attribute 'foo'

a.bar()
#bar
a.qux
#'B'

delattr(a, 'qux')
#Traceback (most recent call last):
#File "<stdin>", line 1, in <module>
#AttributeError: qux
del a.qux
#Traceback (most recent call last):
#File "<stdin>", line 1, in <module>
#AttributeError: qux
a.qux
#'B'

b = B()
b.qux
#'B'
b.qux = 'myB'
b.qux
#'myB'
b.__dict__
#{'qux': 'myB', 'name': 'a'}
b.qux
#'B'

del b.qux

b.qux
#'B'
b.__dict__
#{'name': 'a'}