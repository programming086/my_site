__author__ = 'ktisha'

class A(object):
    def __new__(cls):
        obj = super(A, cls).__new__(cls)
        print 'created object', obj
        return obj
    def __init__(self):
        print 'initing object', self

A()
#created object <__main__.A object at 0x1620ed0>
#initing object <__main__.A object at 0x1620ed0>
#<__main__.A object at 0x1620ed0>


class C(object):
    instance = None
    def __new__(cls):
        if cls.instance is None:
            cls.instance = super(C, cls).__new__(cls)
        return cls.instance

C() is C()
#True
C().x = 1
c = C()
d = C()
c.x
#1
d.x
#1
c.x=2
d.x
#2
c.x
#2
