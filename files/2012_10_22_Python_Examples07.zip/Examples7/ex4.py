__author__ = 'ktisha'

class Ameta(type):
    def foo(cls):
        print 'Ameta.foo'

class A(object):
    __metaclass__ = Ameta

A.foo()
#Ameta.foo


a = A()
a.foo
#Traceback (most recent call last):
#File "<stdin>", line 1, in <module>
#AttributeError: 'A' object has no attribute 'foo'




class Meta(type):
    def __new__(mcls, name, bases, attrs):
        print 'creating new class', name
        return super(Meta, mcls).__new__(mcls, name, bases, attrs)
    def __init__(cls, name, bases, attrs):
        print 'initing new class', name


class A(object):
    __metaclass__ = Meta

#creating new class A
#initing new class A

a = A()