__author__ = 'ktisha'

with open('test1.txt', 'w') as file_out:
    for i in xrange(1000000):
        print >> file_out, 1

# 0.35 sec