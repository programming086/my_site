__author__ = 'ktisha'

from threading import Thread

def writer(filename, n):
    with open(filename, 'w') as file_out:
        for i in xrange(n):
            print >> file_out, 1

t1 = Thread(target=writer, args=('test2.txt', 500000,))
t2 = Thread(target=writer, args=('test3.txt', 500000,))

t1.start()
t2.start()
t1.join()
t2.join()

# 0.7 sec