__author__ = 'ktisha'
import sys

word = sys.stdin.readline().rstrip()
filename = sys.stdin.readline().rstrip()

try:
    with open(filename, "rb") as fh:
        line_number = 1
        while True:
            current = fh.readline()
            if not current:
                break
            if word in current:
                print("found: {0} {1} on line {2}".format(filename,word, line_number))
            line_number += 1
except IOError:
    pass