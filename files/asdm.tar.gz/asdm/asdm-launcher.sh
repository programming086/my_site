#!/bin/sh
# Evoke ASDM-IDM Launcher on *NIX-based systems.
# Copyright (c) 2009 Cisco Systems, Inc.
# All rights reserved.
DIRNAME=`dirname "$0"`
cd "${DIRNAME}"
case "`uname`" in
    CYGWIN*)
	s=';'
	;;
    *)
	s=':'
	;;
esac

pwd

exec java -Xms64m -Xmx512m -XX:MaxNewSize=1024k \
 -Dsun.swing.enableImprovedDragGesture=true \
 -Dapple.laf.useScreenMenuBar=true \
 -Dapple.awt.graphics.UseQuartz=true \
 -classpath \
  lzma.jar${s}jploader.jar${s}asdm-launcher.jar${s}retroweaver-rt-2.0.jar \
 com.cisco.launcher.Launcher
