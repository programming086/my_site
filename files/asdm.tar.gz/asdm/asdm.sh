#!/bin/bash
ASDMLIB=/home/brovko_rs/bin/asdm/
java -classpath \
  ${ASDMLIB}lzma.jar:${ASDMLIB}jploader.jar:${ASDMLIB}asdm-launcher.jar:${ASDMLIB}retroweaver-rt-2.0.jar \
  -Xms64m -Xmx256m -XX:MaxNewSize=1024k \
  -Dsun.swing.enableImprovedDragGesture=true \
  -Dapple.laf.useScreenMenuBar=true \
  -Dapple.awt.graphics.UseQuartz=true \
  com.cisco.launcher.Launcher $*