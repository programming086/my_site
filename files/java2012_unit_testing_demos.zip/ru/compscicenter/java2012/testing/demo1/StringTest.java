package ru.compscicenter.java2012.testing.demo1;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class StringTest {

    @Test
    public void substring_should_count_chars_from_0() {
        assertEquals("lo", "Hello".substring(3));
    }


    @Test(expected = StringIndexOutOfBoundsException.class)
    public void substring_should_throw_exception_for_invalid_index() {
        "".substring(1);
    }


    @Test(timeout = 1000L)
    public void should_work_in_less_than_1_second() throws Exception {
        Thread.sleep(2000L);
    }
}
