package ru.compscicenter.java2012.testing.demo4;

import java.util.logging.Logger;

public class ClassA {

    private static final Logger LOGGER = Logger.getLogger(ClassA.class.getName());

    public void doSomething() {
        LOGGER.info("Hello from ClassA");
    }

}
