package ru.compscicenter.java2012.testing.demo4;

public class LoggingDemo {

    public static void main(String[] args) throws Exception {

//        Logger logger = Logger.getLogger("ru.compscicenter.java2012.testing");
//        logger.setLevel(Level.INFO);
//        logger.addHandler(new FileHandler("/tmp/demologger.txt"));

        new ClassA().doSomething();
        new ClassB().doSomethingElse();
    }
}
