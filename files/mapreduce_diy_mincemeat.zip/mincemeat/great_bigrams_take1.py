#!/usr/bin/env python 
import mincemeat
import sys
import great_bigrams

def mapfn(k, v):
    counts = great_bigrams.do_map(v)
    for key, value in counts.items():
        yield key, value

def reducefn(k, vs):
    result = sum(vs)
    return result

s = mincemeat.Server() 

s.map_input = mincemeat.FileMapInputLineByLine(sys.argv[1]) 
s.mapfn = mapfn
s.reducefn = reducefn

results = s.run_server(password="changeme") 
for key, value in sorted(results.items()):
    print "%s: %s" % (key, value) 
