#!/bin/bash
python mincemeat.py -p changeme localhost & 
#python mincemeat.py -p changeme localhost &
#python mincemeat.py -p changeme localhost &
#python mincemeat.py -p changeme localhost &
#python mincemeat.py -p changeme localhost &
#python mincemeat.py -p changeme localhost &
