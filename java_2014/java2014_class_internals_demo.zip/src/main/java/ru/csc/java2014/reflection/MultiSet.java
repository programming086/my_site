package ru.csc.java2014.reflection;

import java.util.Collection;

public interface MultiSet<E> extends Collection<E> {

    // fancy MultiSet-specific methods here
}
