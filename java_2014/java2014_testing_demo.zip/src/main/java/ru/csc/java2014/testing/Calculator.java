package ru.csc.java2014.testing;

public interface Calculator {

    public double calculate(String expression);
}
