package calc;

public class TestObject {
    
    private String name;

    public TestObject(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
    
    

}
