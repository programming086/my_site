package ru.javabegin.training.web.enums;

public enum SearchType {

    AUTHOR,
    TITLE
}
