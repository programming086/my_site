package main;

import asus.AsusModel1;
import asus.AsusModel2;
import java.io.File;
import objects.Computer;
import printer.PaperFormat;
import printer.Printer;
import toshiba.Toshiba;
import toshiba.ToshibaModel1;

public class StartProgram {

    public static void main(String[] args) {

        AsusModel1 asusModel1 = new AsusModel1("AsusModel1");
//        AsusModel2 asusModel2 = new AsusModel2("AsusModel2");
//        ToshibaModel1 toshibaModel1 = new ToshibaModel1("ToshibaModel1");


//        System.out.println(asusModel1);
//        
//        System.out.println("before: " + asusModel1.getName());
//
//        method1(asusModel1);
//        
//        System.out.println(asusModel1);
//
//        System.out.println("after: " + asusModel1.getName());

        

        int i = 1;
        System.out.println("before:in main i=" + i);
        method2(i);
        System.out.println("after:in main i=" + i);



    }

    private static void method1(Computer comp) {
        comp.setName("Changed name");
        comp = new ToshibaModel1("Tosh1");
        
    }

    private static void method2(int i) {
        i += 10;
        System.out.println("in method i=" + i);
    }

    private static void method1WithFinal(final Computer comp) {
        
        // ошибка компиляции
//        comp.setName("Changed name");
//        comp = new ToshibaModel1("Tosh1");


    }

    private static void method2WithFinal(final int i) {
        // ошибка компиляции
        
//        i += 10;
//        System.out.println("in method i=" + i);
    }

    
    
    
    // дополнительное задание к 6 уроку: печать принтера на заданных форматах бумаги
    private static void testPrinter() {
        Printer printer = new Printer();
        printer.printPaperTypes();// распечатать все форматы бумаги, которые существуют

        printer.print(PaperFormat.A5, "1111111111111111");
        printer.print(PaperFormat.A4, "000000000000000000000");
        printer.print(PaperFormat.A3, "4555");
    }
}
