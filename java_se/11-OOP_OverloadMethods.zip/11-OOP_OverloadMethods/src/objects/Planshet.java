package objects;

import java.io.File;

public abstract class Planshet extends Computer {

    private RetinaScreen screen;
    private Camera camera;
    private static final int MODE_NORMAL = 0;
    private static final int MODE_SAFE = 1;

    public Planshet(String name) {
        super(name);
    }

    public Planshet(String name, double weight) {
        super(name, weight);
    }

    public abstract void navigateByScreen();

    // реализация для всех планшентов
    @Override
    public void on() {
        print("Planshet on");
    }

    @Override
    public void off() {
        print("Planshet off");
    }

    @Override
    public void load() {
        print("Planshet load");
    }

    public Camera getCamera() {
        if (camera == null) {
            camera = new Camera();
        }
        return camera;
    }

    public RetinaScreen getScreen() {
        if (screen == null) {
            screen = new RetinaScreen();
        }
        return screen;
    }

    // перегруженные методы
    public void load(int mode) {
        if (mode == MODE_SAFE) {
            print("do something in safe mode...");
        } else {
            load();
        }


    }

    public void on(String helloMessage) {
        print(helloMessage);
        on();        
    }

    public void off(String message) {
        print(message);
        off();
    }
}
