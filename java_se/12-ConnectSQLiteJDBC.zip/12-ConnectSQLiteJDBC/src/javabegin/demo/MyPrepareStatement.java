package javabegin.demo;


public class MyPrepareStatement {
    
    public static void main(String[] args) {
        
    }

}
