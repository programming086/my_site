package objects;

public class Bus {

    public int number;
    public String model;

    public void drive() {
        System.out.println("Bus number " + number + " drive!");
    }

    public void stop() {
        System.out.println("Bus stop!");
    }

    public void beep() {
        System.out.println("Bus beep!");
    }

}
