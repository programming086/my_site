package start;

import objects.Bus;
import objects.Dog;

public class Main {

    public static void main(String[] args) {
        Dog dog1 = new Dog();
        dog1.name = "Lessi";
        dog1.bark();

        Bus bus1 = new Bus();
        bus1.number = 100;
        bus1.drive();

    }
}
