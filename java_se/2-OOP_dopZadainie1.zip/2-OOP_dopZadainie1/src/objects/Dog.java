package objects;


public class Dog {
    
    public String name;
    public String poroda;
    
    public void run(){
        System.out.println("dog "+poroda+" running!");
    }
    
    public void bark(){
        System.out.println("dog "+name+" is barking!");
    }

}
