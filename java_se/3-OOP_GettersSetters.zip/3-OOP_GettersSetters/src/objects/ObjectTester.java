package objects;

public class ObjectTester {
    public static void main(String[] args) {
        Computer comp = new Computer();
        
        // различные варианты присваивания
        comp.setName("test name");// можно
        comp.setName(null);// нельзя!
        comp.setName("");// нельзя!
        comp.setHdd(2048);// можно
        comp.setHdd(-2048);// нельзя!
        
        comp.on();
        comp.load();
        comp.off();
        
        comp.setFactoryNumber("");
        
        System.out.println(comp.getFactoryNumber());
        
    }

}
