package objects;

public class ObjectTester {
    
    public static void main(String[] args) {
        
        // задание 5 *
        // обмен объектов местами
        Computer comp1 = new Computer("comp1");
        Computer comp2 = new Computer("comp2");
        
        System.out.println("comp1 name = "+comp1.getName());
        System.out.println("comp2 name = "+comp2.getName());
        
        Computer tmpComp;
        
        tmpComp = comp1;
        
        comp1 = comp2;
        
        comp2 = tmpComp;
        
        System.out.println("comp1 name = "+comp1.getName());
        System.out.println("comp2 name = "+comp2.getName());
        
        tmpComp = null;
        
        
    }

}
