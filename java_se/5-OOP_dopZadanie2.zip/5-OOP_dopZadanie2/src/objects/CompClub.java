package objects;

import java.util.Scanner;
import objects.Computer;

public class CompClub {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Введите количество компьютеров: ");
        int compCount = scanner.nextInt();

        Computer[] userComps = new Computer[compCount];

        System.out.println("В зале расположено " + userComps.length + " компьютеров:");

//        создание пользовательских компьютеров
        for (int i = 0; i < compCount; i++) {
            userComps[i] = new Computer("Computer_" + i, false);// false - не админские компы
            System.out.println(userComps[i].getName());
        }

        System.out.println("--------------");
        
        if (userComps.length==0){
            System.out.println("Нет ни одного компьютера!");
            return;
        }

        Computer adminComp = new Computer("Admin comp", true);// true - админский комп

        adminComp.setUserComps(userComps);

        userComps[0].rebootUserComps();// нет разрешения, т.к. комп не админский

        adminComp.switchOnUserComps();
        adminComp.rebootUserComps();
        
        userComps[0].setStatus("running");
        
        adminComp.shutdownUserComps();

    }
}
