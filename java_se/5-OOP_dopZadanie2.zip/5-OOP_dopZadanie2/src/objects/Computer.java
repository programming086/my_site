package objects;


public class Computer {

    // свойства объекта Computer
    private String name;
    private int ram;
    private int hdd;
    private double weight;
    private boolean cdReadable;// может ли считывать диск
    
    private Computer[] userComps;// массив всех созданных компьютеров
    private boolean adminComp;// указатель, является ли текущий компьютер админским
    private String status = "nothing";// текущее состояние комп-ра
    
    // конструктор без параметров
    public Computer() {
        on();
    }

    public Computer(String name) {
        this.name = name;
    }

    public Computer(String name, boolean adminComp) {
        this.name = name;
        this.adminComp = adminComp;
    }

    public Computer(int ram) {
        this.ram = ram;
    }

    // нельзя создавать!! т.к. с таким типом параметра есть уже конструктор
//    public Computer(int hdd){
//        this.hdd = hdd;
//    }
    public Computer(double weight) {
        this.weight = weight;
    }

    public Computer(boolean cdReadable) {
        this.cdReadable = cdReadable;
    }

    public Computer(String name, int ram, int hdd, double weight, boolean cdReadable, boolean adminComp) {
        this.name = name;
        this.ram = ram;
        this.hdd = hdd;
        this.weight = weight;
        this.cdReadable = cdReadable;
        this.adminComp = adminComp;
        on();
    }

    // сервис методы
    public void on() {
        print(name + ": включение");

    }

    public void off() {
        if (!status.equals("running")) {
            print(name + ": выключение");
        } else {
            print(name + ": невозможно выключить, есть незавершенные задачи!");
        }
    }

    public void load() {
        print("я загружаюсь. Мой объем жесткого диска равен: " + getHdd() + " Гб");
    }

    public void reboot() {
        print(name + ": перезагрузка");
    }

    public void readCD() {
        if (cdReadable) {
            print("Считываю диск");
        } else {
            print("Не могу считать диск, устройство не поддерживается!");
        }
    }

    public void rebootUserComps() {
        if (!adminComp) {
            System.out.println("У компьютера " + name + " нет прав на перезагрузку! Это не админский компьютер!");
            return;
        }

        for (int i = 0; i < userComps.length; i++) {
            userComps[i].reboot();
        }

        System.out.println();

    }

    public void shutdownUserComps() {
        if (!adminComp) {
            System.out.println("У компьютера " + name + " нет прав на выключение! Это не админский компьютер!");
            return;
        }

        for (int i = 0; i < userComps.length; i++) {
            userComps[i].off();
        }

        System.out.println();
    }

    public void switchOnUserComps() {
        if (!adminComp) {
            System.out.println("У компьютера " + name + " нет прав на включение! Это не админский компьютер!");
            return;
        }

        for (int i = 0; i < userComps.length; i++) {
            userComps[i].on();
        }

        System.out.println();
    }

    private void print(String str) {
        System.out.println(str);
    }

    // гетеры и сетеры для свойств с проверками передаваемыз значений
    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != null && !name.equals("")) {// если переданное имя не пустое и не null
            this.name = name;
        } else {
            System.out.println("Переданное значение name '" + name + "' не может быть пустым!");
        }
    }

    public int getRam() {
        return ram;
    }

    public void setRam(int ram) {
        if (ram > 0) {
            this.ram = ram;
        } else {
            System.out.println("Переданное значение ram " + ram + " не может быть отрицательным!");
        }
    }

    public int getHdd() {
        return hdd;
    }

    public void setHdd(int hdd) {
        if (hdd > 0) {
            this.hdd = hdd;
        } else {
            System.out.println("Переданное значение hdd " + hdd + " не может быть отрицательным!");
        }

    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        if (weight > 0) {
            this.weight = weight;
        } else {
            System.out.println("Переданное значение weight " + weight + " не может быть отрицательным!");
        }
    }

    public boolean iscdReadable() {
        return cdReadable;
    }

    public void setCdReadable(boolean cdReadable) {
        this.cdReadable = cdReadable;
    }

    public boolean isAdminComp() {
        return adminComp;
    }

    public void setAdminComp(boolean adminComp) {
        this.adminComp = adminComp;
    }

    public Computer[] getUserComps() {
        return userComps;
    }

    public void setUserComps(Computer[] userComps) {
        this.userComps = userComps;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
