package main;

import asus.AsusModel1;
import objects.Computer;
import objects.Notebook;
import toshiba.Toshiba;
import toshiba.ToshibaModel1;
import toshiba.ToshibaModel2;

public class MyFirstProgram {

    public static void main(String[] args) {

        ToshibaModel1 toshiba1 = new ToshibaModel1("T1");
        ToshibaModel2 toshiba2 = new ToshibaModel2("T2");
        
        AsusModel1 asus1 = new AsusModel1("A1");
        AsusModel1 asus2 = new AsusModel1("A2");
        
        toshiba1.writeDisc();
        asus1.writeDisc();
        
        
        // нельзя создавать экземпляры этих классов!
//        Toshiba t1 = new Toshiba("asdasd");
//        Asus a1 = new Asus();
        

        

     
    }
    
}
