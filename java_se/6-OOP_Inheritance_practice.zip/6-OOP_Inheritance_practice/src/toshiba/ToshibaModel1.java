package toshiba;

public class ToshibaModel1 extends Toshiba {

    public ToshibaModel1(String name) {
        super(name);
    }
}
