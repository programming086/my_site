package toshiba;

public class ToshibaModel2 extends Toshiba {

    public ToshibaModel2(String name) {
        super(name);
    }
}
