package main;

import printer.PaperFormat;
import printer.Printer;

public class StartProgram {

    public static void main(String[] args) {
        
        testPrinter();
     
    }
    
     private static void testPrinter(){
        // дополнительное задание к 6 уроку: печать принтера на заданных форматах бумаги
        Printer printer = new Printer();
        printer.printPaperTypes();
        
        printer.print(PaperFormat.A5, "1111111111111111");  
        printer.print(PaperFormat.A4, "000000000000000000000");
        printer.print(PaperFormat.A3, "4555");
    }
    
}
