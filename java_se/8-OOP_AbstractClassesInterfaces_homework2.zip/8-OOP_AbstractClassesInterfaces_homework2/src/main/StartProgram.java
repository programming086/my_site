package main;

import printer.PaperFormat;
import printer.Printer;
import toshiba.ToshibaModel1;

public class StartProgram {

    public static void main(String[] args) {

      
     
    }
    
    
    // дополнительное задание к 6 уроку: печать принтера на заданных форматах бумаги
    private static void testPrinter(){    
        Printer printer = new Printer();
        printer.printPaperTypes();// распечатать все форматы бумаги, которые существуют
       
        printer.print(PaperFormat.A5, "1111111111111111");  
        printer.print(PaperFormat.A4, "000000000000000000000");
        printer.print(PaperFormat.A3, "4555");
    }
    
}
