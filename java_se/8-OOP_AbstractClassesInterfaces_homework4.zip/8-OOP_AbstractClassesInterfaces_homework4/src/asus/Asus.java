package asus;

import objects.Notebook;

public interface Asus extends Notebook {
  
    // все асусы будут печатать приветственное сообщение (можно при загрузке)
    void printStartScreen();
    
}
