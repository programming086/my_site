package main;

import asus.Asus;
import asus.AsusModel1;
import asus.AsusModel2;
import objects.Notebook;
import printer.PaperFormat;
import printer.Printer;
import toshiba.Toshiba;
import toshiba.ToshibaModel1;
import toshiba.ToshibaModel2;

public class StartProgram {

    public static void main(String[] args) {        
        Asus asusModel1 = new AsusModel1("AsusModel1");
        Asus asusModel2 = new AsusModel2("AsusModel2");
        Toshiba toshiba1 = new ToshibaModel1("Toshiba1");
        Toshiba toshiba2 = new ToshibaModel2("Toshiba2");
        
        useNotebook(asusModel1);
        useNotebook(asusModel2);
        useNotebook(toshiba1);
        useNotebook(toshiba2);        
    }
    
    private static void useNotebook(Notebook notebook){
        notebook.useTouchPad();
        notebook.workFromBattery();
    }
    
    // дополнительное задание к 6 уроку: печать принтера на заданных форматах бумаги
    private static void testPrinter(){    
        Printer printer = new Printer();
        printer.printPaperTypes();// распечатать все форматы бумаги, которые существуют
       
        printer.print(PaperFormat.A5, "1111111111111111");  
        printer.print(PaperFormat.A4, "000000000000000000000");
        printer.print(PaperFormat.A3, "4555");
    }
    
}
