package objects;

public interface ElectronicDevice {

    // все эл. устройства должны будут реализовать поведение: включить/выключить
    void on();
    void off();
    
}
