package objects;

public interface Notebook extends Computer {

    // для ноутбуков добавляется поведение работы от батареи (чего не может обычный компьютер)
    void workFromBattery();
    void useTouchPad();
    
}
