package toshiba;

import objects.Notebook;

public interface Toshiba extends Notebook {
    
    // все тошибы должны реализовать поведение для подсветки клавиатуры
    void lightKeyboard();
}
