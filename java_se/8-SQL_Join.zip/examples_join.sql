﻿-- вывести данные (поля) по всем автомобилям (из обеих таблиц Car и Transport), чтобы вместо id значений из справочников выводились наименования на русском

select 

c.id,
crt.[name_ru] as "Тип автомобиля",
m.[name_ru] as "Модель",
tr.[name_ru] as "Коробка передач",
p.[name_ru] as "Привод",
c.[capacity] as "Объем двигателя",
br.[name_ru] as "Бренд",
tsprt.[price] as "Цена",
tsprt.[issue_date] as "Дата выпуска",
curr.[name_ru] as "Валюта",
cond.[name_ru] as "Состояние",
col.[name_ru] as "Цвет",
tsprt.[description] as "Описание"

from Car c

inner join [spr_Transmission] tr on c.[transmission_id] = tr.id
inner join [spr_Privod] p on c.[privod_id] = p.id
inner join [spr_Model] m on c.[model_id] = m.id
inner join [Transport] tsprt on c.[transport_id] = tsprt.id
inner join [spr_Currency] curr on tsprt.[currency_id] = curr.id
inner join [spr_Condition] cond on tsprt.[condition_id] = cond.id
inner join [spr_Color] col on tsprt.[color_id] = col.id
inner join [spr_CarType] crt on c.[car_type_id] = crt.id
inner join [spr_Brand] br on tsprt.[brand_id] = br.id

order by crt.[name_ru]





-- первый пункт, но только для проданных автомобилей

select 

distinct c.id,
crt.[name_ru] as "Тип автомобиля",
m.[name_ru] as "Модель",
tr.[name_ru] as "Коробка передач",
p.[name_ru] as "Привод",
c.[capacity] as "Объем двигателя",
br.[name_ru] as "Бренд",
tsprt.[price] as "Цена",
tsprt.[issue_date] as "Дата выпуска",
curr.[name_ru] as "Валюта",
cond.[name_ru] as "Состояние",
col.[name_ru] as "Цвет",
tsprt.[description] as "Описание"

from Car c

inner join [spr_Transmission] tr on c.[transmission_id] = tr.id
inner join [spr_Privod] p on c.[privod_id] = p.id
inner join [spr_Model] m on c.[model_id] = m.id
inner join [Transport] tsprt on c.[transport_id] = tsprt.id
inner join [spr_Currency] curr on tsprt.[currency_id] = curr.id
inner join [spr_Condition] cond on tsprt.[condition_id] = cond.id
inner join [spr_Color] col on tsprt.[color_id] = col.id
inner join [spr_CarType] crt on c.[car_type_id] = crt.id
inner join [spr_Brand] br on tsprt.[brand_id] = br.id
inner join [Sale] sale on tsprt.[id]=sale.transport_id 

order by crt.[name_ru]


-- первый пункт, но только для марки Toyota, цена которых меньше 3000 $  (учитывать валюту)

select 

c.id,
crt.[name_ru] as "Тип автомобиля",
m.[name_ru] as "Модель",
tr.[name_ru] as "Коробка передач",
p.[name_ru] as "Привод",
c.[capacity] as "Объем двигателя",
br.[name_ru] as "Бренд",
tsprt.[price] as "Цена",
tsprt.[issue_date] as "Дата выпуска",
curr.[name_ru] as "Валюта",
cond.[name_ru] as "Состояние",
col.[name_ru] as "Цвет",
tsprt.[description] as "Описание"

from Car c

inner join [spr_Transmission] tr on c.[transmission_id] = tr.id
inner join [spr_Privod] p on c.[privod_id] = p.id
inner join [spr_Model] m on c.[model_id] = m.id
inner join [Transport] tsprt on c.[transport_id] = tsprt.id
inner join [spr_Currency] curr on tsprt.[currency_id] = curr.id
inner join [spr_Condition] cond on tsprt.[condition_id] = cond.id
inner join [spr_Color] col on tsprt.[color_id] = col.id
inner join [spr_CarType] crt on c.[car_type_id] = crt.id
inner join [spr_Brand] br on tsprt.[brand_id] = br.id

where tsprt.[brand_id]=1 and tsprt.[price]<3000 and tsprt.[currency_id]=2

order by crt.[name_ru]


-- по каждому продавцу вывести кол-во проданных им автомобилей

select

seller.[id],
seller.[fio] as "ФИО",
count(seller.[fio]) as "Количество продаж"

from Seller 
inner join [Sale] on Seller.[id]=Sale.seller_id

group by seller.[fio], seller.[id]

order by seller.[fio]


-- вывести суммарную выручку по продажам автомобилей за январь 2011 г

select 

sum(t.[price]) as "Выручка"

from Sale s
inner join [Transport] t on t.[id]=s.transport_id

where  strftime('%Y', s.[sale_date])='2011'
and  strftime('%m', s.[sale_date])='01'


-- получить всех продавцов, которые продали хотя бы одну подержанную машину

select 

s.[fio] as "ФИО"

from Seller s

inner join Sale sl on sl.[seller_id]=s.id
inner join [Transport] t on sl.[transport_id]=t.id

where t.[condition_id]=2


-- получить всех продавцов, которые не продали ни одной машины, вывести в алфавитном порядке по ФИО

select 

s.[fio] as "ФИО",
sl.[transport_id]

from Seller s

left join Sale sl on sl.[seller_id]=s.id

where sl.[transport_id] is null

order by "ФИО"


-- получить по каждому продавцу количество проданных им машин марки Toyota, где цена >= 1000 $

select

seller.[id],
seller.[fio] as "ФИО",
t.[price],
count(seller.[fio]) as "Количество продаж"

from Seller 
inner join [Sale] on Seller.[id]=Sale.seller_id
inner join [Transport] t on Sale.[transport_id]=t.id

group by seller.[fio], seller.[id], t.[price]

having t.[price]>=1000 and t.[currency_id]=2 and t.[brand_id]=1

order by seller.[fio]
