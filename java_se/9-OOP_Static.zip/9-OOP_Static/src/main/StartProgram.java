package main;

import asus.AsusModel1;
import asus.AsusModel2;
import objects.Computer;
import printer.PaperFormat;
import printer.Printer;
import toshiba.ToshibaModel1;

public class StartProgram {

    public static void main(String[] args) {

        AsusModel1 asusModel1 = new AsusModel1("AsusModel1");
        AsusModel2 asusModel2 = new AsusModel2("AsusModel2");
        ToshibaModel1 toshibaModel1 = new ToshibaModel1("ToshibaModel1");

        Computer.showInfo();

        System.out.println(AsusModel1.createFactoryName(asusModel1.getName()));

        System.out.println(Computer.compCount);
        System.out.println(Computer.lastObject);

        asusModel1.workFromBattery();

    }

    // дополнительное задание к 6 уроку: печать принтера на заданных форматах бумаги
    private static void testPrinter() {
        Printer printer = new Printer();
        printer.printPaperTypes();// распечатать все форматы бумаги, которые существуют

        printer.print(PaperFormat.A5, "1111111111111111");
        printer.print(PaperFormat.A4, "000000000000000000000");
        printer.print(PaperFormat.A3, "4555");
    }
}
