public class Start {

    public static void main(String[] args) {
        int i=4;
        i--;
        System.out.println(i--);
    }
}
