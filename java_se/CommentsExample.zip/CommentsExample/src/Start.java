public class Start {


    private void test(){
        /*
        int i = 0;
        int j=0;
        */


        // int i=0;
    }
}
