public class Start {

    public static void main(String[] args) {
        new Test().testMethod(6);
        new Test().testMethod(3);
    }
}
