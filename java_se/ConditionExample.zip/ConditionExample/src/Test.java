public class Test {

    public void testMethod(int count){


        if (count > 5){
            count += 1;
            //test2();
        }else if (count<0){
            count = -10;
        }else{
            count += 5;
            //test3();

        }

        String a="asdasd";

        switch (a){
            case "asdasd":
                test2();
                break;
            case "asdasdas":
                test3();
                break;
            default:
        }

        // тернарный условный оператор
        count = count>0?count+1:count+5;

        System.out.println(count);

    }


    private void test2(){
        System.out.println("test2");
    }

    private void test3(){
        System.out.println("test3");
    }




}
