package ru.javabegin.training.goldman.interfaces.gamemap;

public interface TimeMap extends DrawableMap{
    
    void start();
    
    void stop();

}
