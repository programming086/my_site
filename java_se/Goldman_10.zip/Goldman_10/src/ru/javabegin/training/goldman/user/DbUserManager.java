package ru.javabegin.training.goldman.user;

public class DbUserManager extends AbstractUserManager{

    @Override
    public void save() {
        
    }

   
    


}
