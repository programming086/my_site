package ru.javabegin.training.goldman.user;

public class FSUserManager extends AbstractUserManager{

    @Override
    public void save() {
        
    }

 
 
  

}
