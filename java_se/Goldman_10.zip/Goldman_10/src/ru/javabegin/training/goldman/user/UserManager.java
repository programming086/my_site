package ru.javabegin.training.goldman.user;

public interface UserManager{
    
    void save();
    
    

}
