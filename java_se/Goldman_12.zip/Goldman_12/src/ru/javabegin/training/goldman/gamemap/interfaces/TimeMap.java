package ru.javabegin.training.goldman.gamemap.interfaces;

public interface TimeMap extends DrawableMap{
    
    void start();
    
    void stop();

}
