package ru.javabegin.training.goldman.score.impl;

import java.util.ArrayList;
import ru.javabegin.training.goldman.objects.UserScore;
import ru.javabegin.training.goldman.score.interfaces.ScoreSaver;

public class FSScoreSaver implements ScoreSaver{

    @Override
    public boolean saveScore(UserScore userScore) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public ArrayList<UserScore> getScoreList() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

  
 

  

}
