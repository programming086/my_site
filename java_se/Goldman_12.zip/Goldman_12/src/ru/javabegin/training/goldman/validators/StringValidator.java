package ru.javabegin.training.goldman.validators;

public interface StringValidator {

    boolean isValid(String text);

}
