package ru.javabegin.training.goldman.listeners.interfaces;

public interface CloseFrameListener {
    
     public void onCloseAction();

}
