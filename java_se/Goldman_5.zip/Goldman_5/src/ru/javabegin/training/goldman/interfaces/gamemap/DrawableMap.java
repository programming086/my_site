package ru.javabegin.training.goldman.interfaces.gamemap;

import java.awt.Component;

public interface DrawableMap {
    
    Component getMap();
    
    boolean drawMap();

}
