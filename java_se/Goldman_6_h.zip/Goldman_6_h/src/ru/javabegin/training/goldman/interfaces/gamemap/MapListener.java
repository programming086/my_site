package ru.javabegin.training.goldman.interfaces.gamemap;

public class MapListener {

}
