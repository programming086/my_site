package ru.javabegin.training.goldman.objects.sound;

import ru.javabegin.training.goldman.enums.ActionResult;

public interface SoundObject {

    String getSoundName(ActionResult actionResult);
    
}
