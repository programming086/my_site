package ru.javabegin.training.goldman.enums;


public enum LocationType {
    DB,
    FS
}
