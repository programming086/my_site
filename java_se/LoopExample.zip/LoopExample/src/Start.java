
public class Start {

    public static void main(String[] args) {


//        // "стандартный" цикл
//        for (int i = 0; i < 10; i++) {
//            System.out.println("i = " + i);
//        }


//        // обратный отсчет
//        for (int i = 10; i>0 ; i--) {
//            System.out.println("i = " + i);
//        }
//

//        // шаг равен 2
//        for (int i = 0; i<10 ; i+=2) {
//            System.out.println("i = " + i);
//        }

        // зацикливание (отсутствует инкремент)
//        for (int i = 0; i < 10;) {
//            System.out.println(i);
//        }


        // переменная объявлена вне цикла
//        int i = 0;
//        for (; i < 10; i++) {
//            System.out.println(i);
//        }

        // переменная типа double
//        for (double k = 0; k < 10; k+=.1) {
//            System.out.println("k = " + k);
//        }


//        int i = 0;
//        while (i < 10) {
//            System.out.println("i = " + i);
//            i++;
//        }


        // провера условия в конце прохода - хотя бы один раз выполнится
//        int i = 0;
//        do{
//            i++;
//            System.out.println("i = " + i);
//        }while(i<0);


        // использвоание break
//        for (int j = 0; j < 10; j++) {
//            System.out.println("j = " + j);
//            if (j==5){
//                break;
//            }
//        }

        // использование continue
//        int i = 0;
//        while (i < 10) {
//            i++;
//            continue;
//            System.out.println("i = " + i);
//        }


    }
}


