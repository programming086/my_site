package ru.javabegin.training.fastjava2;

import ru.javabegin.training.fastjava2.objects.Car;

public class Main {

    public static void main(String[] args) {

        Car car = new Car();
        car.setName("Toyota");

        System.out.println("car.getName() = " + car.getName());
        
        
    }
}
