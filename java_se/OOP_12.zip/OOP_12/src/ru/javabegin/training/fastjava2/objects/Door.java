package ru.javabegin.training.fastjava2.objects;

public class Door {


}
