package ru.javabegin.training.fastjava2.objects;

public class Camry30 {

    public void drive(){
        System.out.println("Camry30 drive");
    }

    public void stop(){
        System.out.println("Stop camry30");
    }
}
