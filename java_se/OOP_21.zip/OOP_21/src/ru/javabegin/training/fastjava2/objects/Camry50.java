package ru.javabegin.training.fastjava2.objects;

public class Camry50 extends Camry30{

    @Override
    public void stop(){
//        super.stop();
        System.out.println("Stop camry50");
    }
}
