package ru.javabegin.training.fastjava2.start;

import ru.javabegin.training.fastjava2.objects.Camry50;

public class Main {

    public static void main(String[] args) {
        Camry50 camry50 = new Camry50();
        camry50.stop();
    }

}
