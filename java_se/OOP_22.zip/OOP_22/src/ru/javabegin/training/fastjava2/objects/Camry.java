package ru.javabegin.training.fastjava2.objects;

public class Camry extends Toyota {

    public Camry(String name) {
        super(name);
    }

}