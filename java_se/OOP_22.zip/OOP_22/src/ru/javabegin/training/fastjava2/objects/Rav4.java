package ru.javabegin.training.fastjava2.objects;

public class Rav4 extends Toyota{

    public Rav4(String name, double volume) {
        super(name, volume);
        System.out.println("Rav4 constr");
    }
}
