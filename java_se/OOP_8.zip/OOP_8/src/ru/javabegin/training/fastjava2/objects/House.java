package ru.javabegin.training.fastjava2.objects;


public class House {

    private String color = "Black";
    private int roomCount = 5;

}
