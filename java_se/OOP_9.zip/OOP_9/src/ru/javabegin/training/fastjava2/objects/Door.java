package ru.javabegin.training.fastjava2.objects;

public class Door {

    private String color;
    private int height;

    public void open(){

    }

    public void close(boolean keyClose){

    }

}
