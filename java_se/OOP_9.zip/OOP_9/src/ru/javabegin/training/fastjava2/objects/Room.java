package ru.javabegin.training.fastjava2.objects;

public class Room {

    private int width;
    private int height;
    private int length;
}
