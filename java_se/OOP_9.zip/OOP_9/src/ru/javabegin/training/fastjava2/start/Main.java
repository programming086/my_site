package ru.javabegin.training.fastjava2.start;

import ru.javabegin.training.fastjava2.objects.House;

public class Main {

    public static void main(String[] args) {
        House house1 = new House();
        House house2 = new House();
    }
}
