package newpackage;

public interface StartInterface {
    int DEFAULT_VALUE = 5;

    void test();

    void test2();
}
