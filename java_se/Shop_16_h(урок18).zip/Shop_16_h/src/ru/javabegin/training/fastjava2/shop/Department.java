package ru.javabegin.training.fastjava2.shop;

public class Department {

    private String name;
    private String consultants;

}
