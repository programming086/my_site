package ru.javabegin.training.fastjava2.shop;

public class SalesRoom {

    private String name;

    private String consultants;


}
