package ru.javabegin.training.fastjava2.shop.bank;

public class Bank {

    private String name;
    private String creaditDescription;

    public void checkInfo(){

    }

    public void giveCredit(){

    }
}
