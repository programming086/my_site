package ru.javabegin.training.fastjava2.shop.bank;

public class Banker {

    private String name;
    private int experience;
    private String bank;

    public void sendRequest(){

    }

}
