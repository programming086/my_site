package ru.javabegin.training.fastjava2.shop.client;

public class VipVisitor {

    private String name;
    private float discount;

    public void buy(){

    }

    public void returnGoods(){

    }



}
