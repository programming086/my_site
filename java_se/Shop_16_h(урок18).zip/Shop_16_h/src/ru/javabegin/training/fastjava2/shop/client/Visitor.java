package ru.javabegin.training.fastjava2.shop.client;

public class Visitor {

    private String name;

    public void buy(){

    }

    public void returnGoods(){

    }


}
