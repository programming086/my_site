package ru.javabegin.training.fastjava2.shop.goods;

public class Computer {

    private String name;
    private int ram;
    private String department;



    public void on(){

    }

    public void off(){

    }


    public void loadOS(){

    }
}
