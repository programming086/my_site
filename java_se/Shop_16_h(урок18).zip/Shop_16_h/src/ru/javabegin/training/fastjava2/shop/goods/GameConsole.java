package ru.javabegin.training.fastjava2.shop.goods;

public class GameConsole {

    private String name;
    private int ram;
    private String department;


    public void on(){

    }

    public void loadGame(){

    }


}
