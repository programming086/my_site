package ru.javabegin.training.fastjava2.shop.goods;

public class HardDrive {

    private String name;
    private int volume;
    private String department;

    public void format(){

    }

    public void copy(){

    }

    public void delete(){

    }


}
