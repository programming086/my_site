package ru.javabegin.training.fastjava2.shop.goods;

public class Televisor {


    private String company;
    private String department;
    private String model;


    public void on(){

    }

    public void off(){

    }

    public void selectChannel(){

    }

    // пока без гетеров и сетеров, т.к. код будет еще меняться

}
