package ru.javabegin.training.fastjava2.shop.service;

public class Cashier {

    private String name;
    private String department;
    private boolean free;

    public void getMoney(){

    }

    public void giveBonusCard(){

    }


}
