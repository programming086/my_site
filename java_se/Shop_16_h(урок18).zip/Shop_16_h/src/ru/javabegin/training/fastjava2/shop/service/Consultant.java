package ru.javabegin.training.fastjava2.shop.service;

public class Consultant {

    private String name;
    private String department;
    private boolean free;


    public void consult(){

    }


    public void send(){

    }


}
