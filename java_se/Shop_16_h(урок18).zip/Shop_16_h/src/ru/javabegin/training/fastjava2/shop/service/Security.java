package ru.javabegin.training.fastjava2.shop.service;

public class Security {

    private String name;

    public void checkVisitor(){

    }

    public void openDoor(){

    }

    public void closeDoor(){

    }

}
