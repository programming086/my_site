package ru.javabegin.training.fastjava2.shop.bank;

public class BaseBank {

    private String name;
    private String creditDescription;

    public void checkInfo(){

    }

    public void giveCredit(){

    }
}
