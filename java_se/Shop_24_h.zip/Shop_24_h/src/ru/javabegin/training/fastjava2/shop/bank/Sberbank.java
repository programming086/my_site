package ru.javabegin.training.fastjava2.shop.bank;

public class Sberbank extends BaseBank {
}
