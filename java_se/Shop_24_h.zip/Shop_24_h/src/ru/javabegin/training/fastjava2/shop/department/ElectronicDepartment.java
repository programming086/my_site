package ru.javabegin.training.fastjava2.shop.department;

public class ElectronicDepartment extends BaseDepartment {


}
