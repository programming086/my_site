package ru.javabegin.training.fastjava2.shop.goods;

public class ElectronicDevice extends BaseGoods {

    public void on(){

    }

    public void off(){

    }

}
