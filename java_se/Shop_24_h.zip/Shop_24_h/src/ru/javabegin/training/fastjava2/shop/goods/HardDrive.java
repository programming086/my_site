package ru.javabegin.training.fastjava2.shop.goods;

public class HardDrive extends ElectronicDevice{


    private int volume;

    public void format(){

    }

    public void copy(){

    }

    public void delete(){

    }


}
