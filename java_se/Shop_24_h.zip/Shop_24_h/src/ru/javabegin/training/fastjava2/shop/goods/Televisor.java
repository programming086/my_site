package ru.javabegin.training.fastjava2.shop.goods;

public class Televisor extends ElectronicDevice{



    private String model;


    public void selectChannel(){

    }



}
