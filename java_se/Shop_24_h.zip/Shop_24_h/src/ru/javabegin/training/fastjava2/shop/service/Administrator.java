package ru.javabegin.training.fastjava2.shop.service;

public class Administrator{

}
