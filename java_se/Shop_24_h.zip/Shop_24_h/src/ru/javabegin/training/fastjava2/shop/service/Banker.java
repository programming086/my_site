package ru.javabegin.training.fastjava2.shop.service;

import ru.javabegin.training.fastjava2.shop.bank.BaseBank;

public class Banker extends BaseEmployee{

    private BaseBank bank;

    public void sendRequest(){

    }

}
