package ru.javabegin.training.fastjava2.shop.service;

import ru.javabegin.training.fastjava2.shop.department.BaseDepartment;

public class BaseEmployee {

    private String name;
    private BaseDepartment department;
    private boolean free;


}
