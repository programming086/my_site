package ru.javabegin.training.fastjava2.shop.bank;

public class Sberbank extends BaseBank {

    @Override
    public void checkInfo() {
        // доработанная реализация
    }

    @Override
    public void giveCredit() {
        // доработанная реализация
    }
}
