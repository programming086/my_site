package ru.javabegin.training.fastjava2.shop.client;

public class CommonVisitor extends BaseVisitor {



}
