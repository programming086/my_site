package ru.javabegin.training.fastjava2.shop.goods;

public class Plate extends BaseGoods {// тарелка - не эл. устройство, не должно уметь включать и выключаться



}
