package ru.javabegin.training.fastjava2.shop.interfaces;

public interface BankInterface {

    void checkInfo();

    void giveCredit();

    String getName();

    String getCreditDescription();
}
