package ru.javabegin.training.fastjava2.shop.service;

import ru.javabegin.training.fastjava2.shop.interfaces.BankInterface;

public class Banker extends BaseEmployee{

    private BankInterface bank;

    public void sendRequest(){

    }

}
