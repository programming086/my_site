package ru.javabegin.training.fastjava2.shop.goods;

import ru.javabegin.training.fastjava2.shop.interfaces.ElectronicDeviceInterface;

public class ElectronicDevice extends BaseGoods implements ElectronicDeviceInterface{

    @Override
    public void on() {
        // общая реализация
    }

    @Override
    public void off() {
        // общая реализация
    }
}
