package ru.javabegin.training.fastjava2.shop.interfaces;

public interface EmployeeInterface{

    String getName();

    DepartmentInterface getDepartment();

    boolean isFree();

}
