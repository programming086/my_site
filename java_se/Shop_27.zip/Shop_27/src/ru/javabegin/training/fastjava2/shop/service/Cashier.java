package ru.javabegin.training.fastjava2.shop.service;

public class Cashier extends BaseEmployee {


    public void getMoney(){

    }

    public void giveBonusCard(){

    }


}
