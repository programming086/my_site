package ru.javabegin.training.fastjava2.shop.service;

public class Consultant extends BaseEmployee {


    public void consult(){

    }


    public void send(){

    }


}
