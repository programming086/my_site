package ru.javabegin.training.fastjava2.shop.service;

public class Security extends BaseEmployee {

    public void checkVisitor(){

    }

    public void openDoor(){

    }

    public void closeDoor(){

    }

}
