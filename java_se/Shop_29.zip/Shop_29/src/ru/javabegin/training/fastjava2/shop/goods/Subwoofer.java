package ru.javabegin.training.fastjava2.shop.goods;

public class Subwoofer extends ElectronicDevice{

    public Subwoofer(String name) {
        super(name);
    }
}
