package ru.javabegin.training.fastjava2.shop.goods;

public class Computer extends ElectronicDevice{

    public Computer(String name) {
        super(name);
    }

    private int ram;



    public void loadOS(){

    }
}
