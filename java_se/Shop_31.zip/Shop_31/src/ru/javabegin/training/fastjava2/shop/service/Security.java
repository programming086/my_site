package ru.javabegin.training.fastjava2.shop.service;

public class Security extends AbstractEmployee {

    public void checkVisitor(){

    }

    public void openDoor(){

    }

    public void closeDoor(){

    }

}
