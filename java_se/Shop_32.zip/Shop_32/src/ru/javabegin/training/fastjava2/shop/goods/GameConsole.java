package ru.javabegin.training.fastjava2.shop.goods;

public class GameConsole extends ElectronicDevice{


    private int ram;


    public void loadGame(){

    }


}
