package ru.javabegin.training.fastjava2.shop.goods;

public class Televisor extends ElectronicDevice{


    public Televisor(String name) {
        super(name);
    }

    public void selectChannel(){

    }



}
