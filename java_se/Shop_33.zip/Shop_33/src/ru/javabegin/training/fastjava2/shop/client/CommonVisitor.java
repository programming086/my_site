package ru.javabegin.training.fastjava2.shop.client;

public class CommonVisitor extends AbstractVisitor {


    public CommonVisitor() {
    }

    public CommonVisitor(String name) {
        super(name);
    }
}
