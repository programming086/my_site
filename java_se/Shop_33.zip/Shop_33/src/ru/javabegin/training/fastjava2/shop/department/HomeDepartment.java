package ru.javabegin.training.fastjava2.shop.department;

public class HomeDepartment extends AbstractDepartment {
}
