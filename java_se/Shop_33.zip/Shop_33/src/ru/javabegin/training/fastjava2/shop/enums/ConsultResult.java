package ru.javabegin.training.fastjava2.shop.enums;

public enum ConsultResult {
    BUY,
    EXIT;
}
