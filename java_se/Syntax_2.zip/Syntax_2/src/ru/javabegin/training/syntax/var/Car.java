package ru.javabegin.training.syntax.var;

public class Car {

    private String name;


    private int i=5, z=6;
    private int x=7;

    public Car(int i, String name) {
        this.i = i;
        this.name = name;
    }

    private void test(){
        i=4;
    }


    public void go(){
        int count = 0;
        count++;
        System.out.println(i);
    }


    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}


