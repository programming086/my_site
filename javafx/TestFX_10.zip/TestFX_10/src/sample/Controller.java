package sample;

import javafx.event.ActionEvent;

public class Controller {

    public void firstButtonAction(ActionEvent actionEvent) {
        System.out.println("button1");

    }

    public void secButtonAction(ActionEvent actionEvent) {
        System.out.println("button2");
    }
}
