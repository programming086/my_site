package ru.javabegin.training.fastjava2.javafx.controllers;

public class MainController {
}
