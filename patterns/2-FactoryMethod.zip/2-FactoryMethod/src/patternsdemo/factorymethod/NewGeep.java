package patternsdemo.factorymethod;

public class NewGeep extends Geep{
    
    public void newFunction(){
        System.out.println("new function");
    }

}
