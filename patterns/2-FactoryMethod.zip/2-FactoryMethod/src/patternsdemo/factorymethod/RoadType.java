package patternsdemo.factorymethod;

public enum RoadType {

    CITY,
    OFF_ROAD,
    GAZON
    
}
