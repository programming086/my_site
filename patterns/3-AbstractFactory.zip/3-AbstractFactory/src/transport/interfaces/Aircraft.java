package transport.interfaces;

public interface Aircraft {

    void flight();
    
}
