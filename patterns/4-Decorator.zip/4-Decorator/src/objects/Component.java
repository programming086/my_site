package objects;

public interface Component {

    void draw();
    
}
