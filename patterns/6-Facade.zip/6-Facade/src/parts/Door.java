package parts;

public class Door{

    public void open() {
        System.out.println("door open");
    }
    
    
}
