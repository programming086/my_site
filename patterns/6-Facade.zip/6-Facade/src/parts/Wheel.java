package parts;

public class Wheel{

    public void turn() {
        System.out.println("wheel turn");
    }

    
}
