package parts;

public class Zazhiganie{

    public void fire() {
        System.out.println("fire");
    }

}
