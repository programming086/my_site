package patternsdemo.observer;

public interface PublisherActionListener {

    void doAction(String message);
}
