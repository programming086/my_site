package state;

public interface TransformerState {

    void action();
}
