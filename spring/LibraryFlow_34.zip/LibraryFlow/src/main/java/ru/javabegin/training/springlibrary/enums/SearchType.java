package ru.javabegin.training.springlibrary.enums;

public enum SearchType {

    AUTHOR,
    TITLE
}
