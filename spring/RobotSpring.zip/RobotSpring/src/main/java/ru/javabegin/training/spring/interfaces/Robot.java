package ru.javabegin.training.spring.interfaces;

public interface Robot {
	void fire();

	void dance();
}
