package ru.javabegin.training.spring.interfaces;

public interface Robot {
	void action();

	void dance();
}
