package ru.javabegin.training.spring.enums;

public enum ColorStyle {

	WHITE, BLACK, GREEN;

}
