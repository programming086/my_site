package ru.javabegin.training.spring.impls.sony;

import ru.javabegin.training.spring.interfaces.Head;

public class SonyHead implements Head{
	
	public void calc(){
		System.out.println("Thinking about Sony...");
	}

}
