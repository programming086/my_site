package ru.javabegin.training.spring.impls;

public class Database {

	public Database() {
		testConnection();
	}

	private void testConnection() {
		System.out.println("Test connection!");
	}

}
