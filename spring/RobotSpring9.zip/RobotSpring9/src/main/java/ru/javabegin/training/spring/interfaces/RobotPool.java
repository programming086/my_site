package ru.javabegin.training.spring.interfaces;

import java.util.Collection;

public interface RobotPool {

	Collection<Robot> getRobotCollection();

}
