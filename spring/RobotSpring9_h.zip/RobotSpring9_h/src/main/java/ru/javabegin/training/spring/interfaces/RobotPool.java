package ru.javabegin.training.spring.interfaces;

import java.util.Map;

public interface RobotPool {

	Map<String, Robot> getRobotCollection();

}
