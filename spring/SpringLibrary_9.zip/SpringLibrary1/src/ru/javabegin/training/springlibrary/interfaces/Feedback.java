package ru.javabegin.training.springlibrary.interfaces;

public interface Feedback {
}
