package ru.javabegin.objects;

public interface CarInterface {

	String getSound();

}
