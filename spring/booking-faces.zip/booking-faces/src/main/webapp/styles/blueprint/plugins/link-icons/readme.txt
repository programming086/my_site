Link Icons
* Icons for links based on protocol or file type.

This is not supported in IE versions < 7.


Credits
----------------------------------------------------------------

* Marc Morgan
* Olav Bjorkoy  [bjorkoy.com]


Usage
----------------------------------------------------------------

1) Add this line to your HTML:
	 <link rel="stylesheet" href="css/blueprint/plugins/link-icons/screen.css" type="text/css" media="screen, projection">	