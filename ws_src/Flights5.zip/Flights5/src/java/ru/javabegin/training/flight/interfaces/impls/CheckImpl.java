package ru.javabegin.training.flight.interfaces.impls;

import ru.javabegin.training.flight.interfaces.Check;
import ru.javabegin.training.flight.objects.Reservation;



public class CheckImpl implements Check{

    @Override
    public Reservation checkReservation(String code) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
