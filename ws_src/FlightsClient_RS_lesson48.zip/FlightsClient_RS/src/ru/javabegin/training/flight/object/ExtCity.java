package ru.javabegin.training.flight.object;

import ru.javabegin.training.flight.rs.objects.City;



public class ExtCity extends City{

    @Override
    public String toString() {
        return super.name;
    }

    
    
}
