package ru.javabegin.training.flight.enums;



public enum ListenerType {
    
    SEARCH_FLIGHT,
    ADD_CITIES,
    BUY_TICKET,
    CHECK_RESERVATION

}
