package ru.javabegin.training.flight.ws.exceptions;



public class ExceptionInfo {

    private String trace;

    public String getTrace() {
        return trace;
    }

    public void setTrace(String trace) {
        this.trace = trace;
    }
   
    

}
