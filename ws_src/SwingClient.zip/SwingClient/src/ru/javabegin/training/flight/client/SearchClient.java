package ru.javabegin.training.flight.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import ru.javabegin.training.flight.ws.City;
import ru.javabegin.training.flight.ws.Flight;
import ru.javabegin.training.flight.ws.FlightService;
import ru.javabegin.training.flight.ws.SearchImpl;

public class SearchClient {

    private FlightService flightService;
    private SearchImpl searchImpl;

    public SearchClient() {

        flightService = new FlightService();
        searchImpl = flightService.getSearchImplPort();

    }

    public ArrayList<City> getAllCities() {
        ArrayList<City> cityList = new ArrayList<>();
        cityList.addAll(searchImpl.getAllCities());
        Collections.sort(cityList, new Comparator<City>() {

            @Override
            public int compare(City t, City t1) {
                return t.getName().compareTo(t1.getName());
            }
        });
        return cityList;
    }
    
    
    public ArrayList<Flight> searchFlight(long date, City cityFrom, City cityTo){
        ArrayList<Flight> flightList = new ArrayList<>();
        flightList.addAll(searchImpl.searchFlight(date, cityFrom, cityTo));        
        return flightList;
    }
    
    
}
